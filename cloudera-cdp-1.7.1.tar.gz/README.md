# cloudera.cdp - Cloudera Data Platform (CDP) for Public and Private Cloud

## Quickstart

1. [Install the collection](#installation)
2. [Install the requirements](#required-libraries)
3. [Use the collection](#using-the-collection)

The updated [collection API documentation](https://github.infra.cloudera.com/pages/wmudge/cloudera.cdp/) is currently in
a temporary location. In addition to these documents and the API, you might find the legacy 
[cloudera.cdp module documentation](https://github.infra.cloudera.com/pages/GOES/cloudera.cdp/) helpful.

## Status

> This collection will be undergoing considerable changes in the coming weeks. Notably, the existing playbooks
> will be refactored into composable roles and moreover the CDP CLI wrappers will be converted into modules.
> In addition, this collection contains two sets of functionality: one that interacts solely with the CDP control
> plane, i.e. the modules, and one that interacts with CDP, cloud provider assets, and other non-CDP resources.
> 
> In the near future, these two will be separated; the latter functionality (the 'opinionated' approach) will be
> moved into a separate collection. The reasons for this separation are several, but the prevailing is that we
> need to provide an 'non-opinionated' library for those who want or require a complete separation between CDP
> and non-CDP resources and a configuration flag just will not suffice. 

Existing roles conversion status:

- ~~cdp_env~~
- ~~cdp_iam~~
- ~~cdp_idbroker~~
- ~~cdp_datalake~~
- ~~cdp_freeipa~~
- cdp_datahub
- cdp_cml
- cdp_cod

Additional Functionality status:

- CDP Credential Azure

## Installation

To install the `cloudera.cdp` collection, you have several options. Please note that to date, we have not yet published
this collection to the public Galaxy server, so you cannot install it via namespace.

The collection has two dependencies that should resolve via the `ansible-galaxy` command:
 
- [community.general](https://galaxy.ansible.com/community/general)
- [community.aws](https://galaxy.ansible.com/community/aws)

### Option #1: Install from internal GitHub

Create or edit the `collections/requirements.yml` file in your project with the following:

```yaml
collections:
  - name: https://github.infra.cloudera.com/GOES/cloudera.cdp.git
    type: git
    version: migration
```

And then run:

```bash
ansible-galaxy collection install -r collections/requirements.yml --force
```

Or run the installation directly:

```bash
ansible-galaxy collection install git+https://github.infra.cloudera.com/GOES/cloudera.cdp.git,migration
```

> For extra credit, use the `-p` flag to install the collection locally, e.g. `-p collections` to install the collection
> into the aptly named `collections` directory. Don't forget to set the local directory in your collections path; in 
> your project's `ansible.cfg` file, add the following:
> ```ini
> [defaults]
> collections_path = ./collections
> ```

> *!! NOTE !!*
> 
> For this option, you must be running Ansible 2.10, which is a stable release available in `pip`. To 
> install, run the following in your `venv` of choice:
> ```bash
> pip install ansible-base
> ``` 

### Option #2: Install the tarball

Periodically, the collection is packaged into a distribution which you can install directly:

```bash
ansible-galaxy collection install https://github.infra.cloudera.com/GOES/cloudera-collection/raw/master/cloudera.cdp-1.7.1.tar.gz -p collections/
```

> You do not need to be running Ansible 2.10 for this option.

### Option #3: Clone the collection repository

For collections development work especially, you can `git clone` the collection repository into your global 
COLLECTIONS_PATH.  Via this method, you can develop (and use) the collection simultaneously.

Read more at [ANSIBLE_COLLECTIONS_PATHS](https://docs.ansible.com/ansible/latest/reference_appendices/config.html#collections-paths).
this method is what is used with Foundry Tower currently.

> You do not need to be running Ansible 2.10 for this option.

## Required Libraries

The collection requires the following Python libraries install to operate its modules:

```pip
cdpcli>=0.9.17
boto
botocore
boto3
```

The [`requirements.txt`](./requirements.txt) file declares these libraries. You can install them via `pip`:

```bash
pip install -r requirements.txt
```

## Using the Collection

Once installed, you can reference the collection into your playbooks and roles.

For example, here we use the [cloudera.cdp.env_info module](./plugins/modules/env_info.py) to list all
available CDP environments:

```yaml
---

- hosts: localhost
  connection: local
  gather_facts: no

  collections:
    - cloudera.cdp

  tasks:
    - name: List all CDP environments
      env_info:
      register: output

    - name: Display the resulting JSON
      debug:
        var: output
```

> The CDP modules expect standard CDP authentication configurations, e.g. `CDP_PROFILE`.

### Modules

See the [README](./plugins/README.md) in the `plugins` directory.

### Roles

[`environment`](./roles/environment/README.md): Installation and management of CDP environments, including management of cloud provider resources as well as workload passwords.

[`iam`](./roles/iam/README.md): Management of CDP IAM groups and users.

[`idbroker`](./roles/iam/README.md): Management of CDP data access for CDP, including management of cloud provider resources.

[`datalake`](./roles/datalake/README.md): Management of CDP Datalakes, including management of cloud provider resources (storage).

## Building the Collection

To create a local collection tarball, run:

```bash
ansible-galaxy collection build 
```

For the site documentation, please see the [BUILDING DOCS](./site/BUILDING_DOCS.md) instructions.
