Cloudera Manager Repository
=========

An Ansible role for configuring the Cloudera Manager repository in preparation for installation.

Requirements
------------

None.

Role Variables
--------------

* `version`:            "7.0.3"
* `license_type`:       "trial"
* `repository_description`:
* `repository_url`:
* `repository_key_url`:
* `repository_username`:
* `repository_password`:


Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

```yaml
- name: Configure the CDH hosts
  hosts: cdh_servers
  become: yes
  
  tasks:
    - name: Configure the Cloudera Manager repository
      include_role:
        name: cm_repo
```

License
-------

AGPL

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
