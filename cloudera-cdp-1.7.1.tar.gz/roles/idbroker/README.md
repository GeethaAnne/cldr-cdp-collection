# CDP ID Broker

A role for creating and configuring the ID Broker data access for a CDP Environment, including the cloud provider prerequisites.

## Requirements

- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
datalake_name | str | The name for the CDP datalake | env.deployment | `env_name` + `datalake_name_suffix`
datalake_name_suffix | str | Suffix when auto-generating `datalake_name` | datalake.name_suffix | '-datalake'
datalake_tags | dict | Metadata tags assigned to the CDP datalake | datalake.tags | `env_tags`
datalake_storage_bucket | str | The name of the storage bucket for the Datalake. | datalake.storage_bucket | `env_deployment`
datalake_storage_path | str | Path to the Datalake directory within the storage bucket. | datalake.storage_path | `datalake_storage_path_default`
datalake_storage_path_default | str | The default path for the Datalake directory | datalake.storage_path_default | For AWS, `/data`
env_idbroker_auto_sync | bool | Flag to indicate if the ID Broker should automatically check if it should sync with the Datalake. In some cases, the Datalake might not yet exist and this function should be suppressed. | env.idbroker_auto_sync | `True`
env_idbroker_role | str | The name of the IAM role for ID Broker. The role will lookup this name in the cloud provider, and if not found, will create the IAM role. | env.idbroker_role | `env_deployment` + `env_idbroker_role_suffix`
env_idbroker_role_suffix | str | The default suffix for the ID Broker IAM role. | env.idbroker_role_suffix | '-ID-BROKER'
env_idbroker_role_policy | str | The _assume role policy_ for the ID Broker IAM role. The role will create this policy if it does not exist. The role will ignore this policy if the `env_idbroker_role` exists. | env.idbroker_role_policy | `env_deployment` + `env_idbroker_role_policy_suffix`
env_idbroker_role_policy_suffix | str | The default suffix for the _assume role policy_ for the ID Broker IAM role. | env.idbroker_role_policy_suffix | '-ID-BROKER'
env_datalake_admin_role | str | The name of the IAM role for Datalake Administrator. The role will lookup this name in the cloud provider, and if not found, will create the IAM role. | env.datalake_admin_role | `env_deployment` + `env_datalake_admin_role_suffix`
env_datalake_admin_role_suffix | str | The default suffix for the Datalake Administrator IAM role. | env.datalake_admin_role_suffix | '-DATALAKE-ADMIN'
env_datalake_admin_s3_policy | str | The _datalake admin S3 policy_ for the Datalake Administrator IAM role. The role will create this policy if it does not exist. The role will ignore this policy if the `env_datalake_admin_role` exists. | env.datalake_admin_s3_policy | `env_deployment` + `env_datalake_admin_s3_policy_suffix`
env_datalake_admin_s3_policy_suffix | str | The default suffix for the _datalake admin S3 policy_ for the Datalake Adminstrator IAM role. | env.datalake_admin_s3_policy_suffix | '-DATALAKE-ADMIN-S3'
env_ranger_audit_role | str | The name of the IAM role for Ranger Audit IAM role. The role will lookup this name in the cloud provider, and if not found, will create the IAM role. | env.ranger_audit_role | `env_deployment` + `env_ranger_audit_role_suffix`
env_ranger_audit_role_suffix | str | The default suffix for the Ranger Audit IAM role. | env.ranger_audit_role_suffix | '-RANGER-AUDIT'
env_ranger_audit_s3_policy | str | The _ranger audit S3 policy_ for the Ranger Audit IAM role. The role will create this policy if it does not exist. The role will ignore this policy if the `env_ranger_audit_role` exists. | env.ranger_audit_s3_policy | `env_deployment` + `env_ranger_audit_s3_policy_suffix`
env_ranger_audit_s3_policy_suffix | str | The default suffix for the _ranger audit S3 policy_ for the Ranger Audit IAM role. | env.ranger_audit_s3_policy_suffix | '-RANGER-AUDIT-S3'
env_bucket_access_policy | str | The _bucket access policy_ for the Datalake Administrator and Ranger Audit IAM roles. The role will create this policy if it does not exist. The role will ignore this policy if `env_datalake_admin_role` and `env_ranger_audit_role` exist. | env.bucket_access_policy | `env_deployment` + `env_bucket_access_policy_suffix`
env_bucket_access_policy_suffix | str | The default suffix for the _bucket access policy_ for the Datalake Adminstrator and Ranger Audit IAM roles. | env.bucket_access_policy_suffix | '-BUCKET-ACCESS'
env_dynamodb_policy | str | The _dynamodb policy_ for the Datalake Administrator and Ranger Audit IAM roles. The role will create this policy if it does not exist. The role will ignore this policy if `env_datalake_admin_role` and `env_ranger_audit_role` exist.  | env.dynamodb_policy | `env_deployment` + `env_dynamodb_policy_suffix`
env_dynamodb_policy_suffix | str | The default suffix for the _dynamodb policy_ for the Datalake Adminstrator and Ranger Audit IAM roles. | env.dynamodb_policy_suffix | '-DYNAMODB'
env_idbroker_group_mapping | list | A list of mapping objects, each containing the following key pairs: `group` for the CDP IAM group name and `role` for the cloud provider IAM role name. The role will validate both key pair values. | env.group_mapping | `[]`
env_idbroker_user_mapping | list | A list of mapping objects, each containing the following key pairs: `user` for the CDP IAM user identifier or CRN and `role` for the cloud provider IAM role name. The role will validate both key pair values. | env.user_mapping | `[]`
env_dynamodb_name | string | The name of the DynamoDB table backing S3Guard | env.dynamodb_name | `env_deployment`

If the data access roles, i.e. `env_datalake_admin_role` and `env_ranger_audit_role`, are defined and exist within the cloud provider, the associated policies will _not_ be checked or created. You must ensure that the existing roles have the appropriate rights and permissions assigned as per cloud provider IAM processes.

For further details, please see the [Minimal setup for cloud storage (AWS)](https://docs.cloudera.com/management-console/cloud/environments/topics/mc-idbroker-minimum-setup.html) section of the CDP documentation. 

### Host Variables

The role does not set any host variables.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../common/environment/README.md)
- [cloudera.cdp.common.idbroker](../common/idbroker/README.md)
- [cloudera.cdp.common.datalake](../common/datalake/README.md)
- [cloudera.cdp.environment.aws.s3guard](../environment/aws/s3guard/README.md)

## Example Playbook

```yml
---

# Examples assume an existing CDP Environment and Datalake

- name: Set up the minimal data access for a CDP Environment using defaults (creating cloud provider resources as needed)
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.idbroker
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1

- name: Set up a CDP Environment using the nested configuration (creating cloud provider resources as needed)
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      region: us-west-1
  tasks:
    - include_role:
        name: cloudera.cdp.environment.idbroker

- name: Set up a CDP Environment using existing cloud provider resources and additional IDBroker mappings
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      region: us-west-1
      idbroker_role: my-managed-idbroker-role
      ranger_audit_role: my-managed-ranger-audit-role
      group_mapping:
        - group: an_existing_CDP_group
          role: my-managed-data-access-role
      user_mapping:
        - user: 90b5b89f-0739-4dbd-8b2e-2ca72593d294
          role: another-managed-data-access-role
    datalake:
      storage_bucket: my-example-bucket
      storage_path: /an_example_datalake/lots_of_data
  tasks:
    - include_role:
        name: cloudera.cdp.environment.idbroker

# An example that assumes an existing CDP Environment that does not yet have a Datalake attached

- name: Create but don't sync
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.idbroker
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1
        env_idbroker_auto_sync: no
```
