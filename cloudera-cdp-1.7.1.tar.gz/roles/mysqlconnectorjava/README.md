# mysqlconnectorjava

Install [MySQLConnector/Java](https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.48.zip) to `/usr/share/java/mysql-connector-java.jar`

## Requirements

- Ansible v2.8.5

## Role Variables

## Dependencies

## Example Playbook

```yml
---

- name: INSTALL MySQL Connector/Java
  hosts: myhosts
  become: yes
  tasks:
    - name: install MySQL connector/Java
      include_role:
        name: mysqlconnectorjava

```
