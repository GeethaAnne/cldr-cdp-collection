# CDP CML

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install cdpcli`

## Example Playbook

```yml
---
- name: DEPLOY CML WORKSPACE
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    enddate: '25122020'
    cml:
      - workspaceName: "{{ deployment_id }}-ml1"
        enable_monitoring: yes # default: yes
        enable_governance: yes # default: yes
        enable_model_metrics: yes # default: yes
        disableTLS: no # default: no
        usePublicLoadBalancer: yes # default: yes
        provisionK8sRequest:
          instanceGroups:
            - autoscaling:
                enabled: true
                maxInstances: 10
                minInstances: 1
              instanceCount: 0
              instanceTier: ON_DEMAND
              instanceType: m5.4xlarge
              name: cml
              rootVolume:
                size: 100
            - autoscaling:
                enabled: true
                maxInstances: 1
                minInstances: 0
              instanceCount: 0
              instanceTier: ON_DEMAND
              instanceType: p2.8xlarge
              name: cml
              rootVolume:
                size: 100
          tags:
            - key: enddate
              value: "{{ enddate }}"
            - key: deploy_tool
              value: Foundry
            - key: deployment_id
              value: "{{ deployment_id }}"

  tasks:
    - name: ensure presence of CDP Environment
      include_role:
        name: cdp_cml
      vars:
        deployment_id: goes-aws-test
```
