# CDP Datalake

A role for creating and managing CDP Datalakes.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
datalake_name | str | The name for the CDP datalake | env.deployment | `env_name` + `datalake_name_suffix`
datalake_name_suffix | str | Suffix when auto-generating `datalake_name` | datalake.name_suffix | '-datalake'
datalake_tags | dict | Metadata tags assigned to the CDP datalake | datalake.tags | `env_tags`
datalake_scale | str | The scale of the datalake. Must be either "LIGHT_DUTY" or "MEDIUM_DUTY_HA". | datalake.scale | `LIGHT_DUTY`
datalake_storage_bucket | str | The name of the storage bucket for the Datalake. | datalake.storage_bucket | `env_deployment`
datalake_storage_path | str | Path to the Datalake directory within the storage bucket. | datalake.storage_path | `datalake_storage_path_default`
datalake_storage_path_default | str | The default path for the Datalake directory | datalake.storage_path_default | AWS: `/data`
env_name | str | The readable name of the CDP environment | env.name | `env_deployment`
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus`  
env_idbroker_role | str | The name of the IAM role for ID Broker. The role will lookup this name in the cloud provider, and if not found, will create the IAM role. | env.idbroker_role | `env_deployment` + `env_idbroker_role_suffix`
env_idbroker_role_suffix | str | The default suffix for the ID Broker IAM role. | env.idbroker_role_suffix | '-ID-BROKER'

### Host Variables

None.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../common/environment/README.md)
- [cloudera.cdp.common.idbroker](../common/idbroker/README.md)
- [cloudera.cdp.common.datalake](../common/datalake/README.md)

## Example Playbook

```yml
---
# These examples assume that the CDP Environment and its data access mappings (ID Broker) have
# been set up

- name: Set up a CDP Datalake 
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.datalake
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1
        env_tags:               
          project: Ansible role example
          notes: These tags represent 'environment'-level tags
        datalake_name_suffix: '-dl'

- name: Set up a CDP Datalake using the nested configuration
  hosts: localhost
  connection: local
  gather_facts: yes
  become: no
  collections:
    - cloudera.cdp
  vars:
    env:
      deployment: example01
      cloud: aws
      region: us-west-1
    datalake:
      name_suffix: '-test-dl'
      tags:
        project: Ansible role example
        notes: These tags override any 'environment'-level tags
  tasks:
    - include_role:
        name: datalake
```