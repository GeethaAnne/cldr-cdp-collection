# Cloudera Edge Management (CEM) Minifi

Ansible roles for automating the installation and deployment of CEM's Minifi.

## Requirements

- Ansible v2.8.5
- Minifi tarball on your Ansible machine as the Role will upload the tarball to the hosts.

## Role Variables

See `defaults/main.yml` for inline documentation and below example playbook for typical variable overrides.

## Dependencies

- Java. Currently the Role installs OpenJDK 8.

## Example Playbook

The following example playbook will do a complete installation and configuration of Minifi using the default parameters from `defaults/main.yml` (and any overrides you've placed in eg. `group_vars/all.yml`).

```yml
---
- name: INSTALL AND CONFIGURE CEM MINIFI
  hosts: minifi
  become: yes
  gather_facts: yes
  vars:
    # MINIFI
    minifi_tarballFilepath: ~/bins/minifi-0.6.0.1.0.0.0-54-bin.tar.gz

    # -- bootstrap.conf
    nifi_c2_rest_urlHost: "efm.mydomain.com"
    nifi_c2_rest_urlAckHost: "efm.mydomain.com"
    nifi_c2_agent_class: demominifi-agent

    minifi_extraConfig:
      - "nifi.c2.agent.identifier = DEMO_AGENT_001"

  tasks:
    - name: install MINIFI
      include_role:
        name: minifi

```
