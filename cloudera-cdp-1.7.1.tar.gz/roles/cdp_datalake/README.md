# CDP Datalake

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install boto boto3`
- `pip install 'ansible[azure]'`
- `pip install cdpcli`

## Example Playbook

```yml
---
- name: DEPLOY CDP DATALAKE
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    enddate: '25122020'
    cdp:
      env:
        ...
      id_broker_mappings:
        ...
      datalake:
        # defaults to '<env_name>-datalake'
        name: demo-aws-prim-dl

        # AWS: defaults to ID Broker Role instance profile
        # Azure: enter the Assumer Identity
        # identity: "arn:aws:iam::007856030109:instance-profile/Cloud-SE-CDPDemo-InstanceProfileRole"

        # AWS: defaults to '<bucked-used-in-env>/datalake'
        # Azure: defaults to datalake@<storage_account>.dfs.core.windows.net
        # path: "cloud-se-demo-useast1-test/datalake"
        database-availability-type: "NONE"
        availability_type: "NONE"
        tags:
          key1: value
          key2: value

  tasks:
    - name: ensure presence of CDP Environment
      include_role:
        name: cdp_datalake
      vars:
        deployment_id: goes-aws-test
```
