Cloudera Manager Agent
=========

An Ansible role for installing and configuring the Cloudera Manager agent.

Requirements
------------

This role installs several packages from the Cloudera repository.

Role Variables
--------------

- `_cm_server_hostname`: the CM Server hostname
- `_repo_file`: the URL of the Cloudera repository

Dependencies
------------

None.

Example Playbook
----------------

```yml
---
- name: PROVISION CM AGENT
  hosts: all
  become: yes
  tasks:
    - name: Install and configure the Cloudera Manager agent
      include_role:
        name: cm_agent
      vars:
        _cm_server_hostname: "cm-server.domain.com"
        _repo_file: "url-of-cm-repository"
```

License
-------

AGPL

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
