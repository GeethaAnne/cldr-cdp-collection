# CDP Environment - AWS S3Guard

A role for setting up the AWS DynamoDB name for S3Guard for CDP.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_dynamodb_name | string | The name of the DynamoDB table backing S3Guard | env.dynamodb_name | `env_deployment`

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__aws_dynamodb_name | str | Value of `env_dynamodb_name`

## Dependencies

### Roles
- [cloudera.cdp.common.environment](../../common/README.md)

## Example Playbook

```yml
---
- name: Configure AWS S3Guard 
  hosts: localhost
  connection: local
  tasks:
    - name: Set the S3Guard internal variable
      include_role:
        name: cloudera.cdp.environment.aws.s3guard
      vars:
        env_dynamodb_name: name-of-s3guard-backing-db
```
