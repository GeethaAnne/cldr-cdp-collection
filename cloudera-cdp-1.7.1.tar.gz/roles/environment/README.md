# CDP Environment

A set of "opinionated" roles for setting up CDP Environments within cloud providers. The roles are capable of setting
up the cloud provider assets required to run an environment, such as AWS IAM roles and policies, S3 buckets, security
groups, etc., as well as delegating to existing cloud assets or to self-management via the CDP control plane.

The [deploy](deploy/README.md) role is an entrypoint for this suite and creates and configures a base CDP environment
using a number of other roles as needed to create the basic structure and processes. Notably, the `deploy` role calls
the [credentials](credentials/README.md), [logs](logs/README.md), [network](network/README.md), and
[security](security/README.md) roles, all of which set internal variables for their artifacts that the role then
passes to its main function.

The [workload](workload/README.md) role sets the workload password on the environment for the current CDP user.

## Requirements

This set of roles requires the following collections:

. `cloudera.cdp`
. `amazon.aws`

The Python environment for the roles, in aggregate, requires:
 
- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

Proper CDP credentials, e.g. CDP_PROFILE, as well as AWS or Azure credentials must be available to the Ansible 
working environment as required by the underlying module.

If creating cloud provider resources, like IAM policies, please ensure the provider login credentials have the 
proper rights for these actions.

## Role Variables

Each role requires a set of variables; some variables are shared. For details on each, please see the README for the 
given role.

Below is the full set, in "nested" form, of configuration variables used by this suite of roles. Note that some cloud
provider specifics are only accessible via the "flat" form; see each role for details.

```yaml
env:
  # Common
  deployment:
  deployment_prefix:
  name:
  tags:
  cloud:
  region:
  # Credentials
  credential:
  credential_suffix:
  credential_description:
  cdp_account_id:
  cdp_external_id:
  credential_aws_cross_account_policy:
  credential_aws_cross_account_policy_suffix:
  credential_aws_cross_account_role:
  credential_aws_cross_account_role_suffix:
  # Deploy
  description:
  workload_analytics:
  public_ip:
  manage_network:
  manage_security:
  network_cidr:
  public_key_id: 
  # Logs (storage)
  log_bucket: 
  log_path:
  log_path_default:
  log_identity:
  log_identity_suffix:
  # Network
  vpc:
  vpc_cidr:
  vpc_public_subnets:
  vpc_public_subnets_config:
  vpc_private_subnets:
  vpc_private_subnets_config:
  vpc_gateway:
  # Security
  inbound_cidrs:
  sg_default:
  sg_default_suffix:
  sg_default_description:
  sg_default_rules:
  sg_knox:
  sg_knox_suffix:
  sg_knox_description:
  sg_knox_rules:
  # Workload Password
  workload_password:
```

## Dependencies

Requires `gather_facts: yes` to handle the `env_deployment` default.

- `pip install boto boto3`
- `pip install 'ansible[azure]'`
- `pip install cdpcli`

## Example Playbook

Create all cloud provider (AWS) resources, like IAM roles and S3 buckets, and manage network and security via CDP. The 
only item must be provided prior is the SSH key.

> Note: these examples only set up the base environment, not the ID Broker mappings, etc.

```yaml
- name: Construct cloud resources with CDP-managed networking and security
  hosts: localhost
  connection: local
  gather_facts: yes
  become: no
  collections:
    - cloudera.cdp
  vars:
    # There are two means of setting a role variable - by 'flat' name or by 'nested' name
    # The two variables below demonstrate the 'flat' mode of operation. 'Flat' overrides 
    # 'nested'.
    env_cloud: aws
    env_region: us-east-1

    # The following are the 'nested' variables.
    env:
      name: full-managed
      deployment: full-managed-example
      cloud: something_else                 # Overridden by the direct role variable above
      public_key_id: example-ssh-key        # This key (i.e. the key label) must exist in the cloud provider 
      inbound_cidrs:
        - 74.217.76.0/24 
      tags:
        owner: example@cloudera.com
        project: Ansible role example
  tasks:
    - name: Deploy a CDP environment
      include_role:
        name: environment.deploy
```

Create a CDP environment using pre-existing cloud provider (AWS) resources for IAM roles and policies, network, and
security.

```yaml
- name: Use preexisting cloud resources with CDP
  hosts: localhost
  connection: local
  gather_facts: yes
  become: no
  collections:
    - cloudera.cdp
  vars:
    env:
      name: preexisting
      deployment: preexisting-example
      cloud: aws
      region: us-east-1
      credential: preexisting-credential
      log_bucket: preexisting-logs          # Assumes default object path, /logs, within the bucket
      log_identity: preexisting-log-role
      public_key_id: wmudge-staging
      tags:
        owner: example@cloudera.com
        project: Ansible role example
      manage_networking: no
      vpc: vpc-9876543210
      vpc_public_subnets:
        - public_a
        - public_b
        - public_c
      vpc_private_subnets:
        - private_a
        - private_b
        - private_c
        - private_d
      vpc_gateway: prexisting-gateway
      manage_security: no
      sg_default: preexisting-default
      sg_knox: preexisting-knox
      idbroker_role: preexisting-idbroker
      datalake_admin_role: preexisting-dl-admin
      ranger_audit_role: preexisting-ranger-audit
  tasks:
    - name: Deploy a CDP environment
      include_role:
        name: environment.deploy
```
