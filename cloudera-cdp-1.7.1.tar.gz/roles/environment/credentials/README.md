# CDP Environment - Credentials

A role for managing CDP credentials and cloud provider users, roles, and policies.

## Requirements

- ansible >= 2.10
- boto3
- boto
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_credential | str | The name of the CDP credential | env.credential | `env_deployment` + `env_credential_suffix`
env_credential_suffix | str | Suffix when auto-generating `env_credential` | env.credential_suffix | '-credential'
env_credential_description | str | Readable, short description for the CDP credential | env.credential_description | `env_credential`
env_credential_aws_cdp_account_id | str | The Account ID for the CDP installation. If undefined, then the value will be found from the CDP account automatically. See [Cloudera Docs / Management Console](https://docs.cloudera.com/management-console/cloud/credentials-aws/topics/mc-create-credentialrole.html) | env.cdp_account_id | Mandatory if creating a cloud provider cross-account role
env_credential_aws_cdp_external_id | str | The External ID for the CDP installation. If undefined, then the value will be found from the CDP account automatically. See [Cloudera Docs / Management Console](https://docs.cloudera.com/management-console/cloud/credentials-aws/topics/mc-create-credentialrole.html) | env.cdp_external_id | Mandatory if creating a cloud provider cross-account role
env_credential_aws_cross_account_policy | str | The name of the cross-account policy at the cloud provider | env.credential_aws_cross_account_policy | `env_deployment` + `env_credential_aws_cross_account_policy_suffix`
env_credential_aws_cross_account_policy_suffix | str | Suffix when auto-generating `env_credential_aws_cross_account_policy` | env.credential_aws_cross_account_policy_suffix | '-cross-account'
env_credential_aws_cross_account_role | str | The name of the cross-account role at the cloud provider | env.credential_aws_cross_account_role | `env_deployment` + `env_credential_aws_cross_account_role_suffix`
env_credential_aws_cross_account_role_suffix | str | Suffix when auto-generating `env_credential_aws_cross_account_role` | env.credential_aws_cross_account_role_suffix | '-cross-account'
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus`  


If the value of `env_credential` does not exist in the CDP installation, the role will use (or create, if not present) 
the cross-account IAM role to register the CDP credential.

WARNING: This logic is subject to change in order to separate the use and creation of the cloud provider cross-account
roles and policies. Currently, cross-account management is brute-force.

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__env_credential | str | The name of the CDP environment credential, supplied or auto-generated.

## Dependencies

The role validates that the `env_credential` conforms with the required CDP format; only lowercase letters, numbers, and
hyphens are permitted.

### Roles
- [cloudera.cdp.common.environment](../../common/environment/README.md)

## Example Playbook

```yml
---
- name: Set up a CDP Credential using discovered account credentials and cross-account role and policy
  hosts: localhost
  connection: local
  tasks:
    - include_role:
        name: cloudera.cdp.environment.credential
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1

- name: Set up a CDP Credential using the nested configuration and an existing cross-account role and policy
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      region: us-west-1
      credential: cred-for-example01
      credential_aws_cross_account_policy: a_policy_name
      credential_aws_cross_account_role: a_role_name
      cdp_account_id: 1233456789
      cdp_external_id: 1234-4567-7890-1234
  tasks:
    - include_role:
        name: cloudera.cdp.environment.credential        
```
