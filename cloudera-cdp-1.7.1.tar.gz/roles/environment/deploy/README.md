# CDP Environment - Deploy

A role for constructing a CDP Environment and its associated prerequisites.

## Requirements

- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'
env_name | str | The readable name of the CDP environment | env.name | `env_deployment`
env_tags | dict | Metadata tags assigned to cloud and CDP resources | env.tags | None
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus` 
env_description | str | Readable, short description of the environment | env.description | 'Built with Ansible'
env_workload_analytics | bool | Flag for enabling Workload Analytics for the environment | env.workload_analytics | True
env_public_ip | bool | Flag for using public IP addresses for the environment | env.public_ip | True
env_manage_network | bool | Flag indicating if the network is managed by the CDP control plane or will be generated or use preexisting resources | env.manage_network | True
env_network_cidr | str | The CIDR address for the auto-generated CDP networking, if `env_manage_network` is set | env.network_cidr | '10.10.0.0/16'
env_public_key_id | str | The label for the SSH public key set on instances in the cloud provider | env.public_key_id | Mandatory
env_manage_security | bool | Flag indicating if the security groups are managed by the CDP control plane or will be generated or use preexisting resources | env.manage_security | True
env_inbound_cidrs | list | List of CIDR addresses managing the inbound access. If `env_manage_security` is set, then only one CIDR address can be assigned. If not set to `False`, then the list is passed to the `environment/security` role. | env.inbound_cidrs | ['255.255.255.255/32']
env_credential | str | The name of the CDP credential | env.credential | `env_deployment` + `env_credential_suffix`
env_credential_suffix | str | Suffix when auto-generating `env_credential` | env.credential_suffix | '-credential'
env_credential_description | str | Readable, short description for the CDP credential | env.credential_description | `env_credential`
env_credential_aws_cdp_account_id | str | The Account ID for the CDP installation. If undefined, then the value will be found from the CDP account automatically. See [Cloudera Docs / Management Console](https://docs.cloudera.com/management-console/cloud/credentials-aws/topics/mc-create-credentialrole.html) | env.cdp_account_id | Mandatory if creating a cloud provider cross-account role
env_credential_aws_cdp_external_id | str | The External ID for the CDP installation. If undefined, then the value will be found from the CDP account automatically. See [Cloudera Docs / Management Console](https://docs.cloudera.com/management-console/cloud/credentials-aws/topics/mc-create-credentialrole.html) | env.cdp_external_id | Mandatory if creating a cloud provider cross-account role
env_credential_aws_cross_account_policy | str | The name of the cross-account policy at the cloud provider | env.credential_aws_cross_account_policy | `env_deployment` + `env_credential_aws_cross_account_policy_suffix`
env_credential_aws_cross_account_policy_suffix | str | Suffix when auto-generating `env_credential_aws_cross_account_policy` | env.credential_aws_cross_account_policy_suffix | '-cross-account'
env_credential_aws_cross_account_role | str | The name of the cross-account role at the cloud provider | env.credential_aws_cross_account_role | `env_deployment` + `env_credential_aws_cross_account_role_suffix`
env_credential_aws_cross_account_role_suffix | str | Suffix when auto-generating `env_credential_aws_cross_account_role` | env.credential_aws_cross_account_role_suffix | '-cross-account'
env_log_identity | str | Cloud provider-specific identity for the environment | env.log_identity | `env_deployment` + `env_log_identity_suffix`
env_log_identity_suffix | str | Suffix when auto-generating the log identity | env.log_identity_suffix | '-LOG-ROLE'
env_log_azure_subscription_id | str | | | 
env_log_azure_role_logger_storage | str | | | 
env_log_aws_policy_log_location | str | AWS policy name for log location, i.e. the `aws-cdp-log-policy` | | `env_deployment` + `env_log_aws_policy_log_location_suffix`
env_log_aws_policy_log_location_suffix | str | Suffix when auto-generating the log location policy | | '-LOG-POLICY'
env_log_bucket | str | Cloud provider-specific log location container for the environment | env.log_bucket | `env_deployment`
env_log_path | str | Cloud provider-specific log location path or key for the environment | env.log_path | `env_log_path_default`
env_log_path_default | str | Default log location path | env.log_path_default | For `env_cloud: aws`, '/datalake/logs'. For `env_cloud: azure`, 'TKTK'
env_vpc | str | Cloud provider-specific VPC name for the environment | env.vpc | `env_deployment`
env_vpc_cidr | str | CIDR block used during auto-generation | env.vpc_cidr | '10.10.0.0/16'
env_public_subnets | list | Names of the existing VPC public subnets | env.vpc_public_subnets |
env_public_subnets_config | list | Objects defining the VPC public subnets | env.vpc_public_subnets_config | _See below_
env_private_subnets | list | Objects defining the VPC private subnets | env.vpc_private_subnets | _See below_
env_gateway | str | Name of the Internet Gateway for the VPC | env.vpc_gateway | 
env_inbound_cidrs | list | CIDR blocks allowed to access the environment | env.inbound_cidrs | None - mandatory variable
env_security_group_default | str | Name of the default security group | env.sg_default | `env_deployment` + `env_security_group_default_suffix`
env_security_group_default_suffix | str | Suffix used when auto-generating the default security group | env.sg_default_suffix | '_sg_default'
env_security_group_default_description | str | Readable, short description of the default security group | env.sg_default_description | 'Default security group for CDP environment'
env_security_group_default_rules | list | Objects defining additional default security group rules | env.sg_default_rules | See [security](../security/README.md)
env_security_group_knox | str | Name of the Knox security group | env.sg_knox | `env_deployment` + `env_security_group_knox_suffix`
env_security_group_knox_suffix | str | Suffix used when auto-generating the Knox security group | env.sg_knox_suffix | '_sg_knox'
env_security_group_knox_description | str | Readable, short description of the Knox security group | env.sg_knox_description | 'Knox security group for CDP environment'
env_security_group_knox_rules | list | Objects defining additional Knox security group rules | env.sg_knox_rules | See [security](../security/README.md)

If the `env_name` (see [cloudera.cdp.common.environment](../../common/environment/README.md)) is not found in the CDP installation, the
role will register a new environment.  The role will set up the [credential](../credentials/README.md) and 
[log](../logs/README.md) prerequisites if they are not specified or do not exist. 

Additionally, the role will set up via the cloud provider the [network](../network/README.md) and 
[security](../security/README.md) resources if the `env_manage_network` and `env_manage_security` settings are `False`. 
Otherwise, i.e. `True`, the network and security resources are managed directly by CDP.

Currently, only Azure supports the use of `env_public_ip`; AWS automatically uses public IP addresses.

### Host Variables

The role does not set any host variables.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../../common/environment/README.md)
- [cloudera.cdp.verify.cdp](../../verify/cdp/README.md)
- [cloudera.cdp.verify.cloud](../../verify/cloud/README.md)
- [cloudera.cdp.environment.credentials](../credentials/README.md)
- [cloudera.cdp.environment.network](../network/README.md)
- [cloudera.cdp.environment.security](../security/README.md)
- [cloudera.cdp.environment.logs](../logs/README.md)

## Example Playbook

```yml
---
- name: Set up common variables for CDP Environments (CDP-managed networking and security)
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.deploy
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1
        env_public_key_id: ssh_key_label
        env_inbound_cidrs:
          - 192.175.27.0/24

- name: Set up a CDP Environment using the nested configuration (cloud provider-managed networking and security)
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      manage_network: no
      manage_security: no 
      public_key_id: ssh_key_label
      inbound_cidrs:
        - 192.175.27.0/24
  tasks:
    - include_role:
        name: cloudera.cdp.environment.deploy      
```
