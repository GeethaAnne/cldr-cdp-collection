# CDP Environment - Security

A role for managing CDP security prerequisites if not handled directly by the CDP control plane.

## Requirements

- ansible >= 2.10
- boto3
- boto
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_inbound_cidrs | list | CIDR blocks allowed to access the environment | env.inbound_cidrs | None - mandatory variable
env_security_group_default | str | Name of the default security group | env.sg_default | `env_deployment` + `env_security_group_default_suffix`
env_security_group_default_suffix | str | Suffix used when auto-generating the default security group | env.sg_default_suffix | '_sg_default'
env_security_group_default_description | str | Readable, short description of the default security group | env.sg_default_description | 'Default security group for CDP environment'
env_security_group_default_rules | list | Objects defining additional default security group rules | env.sg_default_rules | _See below_
env_security_group_knox | str | Name of the Knox security group | env.sg_knox | `env_deployment` + `env_security_group_knox_suffix`
env_security_group_knox_suffix | str | Suffix used when auto-generating the Knox security group | env.sg_knox_suffix | '_sg_knox'
env_security_group_knox_description | str | Readable, short description of the Knox security group | env.sg_knox_description | 'Knox security group for CDP environment'
env_security_group_knox_rules | list | Objects defining additional Knox security group rules | env.sg_knox_rules | _See below_
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'

If the values for either `env_security_group_default` or `env_security_group_knox` do not exist in the CDP 
installation's VPC, the role will create the respective groups. Otherwise, the role will look up the details of the 
groups.

### Additional Security Group Rules

The role supports the addition of rules to the default ones described below. The `env_security_group_default_rules` and
`env_security_group_knox_rules` accept a list of dictionaries, each element describing a rule. The configuration for
each rule is:

Variable | Type | Description
--- | --- | ---
proto | str | The protocol of the rule. Choices are 'tcp', 'udp', and 'all'.
ports | list | A list of integers describing the port numbers of the rule. Ignored if `proto=all`.
cidr_ip | list | A list of strings describing the CIDR blocks of the rule.

#### Default Rules

```yaml
- proto: tcp
  ports:
    - 22
  cidr_ip: "{{ env_inbound_cidrs }}"
- proto: tcp
  ports:
    - 443
  cidr_ip: "{{ env_inbound_cidrs }}"
- proto: tcp
  ports: 9443
  cidr_ip:
    - 52.36.110.208/32
    - 52.40.165.49/32
    - 35.166.86.177/32
- proto: all
  cidr_ip:
    - 10.10.0.0/16 # Replaced by the actual CIDR block of the VPC
```

#### Knox Rules

```yaml
- proto: tcp
  ports:
    - 22
  cidr_ip: "{{ env_inbound_cidrs }}"
- proto: tcp
  ports:
    - 443
  cidr_ip: "{{ env_inbound_cidrs | union(['52.36.110.208/32', '52.40.165.49/32', '35.166.86.177/32']) }}"
- proto: tcp
  ports: 9443
  cidr_ip:
    - 52.36.110.208/32
    - 52.40.165.49/32
    - 35.166.86.177/32
- proto: all
  cidr_ip:
    - 10.10.0.0/16 # Replaced by the actual CIDR block of the VPC
```

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__security_group_default | str | Cloud provider-specific default security group identifier either from supplied or auto-generated.
__security_group_knox | str | Cloud provider-specific Knox security group identifier either from supplied or auto-generated.

## Dependencies

### Roles
- [cloudera.cdp.common.environment](../../common/environment/README.md)

## Example Playbook

```yml
---
- name: Set up CDP security groups 
  hosts: localhost
  connection: local
  tasks:
    - include_role:
        name: cloudera.cdp.environment.security
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1
        env_inbound_cidrs: ['192.175.27.0/24']

- name: Set up CDP security groups using the nested configuration and additional group rules
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      region: us-west-1
      inbound_cidrs:
        - 192.175.27.0/24
      sg_default_rules:
        - proto: tcp
          ports:
            - 8080
          cidr_ip: 192.175.27.0/24
      sg_knox_rules:
        - proto: tcp
          ports:
            - 8080
          cidr_ip: 192.175.27.0/24
  tasks:
    - include_role:
        name: cloudera.cdp.environment.security       
```
