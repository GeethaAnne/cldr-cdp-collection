# CDP Environment - Workload Password

A role for setting the workload password for the current user for an environment.

## Requirements

- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_workload_password | The workload password to set on the environment for the current CDP user | env.workload_password | 'Cloudera$ecret008'
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'
env_name | str | The readable name of the CDP environment | env.name | `env_deployment`

The current CDP user is defined by `CDP_PROFILE` authentication details.

### Host Variables

The role does not set any host variables.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../../common/environment/README.md)

## Example Playbook

```yml
---

# Examples assume an existing CDP Environment

- name: Set the workload password on the Environment
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.workload
      vars:
        env_name: example01
        env_workload_password: VerySecretPassword

- name: Set the workload password on the Environment using the nested configuration
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      name: example01
      workload_password: VerySecretPassword
  tasks:
    - include_role:
        name: cloudera.cdp.environment.workload
```
