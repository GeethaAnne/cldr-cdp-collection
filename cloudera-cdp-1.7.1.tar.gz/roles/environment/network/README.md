# CDP Environment - Network

A role for managing CDP network prerequisites if not handled directly by the CDP control plane. 

## Requirements

- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_vpc | str | Cloud provider-specific VPC name for the environment | env.vpc | `env_deployment`
env_vpc_cidr | str | CIDR block used during auto-generation | env.vpc_cidr | '10.10.0.0/16'
env_public_subnets | list | Names of the existing VPC public subnets | env.vpc_public_subnets |
env_public_subnets_config | list | Objects defining the VPC public subnets | env.vpc_public_subnets_config | _See below_
env_private_subnets | list | Objects defining the VPC private subnets | env.vpc_private_subnets | _See below_
env_gateway | str | Name of the Internet Gateway for the VPC | env.vpc_gateway | 
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus`  
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'

NOTE: `env_vpc` is the name or label for the VPC, not the identifier itself.

If the Internet Gateway (IGW) does not exist, it will be created. An existing IGW must be attached to the VPC, 
otherwise a new IGW will be created. If there are more than one IGW with the same name within the VPC, the role will
fail. The role will ensure that all public subnets, existing or created, will be routed to the IGW.

Subnets, if needed to be created or updated, are defined as lists of dictionary objects via the `env_*_subnets_config` 
parameters:

Key | Type | Description
--- | --- | ---
name | str | Name prefix for the subnet. Will be concatenated with the availability zone found at `az_idx` or the default zone if none is found.
cidr | str | CIDR block for the subnet.
az_idx | int | Availability zone index

If `env_public_subnets_config` or `env_private_subnets_config` are defined, they each replace their respective defaults.

If `env_public_subnets` or `env_private_subnets` are defined, no subnets will be created; the role will check for 
the subnets existence and use them if all are found. These two parameters take precedence over their `*_config`
 counterparts.
 
### Default Public Subnets

```yaml
- name: public
  cidr: 10.10.0.0/19
  az_idx: 0
- name: public
  cidr: 10.10.32.0/19
  az_idx: 1
- name: public
  cidr: 10.10.64.0/19
  az_idx: 2
- name: public
  cidr: 10.10.96.0/19
  az_idx: 3
```

### Default Private Subnets
```yaml
- name: private
  cidr: 10.10.128.0/19
  az_idx: 0
- name: private
  cidr: 10.10.160.0/19
  az_idx: 1
- name: private
  cidr: 10.10.192.0/19
  az_idx: 2
- name: private
  cidr: 10.10.224.0/19
  az_idx: 3
```

### Host Variables

The role sets the following values on the host.

Variable | Type | Description
--- | --- | --- 
__vpc_id | str | Cloud provider-specific VPC identifier, whether supplied or auto-generated
__vpc_public_subnets | list | Cloud provider-specific identifiers for each public subnet, whether supplied or auto-generated
__vpc_private_subnets | list | Cloud provider-specific identifiers for each private subnet, whether supplied or auto-generated
__vpc_internet_gateway | str | Cloud provider-specific Internet Gateway identifier, whether supplied or auto-generated

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../../common/environment/README.md)

## Example Playbook

```yml
---
- name: Set up CDP network requirements using defaults
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.network
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1

- name: Set up CDP network requirements using the nested configuration with specified VPC and custom public subnets
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
      vpc: custom_vpc
      vpc_public_subnets_config:
        - name: custom
          cidr: 10.10.0.0/19
          az_idx: 0
        - name: custom
          cidr: 10.10.32.0/19
          az_idx: 1
  tasks:
    - name: Test CDP environment network
      include_role:
        name: cloudera.cdp.environment.network
```
