# CDP Environment - Log

A role for managing CDP log prerequisites.

## Requirements

- ansible >= 2.10
- boto
- boto3
- cdpcli >= 0.9.12

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_log_identity | str | Cloud provider-specific identity for the environment | env.log_identity | `env_deployment` + `env_log_identity_suffix`
env_log_identity_suffix | str | Suffix when auto-generating the log identity | env.log_identity_suffix | '-LOG-ROLE'
env_log_azure_subscription_id | str | | | 
env_log_azure_role_logger_storage | str | | | 
env_log_aws_policy_log_location | str | AWS policy name for log location, i.e. the `aws-cdp-log-policy` | | `env_deployment` + `env_log_aws_policy_log_location_suffix`
env_log_aws_policy_log_location_suffix | str | Suffix when auto-generating the log location policy | | '-LOG-POLICY'
env_log_bucket | str | Cloud provider-specific log location container for the environment | env.log_bucket | `env_deployment`
env_log_path | str | Cloud provider-specific log location path or key for the environment | env.log_path | `env_log_path_default`
env_log_path_default | str | Default log location path | env.log_path_default | For `env_cloud: aws`, '/datalake/logs'. For `env_cloud: azure`, 'TKTK'
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus` 

For AWS, `env_log_identity` is the "friendly" name for the logging role, i.e. the `RoleName`. The role will query the
IAM endpoint to retrieve the role details, notably the instance profile ARN.

The role will attempt to create the log location and log identity if the variables, `env_log_bucket` and 
`env_log_identity` respectively, are not defined. 

WARNING: If `env_log_identity` is defined, its policy will not be updated. This means that if the `env_log_bucket` or `env_log_path`
variables are not already addressed by the policy, then the CDP Environment deployment will fail.

### Host Variables

The role sets the following values on the host.

Variable | Type | Description
--- | --- | --- 
__log_location | str | Cloud provider-specific complete storage location (bucket, object), whether supplied or auto-generated
__log_identity | str | Cloud provider-specific identifier for the log role, whether supplied or auto-generated

## Dependencies

### Roles

- [cloudera.cdp.common.environment](../../common/environment/README.md)

## Example Playbook

```yml
---
- name: Set up CDP logging requirements
  hosts: localhost
  connection: local
  gather_facts: yes
  tasks:
    - include_role:
        name: cloudera.cdp.environment.logs
      vars:
        env_deployment: example01
        env_cloud: aws
        env_region: us-west-1

- name: Set up CDP logging requirements using the nested configuration
  hosts: localhost
  connection: local
  gather_facts: yes
  vars:
    env:
      deployment: example01
      cloud: aws
  tasks:
    - name: Test CDP environment logs
      include_role:
        name: cloudera.cdp.environment.logs
```
