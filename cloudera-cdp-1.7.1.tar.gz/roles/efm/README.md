# Cloudera Edge Management (CEM) Edge Flow Management (EFM)

Ansible roles for automating the deployment of CEM's Edge Flow Management (EFM).

## Requirements

- Ansible v2.8.5
- EFM tarball on your Ansible machine as the Role will upload the tarball to the hosts.

## Role Variables

See `defaults/main.yml` for inline documentation and below example playbook for typical variable overrides.

## Dependencies

EFM has a dependency on Ansible Role `roles-mysqlconnectorjava`, see [GitHub repo](https://github.infra.cloudera.com/GOES/roles-mysqlconnectorjava).

## Example Playbook

The following example playbook will do a complete installation and configuration of CEM EFM using the default parameters from `defaults/main.yml` (and any overrides you've placed in eg. `group_vars/all.yml`).

```yml
---

- name: INSTALL AND CONFIGURE CEM EFM
  hosts: efm
  become: yes
  vars:
    # EFM
    efm_tarballFilepath: ~/bins/efm-1.0.0.1.0.0.0-54-bin.tar.gz

    # -- efm.properties
    efm_server_address: "efm.mydomain.com"
    efm_db_url: jdbc:mysql://my-mysqldb.mydomain.com:3306/mydatabase
    efm_db_driverClass: com.mysql.jdbc.Driver
    efm_db_username: myusername
    efm_db_password: mypassword
    efm_nifi_registry_url: http://nifi.mydomain.com:18080
    efm_nifi_registry_bucketName: mybucket

    efm_extraConfig:
      - "efm.encryption.password = Cloudera_NiFi123"

  tasks:
    - name: install EFM
      include_role:
        name: efm

```
