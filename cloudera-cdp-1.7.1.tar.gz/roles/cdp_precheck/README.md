# CDP Prechecks

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install boto boto3`
- `pip install 'ansible[azure]'`
- `pip install cdpcli`

## Example Playbook

```yml
---
- name: CHECK CDP ENVIRONMENT PREREQUISITES
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    # if true, we will run prechecks as step 0
    run_precheck: true
    # if true, the playbook will stop after completing prechecks
    skip_deployment: true
    cdp:
      env:
        # AWS or Azure
        cloud: Azure
        # Mandatory field
        region: eastus

  tasks:
    - name: run pre-checks for creating an environment
      include_role:
        name: cdp_precheck
```
