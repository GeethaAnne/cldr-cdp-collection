# CDP Setup

A role for provisioning a CDP Public Cloud deployment

## Requirements

- ansible >= 2.10

## Role Variables

The role expects a set of nested configuration sections for each experience of CDP.

Variable | Description 
---| --- 
env | General Environment configuration
iam | IAM user and group definition and assignments
datalake | Datalake definition
datahub | tktk
mlx | tktk
odx | tktk
dwx | tktk

### Host Variables

None.

## Dependencies

### Roles

None.

## Example Playbook

```yml
- name: A CDP Public Cloud deployment
  hosts: localhost
  connection: local
  gather_facts: yes
  become: no
  tasks:
    - name: Provision a cloud deployment
      include_role:
        name: cloudera.cdp.setup
      vars:
        env:
            deployment: example
            cloud: aws
            region: us-east-2
            workload_password: Cloudera!!2020
            public_key_id: cloud-key
            inbound_cidrs:
                - 192.168.1.0/24
            tags:
                project: An example
        iam:
            env_groups:
              - name: example-admin-group
                add_current_user: yes
                purge: yes
                roles:
                    - PowerUser
                resource_roles:
                    - EnvironmentAdmin
                    - EnvironmentUser
                    - DEAdmin
                    - DEUser
                    - DWAdmin
                    - DWUser
                    - MLAdmin
                    - MLUser
              - name: wmudge-runbook-users
                users:
                    - f6a7640d-6c9c-404c-8474-74be5053ee10
                roles:
                    - PowerUser
                resource_roles:
                    - EnvironmentUser
                    - DEUser
                    - DWUser
                    - MLUser
```