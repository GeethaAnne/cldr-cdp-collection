# CDP COD

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install cdpcli`

## Example Playbook

```yml
---
- name: DEPLOY COD DATABASE
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    enddate: '25122020'
    cod:
      - databaseName: "{{ deployment_id }}-cod"
      - {} # empty dict to use the defaults

  tasks:
    - name: ensure presence of CDP Environment
      include_role:
        name: cdp_cod
      vars:
        deployment_id: goes-aws-test
```
