# CDP ID Broker

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install boto boto3`
- `pip install cdpcli==0.9.7`

## Example Playbook

```yml
---
- name: REGISTER ID BROKER MAPPINGS
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    cdp:
      id_broker_mappings:
        # defaults to new ID Broker role
        #id_broker_role: "arn:aws:iam::00109:role/GOES_IDBROKER_ROLE"

        # defaults to new Datalake role
        #datalake_role: "arn:aws:iam::000109:role/GOES_DATALAKE_ADMIN_ROLE"

        # defaults to new Ranger role
        #ranger_role: "arn:aws:iam::000109:role/GOES_RANGER_AUDIT_ROLE"

        # defaults to no. Maps the group you specified in iam[0] to the Datalake Role
        map_group_to_datalake_role: yes

        mappings: []
        #   - accessorCrn: "crn:altus:iam:us-west-1:12a0079b-1591-4ca0-b"
        #     role: "arn:aws:iam::000109:role/SOME_ROLE"

  tasks:
    - name: ensure presende of CDP Environment
      include_role:
        name: cdp_idbroker
      vars:
        deployment_id: cdp-20200331
```
