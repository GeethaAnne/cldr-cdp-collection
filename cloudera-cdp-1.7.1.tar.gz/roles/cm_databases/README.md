# CM databases

Ansible roles for automating the creation of databases and users required by mypassword Manager on any of the following RDBMS:

- MySQL
- MariaDB
- PGSQL (not implemented)
- Oracle (not implemented)

Assumes the database is on the host Ansible is connected to, and that credentials are stored in `~/.my.cnf` as that will make the Role execution idempotent.

## Requirements

- Ansible v2.8.5.
- the RDBMS is already up and running on target host.
- credentials stored in `~/.my.cnf`.

## Role Variables

- `rdbms_type`: any of `mysql`, `oracle`, `pgsql`.
- `db_list`: a list of dicts to pass database name and users, see example.

## Dependencies

## Example Playbook

```yml
---
- name: CREATE CM DATABASES
  hosts: db_server
  become: yes
  gather_facts: no
  vars:
    db:
      type: mysql
      list:
        - name: scm
          user: scm
          pass: mypassword
        - name: amon
          user: amon
          pass: mypassword
        - name: rman
          user: rman
          pass: mypassword
        - name: metastore
          user: hive
          pass: mypassword
        - name: hue
          user: hue
          pass: mypassword
        - name: oozie
          user: oozie
          pass: mypassword
        - name: efm
          user: efm
          pass: mypassword
        - name: nifireg
          user: nifireg
          pass: mypassword
        - name: registry
          user: registry
          pass: mypassword
        - name: streamsmsgmgr
          user: streamsmsgmgr
          pass: mypassword
        - name: ranger
          user: ranger
          pass: mypassword


  tasks:
    - name: create CM databases
      include_role:
        name: cm_databases
      vars:
        rdbms_type: "{{ db.type }}"
        db_list: "{{ db.list }}"

```
