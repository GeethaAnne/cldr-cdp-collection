# CDP Identity and Access Management - Group

A role for creating CDP IAM groups. This role is used to define any ad-hoc group; no predetermined resource role targets
are defined, for example.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_user_sync | bool | Flag indicating whether group membership is synced when a user logs in. | group.user_sync | `False`
iam_group_purge | bool | Flag indicating whether the role will replace the `users`, `roles`, and/or `resource_roles` values or add to any existing values. | group.purge | `False`
iam_group_users | list | A list of strings identifying the assigned users. The values can be either the user ID or CRN. | group.users |
iam_group_users_add_current_user | bool | Flag indicating if the current CDP user should be added to the assigned users. | group.add_current_user | `True`
iam_group_roles | list | A list of strings identifying the assigned roles. The values can be either short or long form; the former will be assigned the `iam_roles_prefix`. | group.roles |
iam_role_prefix | str | Prefix when normalizing the values in `iam_group_roles` | group.role_prefix | 'crn:altus:iam:us-west-1:altus:role:'
iam_group_resource_roles | list | A list of strings identifying the assigned resource roles. The values can be either short or long form; the former will be assigned the `iam_resource_role_prefix`. | group.resource_roles |
iam_resource_role_prefix | str | Prefix when normalizing the values in `iam_group_resource_roles` | group.resource_role_prefix | 'crn:altus:iam:us-west-1:altus:resourceRole:'

### Host Variables

None.

## Dependencies

None.

### Roles

- [cloudera.cdp.iam.common.users](../common/users/README.md)
- [cloudera.cdp.iam.common.roles](../common/roles/README.md)
- [cloudera.cdp.iam.common.resource_roles](../common/resource_roles/README.md)

## Example Playbook

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.group
      vars:
        iam_group_name: some-group
        iam_group_user_sync: yes
        iam_group_purge: yes
        iam_group_users: 
          - 8438b2e4-d183-4e0c-806f-55512d6125b4
          - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4
        iam_group_users_add_current_user: yes
        iam_group_roles:
          - IamUser
          - EnvironmentUser
          - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
        iam_group_resource_roles:
          - resource: an:example:Environment:crn:11223344ee-d183-4e0c-806f-5566889944
            role: crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin

- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    iam:
      adhoc_groups:
        - name: some-group
          user_sync: yes
          purge: yes
          add_current_user: yes
          users:
            - 8438b2e4-d183-4e0c-806f-55512d6125b4
            - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4 
          roles:
            - IamUser
            - EnvironmentUser
            - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
          resource_roles:
            - resource: an:example:Environment:crn:11223344ee-d183-4e0c-806f-5566889944
              role: crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin
  tasks:
    - include_role:
        name: cloudera.cdp.iam.group
      loop: "{{ iam.adhoc_groups }}"
      loop_control:
        loop_var: group    
```
