# CDP Identity and Access Management - Common, Group Users

A role for managing common tasks shared by all CDP IAM group users operations.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_users | list | A list of strings identifying the assigned users. The values can be either the user ID or CRN. | group.users |
iam_group_users_add_current_user | bool | Flag indicating if the current CDP user should be added to the assigned users. | group.add_current_user | `True`

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__iam_groups\[iam_group_name\]\['users'\] | list | A list of users.

If `iam_group_users` is blank or undefined and `iam_group_users_add_current_user` is `False`, the role will not set the
keyed entry above.

## Dependencies

None.

### Roles

- [cloudera.cdp.iam.common.groups](../common/groups/README.md)

## Example Playbook

Typically, this role is not called directly in a playbook, rather it is a building block within a main role.

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.roles
      vars:
        iam_group_users: 
          - 8438b2e4-d183-4e0c-806f-55512d6125b4
          - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4
        iam_group_users_add_current_user: yes

- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    iam:
      groups:
        - users:
            - 8438b2e4-d183-4e0c-806f-55512d6125b4
            - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4
          add_current_user: yes
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.users
      loop: "{{ iam.groups }}"
      loop_control:
        loop_var: group    
```
