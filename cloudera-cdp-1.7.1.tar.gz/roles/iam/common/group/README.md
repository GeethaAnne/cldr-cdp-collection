# CDP Identity and Access Management - Common, Group

A role for managing common tasks shared by all CDP IAM group operations.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_name | str | The name for the group. | group.name | _Mandatory_

### Host Variables

Variable | Type | Description
--- | --- | --- 
__iam_groups\[iam_group_name\] | dict | An entry keyed on the `iam_group_name`.

## Dependencies

None.

### Roles

None.

## Example Playbook

Typically, this role is not called directly in a playbook, rather it is a building block within a main role.

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.group
      vars:
        iam_group_name: some-group

- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    iam:
      adhoc_groups:
        - name: some-group
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.group
      loop: "{{ iam.adhoc_groups }}"
      loop_control:
        loop_var: group    
```
