# CDP Identity and Access Management - Common, Group Roles

A role for managing common tasks shared by all CDP IAM group role operations.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_roles | list | A list of strings identifying the assigned roles. The values can be either short or long form; the former will be assigned the `iam_roles_prefix`. | group.roles |
iam_role_prefix | str | Prefix when normalizing the values in `iam_group_roles` | group.role_prefix | 'crn:altus:iam:us-west-1:altus:role:'

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__iam_groups\[iam_group_name\]\['roles'\] | list | A list of normalized roles.

If `iam_group_roles` is blank or undefined, the role will not set the keyed entry above.

## Dependencies

None.

### Roles

- [cloudera.cdp.iam.common.groups](../common/groups/README.md)

## Example Playbook

Typically, this role is not called directly in a playbook, rather it is a building block within a main role.

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.roles
      vars:
        iam_group_roles: 
          - IamUser
          - EnvironmentUser
          - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin

- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    iam:
      groups:
        - roles:
            - IamUser
            - EnvironmentUser
            - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.roles
      loop: "{{ iam.groups }}"
      loop_control:
        loop_var: group    
```
