# CDP Identity and Access Management - Common, Group Resource Roles

A role for managing common tasks shared by all CDP IAM group resource role operations.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_resource_roles | list | A list of strings identifying the assigned resource roles. The values can be either short or long form; the former will be assigned the `iam_resource_role_prefix`. | group.resource_roles |
iam_resource_role_prefix | str | Prefix when normalizing the values in `iam_group_resource_roles` | group.resource_role_prefix | 'crn:altus:iam:us-west-1:altus:resourceRole:'

Note that the role also accepts and/or has requirements for the variables defined in its dependent roles. 

### Host Variables

The role sets the following values on the host.
 
Variable | Type | Description
--- | --- | --- 
__iam_groups\[iam_group_name\]\['resource_roles'\] | list | A list of assignments, defined as a pair of variables, `resource` and `role`.

If `iam_group_resource_roles` is blank or undefined, the role will not set the entry above.

## Dependencies

The role will only normalize the `roles` for the assignments. The caller of the role must ensure that the `resource` as
normalized prior.

### Roles

- [cloudera.cdp.iam.common.groups](../common/groups/README.md)

## Example Playbook

Typically, this role is not called directly in a playbook, rather it is a building block within a main role.

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.resource_roles
      vars:
        iam_group_resource_roles: 
          - resource: an:CRN:to:an:example:Environment:resource
            role: ODAdmin
          - resource: an:CRN:to:an:example:Environment:resource
            role: crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin

- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    iam:
      groups:
        - resource_roles:
            - resource: an:CRN:to:an:example:Environment:resource
              role: ODAdmin
            - resource: an:CRN:to:an:example:Environment:resource
              role: crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin
  tasks:
    - include_role:
        name: cloudera.cdp.iam.common.resource_roles
      loop: "{{ iam.groups }}"
      loop_control:
        loop_var: group    
```
