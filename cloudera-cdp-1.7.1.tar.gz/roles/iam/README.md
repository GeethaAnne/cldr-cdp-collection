# CDP IAM

A set of "opinionated" roles for setting up CDP IAM groups. 

The entry points for this set are the [group](group/README.md) and [environment](environment/README.md) roles, both of 
which in turn use the [common](../common/README.md) roles.

These roles will normalize short form entries, such as role names, to their long forms, as well as provide other 
convenience when manipulating groups within CDP.

## Requirements

This set of roles requires the following collections:

. `cloudera.cdp`

The Python environment for the roles, in aggregate, requires:
 
- ansible >= 2.10
- cdpcli >= 0.9.15

Proper CDP credentials, e.g. `CDP_PROFILE`, must be available to the Ansible working environment as required by the 
underlying module.

## Role Variables

Each role requires a set of variables; some variables are shared. For details on each, please see the README for the 
given role.

Below is the full set, in "nested" form, of configuration variables used by this suite of roles. Note that the 
declaration of the `group` configuration container is often handled by a `loop_var`. See the [Example Playbook](#example-playbook).

```yaml
env:
  name:
group:
  name:
  user_sync:
  purge:
  users:
  add_current_user:
  roles:
  role_prefix:
  resource_roles:
  resource_role_prefix:
```

## Dependencies

- `pip install ansible`
- `pip install cdpcli`

## Example Playbook

Create a CDP IAM group for any configuration, i.e. ad-hoc. This is a generalized form of using this set of roles.

```yaml
- name: Create a single ad-hoc CDP IAM group
  hosts: localhost
  connection: local
  gather_facts: no
  become: no
  collections:
    - cloudera.cdp
  vars:
    # There are two means of setting a role variable - by 'flat' name or by 'nested' name
    # The variable below demonstrate the 'flat' mode of operation. 'Flat' overrides 'nested'.
    iam_group_users_add_current_user: no

    # The following are examples of 'nested' variables.
    iam:
      ad_hoc_groups:
        - name: example-group-1
          add_current_user: yes   # This is overridden by the 'flat' variable above
          purge: yes
          users:
            - 234564-6c9c-404c-8474-74be50fee4r5
          roles:
            - IamUser             # These two roles will be normalized to their CRN, i.e. long form
            - EnvironmentUser
          resource_roles:
            - resource: crn:altus:iam:us-west-1:558bc1d2-8867-4357-8524-311d51259233:user:90b5b89f-0739-4dbd-8b2e-1234456788
              role: IamGroupAdmin
  tasks:
    - name: Set up the ad-hoc groups
      include_role:
        name: iam.group
      loop: "{{ iam.ad_hoc_groups }}"
      loop_control:
        loop_var: group           # Expose each set of configurations in the `group` variable
```

The set also has a specialized role for configuring IAM groups for a given environment, e.g. administration groups. The
role uses the defined environment name as the resource target for any resource role assignments. This could be performed
by the generalized `group` role by setting the `resource` parameter directly; the `environment` role handles the 
CRN lookup for the environment and handles other bookkeeping.
 
```yaml
- name: Configure an environment IAM group
  hosts: localhost
  connection: local
  gather_facts: no
  become: no
  collections:
    - cloudera.cdp
  vars:
    env:
      name: preexisting-environment
    iam:
      admin_groups:
        - name: admin-1
          add_current_user: yes
          roles:
            - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
          resource_roles:
            - crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin
  tasks:
    - name: Set up the admin groups
      include_role:
        name: iam.environment
      loop: "{{ iam.admin_groups }}"
      loop_control:
        loop_var: group
```
