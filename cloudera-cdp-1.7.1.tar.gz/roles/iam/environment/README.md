# CDP Identity and Access Management - Environment Group

A role for creating CDP IAM groups specific to an Environment. This role is commonly used to define administrative 
group(s) for an Environment.  Specifically, the role sets the Environment as the target for any resource roles.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
iam_group_env_name | str | The name of the Environment. The role will validate that the Environment exists. | env.name | _Mandatory_
iam_group_users | list | A list of strings identifying the assigned users. The values can be either the user ID or CRN. | group.users |
iam_group_users_add_current_user | bool | Flag indicating if the current CDP user should be added to the assigned users. | group.add_current_user | `True`
iam_group_roles | list | A list of strings identifying the assigned roles. The values can be either short or long form; the former will be assigned the `iam_roles_prefix`. | group.roles |
iam_role_prefix | str | Prefix when normalizing the values in `iam_group_roles` | group.role_prefix | 'crn:altus:iam:us-west-1:altus:role:'
iam_group_resource_roles | list | A list of strings identifying the assigned resource roles. The values can be either short or long form; the former will be assigned the `iam_resource_role_prefix`. | group.resource_roles |
iam_resource_role_prefix | str | Prefix when normalizing the values in `iam_group_resource_roles` | group.resource_role_prefix | 'crn:altus:iam:us-west-1:altus:resourceRole:'
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'
env_name | str | The readable name of the CDP environment | env.name | `env_deployment`

### Host Variables

None.

## Dependencies

While the role depends on [cloudera.cdp.iam.common.resource_roles](../common/resource_roles/README.md), the role 
calls this dependency directly after converting the `iam_group_resource_roles` values into proper key/value pairs
that reference the specified environment; it does not employ the standard dependency resolution process.

### Roles

- [cloudera.cdp.iam.common.users](../common/users/README.md)
- [cloudera.cdp.iam.common.roles](../common/roles/README.md)
- [cloudera.cdp.iam.common.resource_roles](../common/resource_roles/README.md)

## Example Playbook

This role is typically used to define administrative groups assigned to an Environment.

```yml
---
- name: Direct (i.e. flat) variable assignment
  hosts: localhost
  connection: local
  gather_facts: no
  tasks:
    - include_role:
        name: cloudera.cdp.iam.environment
      vars:
        env_name: example-environment
        iam_group_name: the-admin-group
        iam_group_users: 
          - 8438b2e4-d183-4e0c-806f-55512d6125b4
          - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4
        iam_group_users_add_current_user: yes
        iam_group_roles:
          - IamUser
          - EnvironmentUser
          - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
        iam_group_resource_roles:
          - ODAdmin
          - ODUser
          - crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin


- name: Nested variable assignment (note the name of the 'loop_var')
  hosts: localhost
  connection: local
  gather_facts: no
  vars:
    env:
      name: example-environment
    iam:
      admin_groups:
        - name: the-admin-group
          add_current_user: yes
          users:
            - 8438b2e4-d183-4e0c-806f-55512d6125b4
            - an:example:User:crn:8438b2e4-d183-4e0c-806f-55512d6125b4 
          roles:
            - IamUser
            - EnvironmentUser
            - crn:altus:iam:us-west-1:altus:role:EnvironmentAdmin
          resource_roles:
            - ODAdmin
            - ODUser
            - crn:altus:iam:us-west-1:altus:resourceRole:IamGroupAdmin
      other_groups:
        - name: some-other-group
          roles:
            - IamUser
            - EnvironmentUser
  tasks:
    - include_role:
        name: cloudera.cdp.iam.environment
      loop: "{{ iam.admin_groups }}"
      loop_control:
        loop_var: group    
```
