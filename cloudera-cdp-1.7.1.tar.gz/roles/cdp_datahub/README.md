# CDP Datahub

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install cdpcli`

## Example Playbook

```yml
---
- name: DEPLOY CDP DATAHUB
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    enddate: '25122020'
    cdp:
      datahub:
        - cluster:
            clusterName: "{{ deployment_id }}-fm"
            clusterDefinitionName: "7.1.0 - Flow Management Light Duty for AWS"
            clusterTemplateName: "7.1.0 - Flow Management Light Duty with Apache NiFi, Apache NiFi Registry"
            availability_type: "NONE" # defaults to NONE
            tags:
              enddate: "{{ enddate }}"
              deploy_tool: Foundry

        - cluster:
            clusterName: "{{ deployment_id }}-all"
            clusterTemplateName: "7.1.0 - All Services 2"
            instanceGroups:
              - nodeCount: 1
                  instanceGroupName: master
                  instanceGroupType: CORE
                  instanceType: m5.4xlarge
                  rootVolumeSize: 100
                  recoveryMode: MANUAL
                  recipeNames: []
                  volumeEncryption:
                  enableEncryption: false
                  encryptionKey: ""
                  attachedVolumeConfiguration:
                  - volumeSize: 100
                      volumeCount: 1
                      volumeType: standard

              - nodeCount: 1
                  instanceGroupName: master2
                  instanceGroupType: CORE
                  instanceType: m5.4xlarge
                  rootVolumeSize: 100
                  recoveryMode: MANUAL
                  recipeNames: []
                  volumeEncryption:
                  enableEncryption: false
                  encryptionKey: ""
                  attachedVolumeConfiguration:
                  - volumeSize: 100
                      volumeCount: 1
                      volumeType: standard

              - nodeCount: 3
                  instanceGroupName: worker
                  instanceGroupType: CORE
                  instanceType: m5.4xlarge
                  rootVolumeSize: 100
                  recoveryMode: MANUAL
                  recipeNames: []
                  volumeEncryption:
                  enableEncryption: false
                  encryptionKey: ""
                  attachedVolumeConfiguration:
                  - volumeSize: 100
                      volumeCount: 1
                      volumeType: standard

              - nodeCount: 1
                  instanceGroupName: gateway
                  instanceGroupType: GATEWAY
                  instanceType: m5.2xlarge
                  rootVolumeSize: 100
                  recoveryMode: MANUAL
                  recipeNames: []
                  volumeEncryption:
                  enableEncryption: false
                  encryptionKey: ""
                  attachedVolumeConfiguration:
                  - volumeSize: 100
                      volumeCount: 1
                      volumeType: standard

            tags:
              enddate: "{{ enddate }}"
              deploy_tool: Foundry

  tasks:
    - name: ensure presence of CDP Datahub
      include_role:
        name: cdp_datahub
      vars:
        deployment_id: goes-aws-test
```
