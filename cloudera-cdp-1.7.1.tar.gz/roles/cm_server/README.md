# CM Server

Ansible roles for automating the configuration of Cloudera Manager server.

## Requirements

- Ansible v2.8.5

## Role Variables

See example below.

## Dependencies

## Example Playbook

```yml
---
- name: PROVISION CMS AND CLUSTER
  hosts: cm_server
  become: yes
  tasks:
    - name: Install cm server and deploy cluster template
      include_role:
        name: cm_server

```
