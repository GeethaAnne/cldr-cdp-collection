# Common - CDP

A set of roles used to share variables and defaults for CDP services among implementing roles. 

- [datalake](./datalake/README.md)
- [environment](./environment/README.md)
- [idbroker](./idbroker/README.md)

## Requirements

- ansible >= 2.10

## Role Variables

For details on each role and its variables and defaults, please see the README for the 
given role.

Below is the full set, in "nested" form, of configuration variables used by this suite of roles. 

```yaml
datalake:
  storage_bucket:
  storage_path:
  storage_path_default:
env:
  deployment:
  deployment_prefix:
  name:
  tags:
  cloud:
  region:
  log_bucket:
  log_path:
  log_path_default:
  idbroker_role:
  idbroker_role_suffix:
```

## Dependencies

These roles require `gather_facts: yes` to generate the `env_deployment` default.
