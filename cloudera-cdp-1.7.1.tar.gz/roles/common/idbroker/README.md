# Common - CDP ID Broker

A role that defines the shared variables and defaults for CDP ID Broker mappings.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_idbroker_role | str | The name of the IAM role for ID Broker. The role will lookup this name in the cloud provider, and if not found, will create the IAM role. | env.idbroker_role | `env_deployment` + `env_idbroker_role_suffix`
env_idbroker_role_suffix | str | The default suffix for the ID Broker IAM role. | env.idbroker_role_suffix | '-ID-BROKER'

### Host Variables

None.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](./environment/README.md)
