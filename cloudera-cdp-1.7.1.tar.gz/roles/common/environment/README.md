# Common - CDP Environment

A role that defines the shared variables and defaults for CDP Environments.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
env_deployment | str | The "primary key" for the CDP installation | env.deployment | `env_deployment_prefix` + `ansible_date_time.epoch`
env_deployment_prefix | str | Prefix when auto-generating `env_deployment` | env.deployment_prefix | 'cdp-'
env_name | str | The readable name of the CDP environment | env.name | `env_deployment`
env_tags | dict | Metadata tags assigned to cloud and CDP resources | env.tags | None
env_cloud | str | Cloud provider for the environment. Options are `aws` and `azure`. | env.cloud | None - mandatory variable
env_region | str | Cloud provider-specific region for the environment | env.region |  For `env_cloud: aws`, `us-east-1`, for `env_cloud: azure`, `eastus`  
env_log_bucket | str | Cloud provider-specific log location container for the environment | env.log_bucket | `env_deployment`
env_log_path | str | Cloud provider-specific log location path or key for the environment | env.log_path | `env_log_path_default`
env_log_path_default | str | Default log location path | env.log_path_default | For `env_cloud: aws`, '/datalake/logs'. For `env_cloud: azure`, 'TKTK'

### Host Variables

None.

## Dependencies

The role must be run with `gather_facts: yes` to generate values for `ansible_date_time.epoch`, which is used to 
generate the default value for `env_enddate`. 

### Roles

- None
