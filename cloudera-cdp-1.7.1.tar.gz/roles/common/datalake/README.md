# Common - CDP Datalake

A role that defines the shared variables and defaults for CDP Datalakes.

## Requirements

- ansible >= 2.10

## Role Variables

Variables can be set either by flat configuration or an alternate nested- or dictionary-based configuration.

Variable | Type | Description | Mapping | Default
---| --- | --- | --- | ---
datalake_storage_bucket | str | The name of the cloud-specific storage bucket for the Datalake. | datalake.storage_bucket | `env_deployment`
datalake_storage_path | str | Cloud-specific path to the Datalake directory within the storage bucket. | datalake.storage_path | `datalake_storage_path_default`
datalake_storage_path_default | str | The default path for the Datalake directory | datalake.storage_path_default | AWS: `/data`

### Host Variables

None.

## Dependencies

### Roles

- [cloudera.cdp.common.environment](./environment/README.md)
