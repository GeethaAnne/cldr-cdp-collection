# CDP IAM

Ansible Role to manage CDP IAM

## Requirements

- Ansible 2.9+
- CDP, AWS or Azure credentials loaded as environment variables.

## Role Variables

See below example.

## Dependencies

- `pip install cdpcli`

## Example Playbook

```yml
---
- name: DEPLOY CDP ENVIRONMENT
  hosts: localhost
  connection: local
  become: no
  gather_facts: no
  vars:
    iam:
      - group_name: mygroup1
        users:
            - "crn:altus:iam:us-west-1:-8524-:user:f6a7640d--404c--74be5053ee10"
            - "crn:altus:iam:us-west-1:-8524-:user:197e7a24--46a0--11522fb8421d"
            - "crn:altus:iam:us-west-1:-8524-:user:c40446fa--4d50--2a95057a7402"
            - "crn:altus:iam:us-west-1:-8524-:user:32885d2e--4170--39380ff508e0"  
        force_users: yes # will delete users if set to yes
        add_self: yes # lookup the current user, and add it to the group
        roles:
            - PowerUser
            - IamViewer
        resource_roles:
            - DWAdmin
            - DEUser
            - MLAdmin
        # env_name:  # defaults to cdp.env.name

  tasks:
    - name: configure CDP groups and users
      include_role:
        name: cdp_iam

```

## Issues

1. list-users might return partial list due to paging, thus removing users might not remove all users.
