# OS Config

Ansible roles for automating the configuration of the OS.

## Requirements

- Ansible v2.8.5

## Role Variables

See example below.

## Dependencies

## Example Playbook

```yml
---
- name: CONFIG HOSTS FOR CDP DC
  hosts: all
  gather_facts: yes
  become: yes
  tasks:
    - name: configure OS for all servers
      include_role:
        name: cdpdc_os_config
      vars:
        _cloud_provider: "{{ instances.cloud }}"

```
