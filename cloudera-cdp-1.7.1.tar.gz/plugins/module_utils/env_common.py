#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
For shared retrieval of Environment objects.
"""

from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import parse_client_error, handle_cdp_error
from ansible.utils.display import Display
from cdpcli.exceptions import ClientError

PAGE_SIZE = 50

display = Display()


def gather_idbroker_mappings(client, environment):
        results = dict()

        mappings = _get_id_broker_mappings(client, environment)
        if mappings is not None:
            results.update(**mappings)

        syncStatus = get_id_broker_sync(client, environment)
        if syncStatus is not None:
            results.update(syncStatus=syncStatus)

        return results


@handle_cdp_error('NOT_FOUND', None)
def _get_id_broker_mappings(client, environment):
    return client.get_id_broker_mappings(environmentName=environment)


def get_id_broker_sync(client, environment):
    try:
        return client.get_id_broker_mappings_sync_status(environmentName=environment)
    except ClientError as e:
        error = parse_client_error(e)
        if error['status_code'] == '400' and error['msg'] == 'INVALID_ARGUMENT':
            display.warning('Environment, %s, has no associated datalake' % environment)
        elif error['status_code'] == '404' and error['msg'] == 'NOT_FOUND':
            display.warning('No mappings found for environment, %s' % environment)
        else:
            raise e

    return None
