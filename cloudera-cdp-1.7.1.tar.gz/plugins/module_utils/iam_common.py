#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
For shared retrieval of IAM objects.
"""

from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import handle_cdp_error

PAGE_SIZE = 50


def gather_groups(client, group_names=None):
    groups = []
    results = _list_groups(client, group_names=group_names)
    while 'nextToken' in results:
        list(map(lambda grp: grp.update(users=gather_membership(client, grp['crn'])), results['groups']))
        list(map(lambda grp: grp.update(roles=gather_roles(client, grp['crn'])), results['groups']))
        list(map(lambda grp: grp.update(resource_roles=gather_resource_roles(client, grp['crn'])), results['groups']))
        groups.extend(results['groups'])
        results = _list_groups(client, starting_token=results['nextToken'])
    if 'groups' in results:
        list(map(lambda grp: grp.update(users=gather_membership(client, grp['crn'])), results['groups']))
        list(map(lambda grp: grp.update(roles=gather_roles(client, grp['crn'])), results['groups']))
        list(map(lambda grp: grp.update(resource_roles=gather_resource_roles(client, grp['crn'])), results['groups']))
        groups.extend(results['groups'])
    return groups


@handle_cdp_error('NOT_FOUND', list())
def _list_groups(client, group_names=None, starting_token=None):
    if starting_token:
        return client.list_groups(pageSize=PAGE_SIZE, startingToken=starting_token)
    elif group_names:
        if not isinstance(group_names, list):
            group_names = [group_names]
        return client.list_groups(pageSize=PAGE_SIZE, groupNames=group_names)
    else:
        return client.list_groups(pageSize=PAGE_SIZE)


def gather_membership(client, group_name):
    members = []
    results = _list_membership(client, group_name)
    while 'nextToken' in results:
        members.extend(results['memberCrns'])
        results = _list_membership(client, group_name, starting_token=results['nextToken'])
    if 'memberCrns' in results:
        members.extend(results['memberCrns'])
    return members


@handle_cdp_error('NOT_FOUND', list())
def _list_membership(client, group_name, starting_token=None):
    if starting_token:
        return client.list_group_members(pageSize=PAGE_SIZE, groupName=group_name, startingToken=starting_token)
    else:
        return client.list_group_members(pageSize=PAGE_SIZE, groupName=group_name)


def gather_roles(client, group_name):
    roles = []
    results = _list_roles(client, group_name)
    while 'nextToken' in results:
        roles.extend(results['roleCrns'])
        results = _list_roles(client, group_name, starting_token=results['nextToken'])

    if 'roleCrns' in results:
        roles.extend(results['roleCrns'])
    return roles


@handle_cdp_error('NOT_FOUND', list())
def _list_roles(client, group_name, starting_token=None):
    if starting_token:
        return client.list_group_assigned_roles(pageSize=PAGE_SIZE, groupName=group_name, starting_token=starting_token)
    else:
        return client.list_group_assigned_roles(pageSize=PAGE_SIZE, groupName=group_name)


def gather_resource_roles(client, group_name):
    resource_roles = []
    results = _list_resource_roles(client, group_name)
    while 'nextToken' in results:
        resource_roles.extend(results['resourceAssignments'])
        results = _list_resource_roles(client, group_name, starting_token=results['nextToken'])

    if 'resourceAssignments' in results:
        resource_roles.extend(results['resourceAssignments'])
    return resource_roles


@handle_cdp_error('NOT_FOUND', list())
def _list_resource_roles(client, group_name, starting_token=None):
    if starting_token:
        return client.list_group_assigned_resource_roles(pageSize=PAGE_SIZE, groupName=group_name,
                                                         starting_token=starting_token)
    else:
        return client.list_group_assigned_resource_roles(pageSize=PAGE_SIZE, groupName=group_name)
