#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2019, Cloudera
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

import cm_client
from cm_client.rest import ApiException
from collections import namedtuple
import json
import time
import sys

# Static variables
DEFAULT_RESULT = ""  # if you have nothing to say, say nothing.
REDACTED_LIST = ['passphrase', 'password', 'private_key']
REDACT_WORD = "REDACTED"

#
# Builders
#


def stringify_error(e):
    if isinstance(e, ApiException):
        return {"e.status": e.status, "e.reason": e.reason, "e.body": e.body}
    else:
        return str(e)


def build_ApiClient(d):
    """
    Build a ApiClient obj from a dict

    Args:
        dict

    Return:
        ApiClient
    """
    cm_client.configuration.username = d["username"]
    cm_client.configuration.password = d["password"]
    cm_client.configuration.verify_ssl = d['verify_ssl']
    cm_host_api_url = "%s://%s:%s%s" % (
        d['protocol'],
        d["host"],
        d["port"],
        d["path"])

    return cm_client.ApiClient(cm_host_api_url)


def build_ApiServiceList(d):
    """
    Builds a ApiServiceList obj from a dict

    Args:
        dict

    Returns:
        ApiServiceList
    """
    api = cm_client.ApiServiceList(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [build_ApiService(x) for x in v]

    return api


def build_ApiClusterTemplate(d):
    """
    Builds a ApiClusterTemplate obj from a json dict

    Args:
        dict

    Returns:
        ApiClusterTemplate
    """
    api = cm_client.ApiClusterTemplate(**d)

    for k, v in d.items():
        if k == 'products':
            api.products = [cm_client.ApiProductVersion(**x) for x in v]
        if k == 'services':
            api.services = [build_ApiClusterTemplateService(x) for x in v]
        if k == 'host_templates':
            api.host_templates = [
                cm_client.ApiClusterTemplateHostTemplate(**x) for x in v]
        if k == 'instantiator':
            api.instantiator = build_ApiClusterTemplateInstantiator(v)
        if k == 'cluster_spec':
            api.cluster_spec = build_ApiClusterTemplateClusterSpec(v)

    return api


def build_ApiClusterTemplateClusterSpec(d):
    """
    Builds a ApiClusterTemplateClusterSpec obj from a json dict

    Args:
        dict

    Returns:
        ApiClusterTemplateClusterSpec
    """
    api = cm_client.ApiClusterTemplateClusterSpec(**d)

    for k, v in d.items():
        if k == 'data_context_refs':
            api.data_context_refs = [
                cm_client.ApiDataContextRef(**x) for x in v]

    return api


def build_ApiClusterTemplateService(d):
    """
    Builds a ApiClusterTemplateService obj from a json dict

    Args:
        dict

    Returns:
        ApiClusterTemplateService
    """
    api = cm_client.ApiClusterTemplateService(**d)

    for k, v in d.items():
        if k == 'service_configs':
            api.service_configs = [
                cm_client.ApiClusterTemplateConfig(**x) for x in v]
        if k == 'role_config_groups':
            api.role_config_groups = [
                build_ApiClusterTemplateRoleConfigGroup(x) for x in v]
        if k == 'roles':
            api.roles = [cm_client.ApiClusterTemplateRole(**x) for x in v]

    return api


def build_ApiClusterTemplateRoleConfigGroup(d):
    """
    Builds a ApiClusterTemplateRoleConfigGroup obj from a json dict

    Args:
        dict

    Returns:
        ApiClusterTemplateRoleConfigGroup
    """
    api = cm_client.ApiClusterTemplateRoleConfigGroup(**d)

    for k, v in d.items():
        if k == 'configs':
            api.configs = [cm_client.ApiClusterTemplateConfig(**x) for x in v]

    return api


def build_ApiClusterTemplateInstantiator(d):
    """
    Builds a ApiClusterTemplateInstantiator obj from a json dict

    Args:
        dict

    Returns:
        ApiClusterTemplateInstantiator
    """
    api = cm_client.ApiClusterTemplateInstantiator(**d)

    for k, v in d.items():
        if k == 'hosts':
            api.hosts = [cm_client.ApiClusterTemplateHostInfo(**x) for x in v]
        if k == 'variables':
            api.variables = [
                cm_client.ApiClusterTemplateVariable(**x) for x in v]
        if k == 'role_config_groups':
            api.role_config_groups = [
                cm_client.ApiClusterTemplateRoleConfigGroupInfo(**x) for x in v]
        if k == 'enable_kerberos':
            api.enable_kerberos = [
                cm_client.ApiConfigureForKerberosArguments(**x) for x in v]

    return api


def build_ApiService(d):
    """
    Builds a ApiService obj from a json dict

    Args:
        dict

    Returns:
        ApiService
    """
    api = cm_client.ApiService(**d)

    for k, v in d.items():
        if k == 'config':
            api.config = build_ApiServiceConfig(v)
        if k == 'roles':
            api.roles = [build_ApiRole(x) for x in v]
        if k == 'role_config_groups':
            api.role_config_groups = [build_ApiRoleConfigGroup(x) for x in v]
        if k == 'replication_schedules':
            api.replication_schedules = [
                build_ApiReplicationSchedule(x) for x in v]
        if k == 'snapshot_policies':
            api.snapshot_policies = [build_ApiSnapshotPolicy(x) for x in v]
        # below are ReadOnly prop so you shouldn't set them
        # if k == 'cluster_ref':
        #     api.cluster_ref = cm_client.ApiClusterRef(**v)
        # if k == 'service_state':
        #     api.service_state = cm_client.ApiServiceState(**v)
        # if k == 'health_summary':
        #     api.health_summary = cm_client.ApiHealthSummary(**v)
        # if k == 'config_stale':
        #     api.config_stale = v
        # if k == 'config_staleness_status':
        #     api.config_staleness_status = cm_client.ApiConfigStalenessStatus(**v)
        # if k == 'client_config_staleness_status':
        #     api.client_config_staleness_status = cm_client.ApiConfigStalenessStatus(**v)
        # if k == 'health_checks':
        #     api.health_checks = [build_ApiHealthCheck(x) for x in v]
        # if k == 'service_url':
        #     api.service_url = v
        # if k == 'role_instances_url':
        #     api.role_instances_url = v
        # if k == 'maintenance_mode':
        #     api.maintenance_mode = v
        # if k == 'maintenance_owners':
        #     api.maintenance_owners = v
        # if k == 'entity_status':
            # api.entity_status = v

    return api


def build_ApiSnapshotPolicy(d):
    """
    Builds a ApiSnapshotPolicy obj from a json dict

    Args:
        dict

    Returns:
        ApiSnapshotPolicy
    """
    api = cm_client.ApiSnapshotPolicy(**d)

    for k, v in d.items():
        if k == 'hbase_arguments':
            api.hbase_arguments = build_ApiHBaseSnapshotPolicyArguments(v)
        if k == 'hdfs_arguments':
            api.hdfs_arguments = cm_client.ApiHdfsSnapshotPolicyArguments(**v)
        if k == 'last_command':
            api.last_command = build_ApiSnapshotCommand(v)
        if k == 'last_successful_command':
            api.last_successful_command = build_ApiSnapshotCommand(v)

    return api


def build_ApiHBaseSnapshotPolicyArguments(d):
    """
    Builds a ApiHBaseSnapshotPolicyArguments obj from a json dict

    Args:
        dict

    Returns:
        ApiHBaseSnapshotPolicyArguments
    """
    api = cm_client.ApiHBaseSnapshotPolicyArguments(**d)

    for k, v in d.items():
        if k == 'storage':
            api.storage = cm_client.Storage(**v)

    return api


def build_ApiSnapshotCommand(d):
    """
    Builds a ApiSnapshotCommand obj from a json dict

    Args:
        dict

    Returns:
        ApiSnapshotCommand
    """
    api = cm_client.ApiSnapshotCommand(**d)

    for k, v in d.items():
        if k == 'cluster_ref':
            api.cluster_ref = cm_client.ApiClusterRef(**v)
        if k == 'service_ref':
            api.service_ref = cm_client.ApiServiceRef(**v)
        if k == 'role_ref':
            api.role_ref = cm_client.ApiRoleRef(**v)
        if k == 'host_ref':
            api.host_ref = cm_client.ApiHostRef(**v)
        if k == 'parent':
            api.parent = build_ApiCommandList(v)
        if k == 'children':
            api.children = build_ApiCommandList(v)
        if k == 'hbase_result':
            api.hbase_result = build_ApiHBaseSnapshotResult(v)
        if k == 'hdfs_result':
            api.hdfs_result = build_ApiHdfsSnapshotResult(v)

    return api


def build_ApiHBaseSnapshotResult(d):
    """
    Builds a ApiHBaseSnapshotResult obj from a json dict

    Args:
        dict

    Returns:
        ApiHBaseSnapshotResult
    """
    api = cm_client.ApiHBaseSnapshotResult(**d)

    for k, v in d.items():
        if k == 'created_snapshots':
            api.created_snapshots = [build_ApiHBaseSnapshot(x) for x in v]
        if k == 'deleted_snapshots':
            api.interval_unit = [build_ApiHBaseSnapshot(x) for x in v]
        if k == 'interval_unit':
            api.interval_unit = [build_ApiHBaseSnapshotError(x) for x in v]
        if k == 'interval_unit':
            api.interval_unit = [build_ApiHBaseSnapshotError(x) for x in v]

    return api


def build_ApiHdfsSnapshotResult(d):
    """
    Builds a ApiHdfsSnapshotResult obj from a json dict

    Args:
        dict

    Returns:
        ApiHdfsSnapshotResult
    """
    api = cm_client.ApiHdfsSnapshotResult(**d)

    for k, v in d.items():
        if k == 'created_snapshots':
            api.created_snapshots = [cm_client.ApiHdfsSnapshot(**x) for x in v]
        if k == 'deleted_snapshots':
            api.deleted_snapshots = [cm_client.ApiHdfsSnapshot(**x) for x in v]
        if k == 'creation_errors':
            api.creation_errors = [
                cm_client.ApiHdfsSnapshotError(**x) for x in v]
        if k == 'deletion_errors':
            api.deletion_errors = [
                cm_client.ApiHdfsSnapshotError(**x) for x in v]

    return api


def build_ApiHBaseSnapshot(d):
    """
    Builds a ApiHBaseSnapshot obj from a json dict

    Args:
        dict

    Returns:
        ApiHBaseSnapshot
    """
    api = cm_client.ApiHBaseSnapshot(**d)

    for k, v in d.items():
        if k == 'storage':
            v
            api.storage = cm_client.Storage()

    return api


def build_ApiHBaseSnapshotError(d):
    """
    Builds a ApiHBaseSnapshotError obj from a json dict

    Args:
        dict

    Returns:
        ApiHBaseSnapshotError
    """
    api = cm_client.ApiHBaseSnapshotError(**d)

    for k, v in d.items():
        if k == 'storage':
            v
            api.storage = cm_client.Storage()

    return api


def build_ApiReplicationSchedule(d):
    """
    Builds a ApiReplicationSchedule obj from a json dict

    Args:
        dict

    Returns:
        ApiReplicationSchedule
    """
    api = cm_client.ApiReplicationSchedule(**d)

    for k, v in d.items():
        if k == 'interval_unit':
            api.interval_unit = cm_client.ApiScheduleInterval(**v)
        if k == 'hdfs_arguments':
            api.hdfs_arguments = build_ApiHdfsReplicationArguments(v)
        if k == 'hive_arguments':
            api.hive_arguments = build_ApiHiveReplicationArguments(v)
        if k == 'hdfs_cloud_arguments':
            api.hdfs_cloud_arguments = build_ApiHdfsCloudReplicationArguments(
                v)
        if k == 'history':
            api.history = [build_ApiReplicationCommand(x) for x in v]
        if k == 'hive_cloud_arguments':
            api.hive_cloud_arguments = build_ApiHiveCloudReplicationArguments(
                v)

    return api


def build_ApiHdfsReplicationArguments(d):
    """
    Builds a ApiHdfsReplicationArguments obj from a json dict

    Args:
        dict

    Returns:
        ApiHdfsReplicationArguments
    """
    api = cm_client.ApiHdfsReplicationArguments(**d)

    for k, v in d.items():
        if k == 'source_service':
            api.source_service = cm_client.ApiServiceRef(**v)
        if k == 'replication_strategy':
            api.replication_strategy = cm_client.ReplicationStrategy(**v)

    return api


def build_ApiHiveReplicationArguments(d):
    """
    Builds a ApiHiveReplicationArguments obj from a json dict

    Args:
        dict

    Returns:
        ApiHiveReplicationArguments
    """
    api = cm_client.ApiHiveReplicationArguments(**d)

    for k, v in d.items():
        if k == 'source_service':
            api.source_service = cm_client.ApiServiceRef(**v)
        if k == 'table_filters':
            api.table_filters = [cm_client.ApiHiveTable(**x) for x in v]
        if k == 'hdfs_arguments':
            api.hdfs_arguments = build_ApiHdfsReplicationArguments(v)

    return api


def build_ApiHdfsCloudReplicationArguments(d):
    """
    Builds a ApiHdfsCloudReplicationArguments obj from a json dict

    Args:
        dict

    Returns:
        ApiHdfsCloudReplicationArguments
    """
    api = cm_client.ApiHdfsCloudReplicationArguments(**d)

    for k, v in d.items():
        if k == 'source_service':
            api.source_service = cm_client.ApiServiceRef(**v)
        if k == 'replication_strategy':
            api.replication_strategy = cm_client.ReplicationStrategy(**v)

    return api


def build_ApiReplicationCommand(d):
    """
    Builds a ApiReplicationCommand obj from a json dict

    Args:
        dict

    Returns:
        ApiReplicationCommand
    """
    api = cm_client.ApiReplicationCommand(**d)

    for k, v in d.items():
        if k == 'cluster_ref':
            api.cluster_ref = cm_client.ApiClusterRef(**v)
        if k == 'service_ref':
            api.service_ref = cm_client.ApiClusterRef(**v)
        if k == 'role_ref':
            api.role_ref = cm_client.ApiRoleRef(**v)
        if k == 'host_ref':
            api.host_ref = cm_client.ApiHostRef(**v)
        if k == 'parent':
            api.parent = build_ApiCommand(v)
        if k == 'children':
            api.children = build_ApiCommandList(v)
        if k == 'hdfs_result':
            api.hdfs_result = build_ApiHdfsReplicationResult(v)
        if k == 'hive_result':
            api.hive_result = build_ApiHiveReplicationResult(v)

    return api


def build_ApiCommand(d):
    """
    Builds a ApiCommand obj from a json dict

    Args:
        dict

    Returns:
        ApiCommand
    """
    api = cm_client.ApiCommand(**d)

    for k, v in d.items():
        if k == 'cluster_ref':
            api.cluster_ref = cm_client.ApiClusterRef(**v)
        if k == 'service_ref':
            api.service_ref = cm_client.ApiServiceRef(**v)
        if k == 'role_ref':
            api.role_ref = cm_client.ApiRoleRef(**v)
        if k == 'host_ref':
            api.host_ref = cm_client.ApiHostRef(**v)
        if k == 'parent':
            api.parent = build_ApiCommand(v)
        if k == 'children':
            api.children = build_ApiCommandList(v)

    return api


def build_ApiCommandList(d):
    """
    Builds a ApiCommandList obj from a json dict

    Args:
        dict

    Returns:
        ApiCommandList
    """
    api = cm_client.ApiCommandList(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [build_ApiCommand(x) for x in v]

    return api


def build_ApiHdfsReplicationResult(d):
    """
    Builds a ApiHdfsReplicationResult obj from a json dict

    Args:
        dict

    Returns:
        ApiHdfsReplicationResult
    """
    api = cm_client.ApiHdfsReplicationResult(**d)

    for k, v in d.items():
        if k == 'counters':
            api.counters = [
                cm_client.ApiHdfsReplicationCounter(**x) for x in v]

    return api


def build_ApiHiveReplicationResult(d):
    """
    Builds a ApiHiveReplicationResult obj from a json dict

    Args:
        dict

    Returns:
        ApiHiveReplicationResult
    """
    api = cm_client.ApiHiveReplicationResult(**d)

    for k, v in d.items():
        if k == 'tables':
            api.tables = [cm_client.ApiHiveTable(**x) for x in v]
        if k == 'impala_ud_fs':
            api.impala_ud_fs = [cm_client.ApiImpalaUDF(**x) for x in v]
        if k == 'hive_ud_fs':
            api.hive_ud_fs = [cm_client.ApiHiveUDF(**x) for x in v]
        if k == 'errors':
            api.errors = [cm_client.ApiHiveReplicationError(**x) for x in v]
        if k == 'data_replication_result':
            api.data_replication_result = build_ApiHdfsReplicationResult(v)

    return api


def build_ApiHiveCloudReplicationArguments(d):
    """
    Builds a ApiHiveCloudReplicationArguments obj from a json dict

    Args:
        dict

    Returns:
        ApiHiveCloudReplicationArguments
    """
    api = cm_client.ApiHiveCloudReplicationArguments(**d)

    for k, v in d.items():
        if k == 'source_service':
            api.source_service = cm_client.ApiServiceRef(**v)
        if k == 'table_filters':
            api.table_filters = [cm_client.ApiHiveTable(**x) for x in v]
        if k == 'hdfs_arguments':
            api.hdfs_arguments = build_ApiHdfsReplicationArguments(v)
        if k == 'replication_option':
            api.replication_option = cm_client.ReplicationOption()

    return api


def build_ApiRoleConfigGroupList(d):
    """
    Builds a ApiRoleConfigGroupList obj from a json dict

    Args:
        dict

    Returns:
        ApiRoleConfigGroupList
    """
    api = cm_client.ApiRoleConfigGroupList(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [build_ApiRoleConfigGroup(x) for x in v]

    return api


def build_ApiRoleConfigGroup(d):
    """
    Builds a ApiRoleConfigGroup obj from a json dict

    Args:
        dict

    Returns:
        ApiRoleConfigGroup
    """
    api = cm_client.ApiRoleConfigGroup(**d)

    for k, v in d.items():
        if k == 'config':
            api.config = build_ApiConfigList(v)
        # below are Read-Only
        if k == 'service_ref':
            api.service_ref = cm_client.ApiServiceRef(**v)

    return api


def build_ApiServiceConfig(d):
    """
    Builds a ApiServiceConfig obj from a json dict

    Args:
        dict

    Returns:
        ApiServiceConfig
    """
    api = cm_client.ApiServiceConfig(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [cm_client.ApiConfig(**x) for x in v]
        if k == 'role_type_configs':
            api.role_type_configs = [build_ApiRoleTypeConfig(x) for x in v]

    return api


def build_ApiRoleTypeConfig(d):
    """
    Builds a ApiRoleTypeConfig obj from a json dict

    Args:
        dict

    Returns:
        ApiRoleTypeConfig
    """
    api = cm_client.ApiRoleTypeConfig(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [cm_client.ApiConfig(**x) for x in v]

    return api


def build_ApiRole(d):
    """
    Builds a ApiRole obj from a json dict

    Args:
        dict

    Returns:
        ApiRole
    """
    api = cm_client.ApiRole(**d)

    for k, v in d.items():
        if k == 'host_ref':
            api.host_ref = cm_client.ApiHostRef(**v)
        if k == 'config':
            api.config = build_ApiConfigList(v)
        # below are read-only
        # if k == 'service_ref':
        #     api.service_ref = v
        # if k == 'role_state':
        #     api.role_state = v
        # if k == 'commission_state':
        #     api.commission_state = v
        # if k == 'health_summary':
        #     api.health_summary = v
        # if k == 'config_stale':
        #     api.config_stale = v
        # if k == 'config_staleness_status':
        #     api.config_staleness_status = v
        # if k == 'health_checks':
        #     api.health_checks = v
        # if k == 'ha_status':
        #     api.ha_status = v
        # if k == 'role_url':
        #     api.role_url = v
        # if k == 'maintenance_mode':
        #     api.maintenance_mode = v
        # if k == 'maintenance_owners':
        #     api.maintenance_owners = v
        # if k == 'role_config_group_ref':
        #     api.role_config_group_ref = v
        # if k == 'zoo_keeper_server_mode':
        #     api.zoo_keeper_server_mode = v
        # if k == 'entity_status':
        #     api.entity_status = v

    return api


def build_ApiConfigList(d):
    """
    Builds a ApiConfigList obj from a dict

    Args:
        dict

    Returns:
        ApiConfigList
    """
    api = cm_client.ApiConfigList(**d)

    for k, v in d.items():
        if k == 'items':
            api.items = [cm_client.ApiConfig(**x) for x in v]

    return api


#
# Utility functions
#
def redact(d, redacted_list, redact_word):
    """
    Redacts all values of a (multi-level) dict with the redact_word if the key is included in the redacted_list 

    Args:
        dict        d
        list['str'] redacted_list
        str         redact_word

    Returns:
        dict
    """
    for k, v in d.items():
        if isinstance(v, dict):
            redact(v, redacted_list, redact_word)
        if k in (redacted_list):
            d[k] = redact_word
    return d


def wait(api_command, api_client, timeout=None):
    """
    Queries the ApiCommand obj for status and returns once status is no longer active

    Args:
        ApiCommand : api_command
        ApiClient  : api_client
        int        : timeout

    Returns:
        ApiCommand
    """
    SYNCHRONOUS_COMMAND_ID = -1
    if api_command.id == SYNCHRONOUS_COMMAND_ID:
        return api_command, ""

    SLEEP_SECS = 5
    if timeout is None:
        deadline = None
    else:
        deadline = time.time() + timeout

    api_command_instance = cm_client.CommandsResourceApi(api_client)
    while True:
        api_command = api_command_instance.read_command(
            int(api_command.id))
        if not api_command.active:
            return api_command

        if deadline is not None:
            now = time.time()
            if deadline < now:
                return api_command
            else:
                time.sleep(min(SLEEP_SECS, deadline - now))
        else:
            time.sleep(SLEEP_SECS)


def old_wait(api_command, api_client, timeout=None):
    """
    Queries the ApiCommand obj for status and returns once status is no longer active

    Args:
        ApiCommand : api_command
        ApiClient  : api_client
        int        : timeout

    Returns:
        ApiCommand
        ApiException  
    """
    SYNCHRONOUS_COMMAND_ID = -1
    if api_command.id == SYNCHRONOUS_COMMAND_ID:
        return api_command, ""

    SLEEP_SECS = 5
    if timeout is None:
        deadline = None
    else:
        deadline = time.time() + timeout

    try:
        api_command_instance = cm_client.CommandsResourceApi(api_client)
        while True:
            api_command = api_command_instance.read_command(
                int(api_command.id))
            if not api_command.active:
                return api_command, ""

            if deadline is not None:
                now = time.time()
                if deadline < now:
                    return api_command, ""
                else:
                    time.sleep(min(SLEEP_SECS, deadline - now))
            else:
                time.sleep(SLEEP_SECS)
    except ApiException as e:
        return api_command, stringify_error(e)
