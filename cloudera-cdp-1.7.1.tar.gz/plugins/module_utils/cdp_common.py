#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
For interactions with Cloudera Data Platform Public Cloud Control Plane APIs
"""

import datetime
import html
import io
import json
import logging
import platform
import re
from functools import wraps
from json import JSONDecodeError

from cdpcli import VERSION
from cdpcli.client import ClientCreator
from cdpcli.client import Context
from cdpcli.credentials import Credentials
from cdpcli.endpoint import EndpointCreator
from cdpcli.endpoint import EndpointResolver
from cdpcli.loader import Loader
from cdpcli.parser import ResponseParserFactory
from cdpcli.retryhandler import create_retry_handler
from cdpcli.translate import build_retry_config
from cdpcli.exceptions import ClientError


__credits__ = ["cleroy@cloudera.com"]
__maintainer__ = [
    "dchaffelson@cloudera.com",
    "wmudge@cloudera.com"
]

LOG = logging.getLogger('cloudera.cdp')
ROOT_LOGGER = logging.getLogger('')
LOG_FORMAT = '%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s'


class ClientBuilder(object):
    def __init__(self, debug=False):

        loader = Loader()
        user_agent = self._make_user_agent_header()

        self._client_creator = ClientCreator(
            loader,
            Context(),
            EndpointCreator(EndpointResolver()),
            user_agent,
            ResponseParserFactory(),
            create_retry_handler(self._load_retry_config(loader)))

        if debug:
            self._setup_logger(logging.DEBUG)
            LOG.debug("CDP SDK version: %s", user_agent)
        else:
            self._setup_logger(logging.ERROR)

    @staticmethod
    def _make_user_agent_header():
        return 'CDPSDK/%s Python/%s %s/%s' % (VERSION,
                                              platform.python_version(),
                                              platform.system(),
                                              platform.release())

    @staticmethod
    def _load_retry_config(loader):
        original_config = loader.load_json('_retry.json')
        retry_config = build_retry_config(
            original_config['retry'],
            original_config.get('definitions', {}))
        return retry_config

    def _setup_logger(self, log_level):
        ROOT_LOGGER.setLevel(logging.DEBUG)

        self.log_capture = io.StringIO()

        handler = logging.StreamHandler(self.log_capture)
        handler.setLevel(log_level)

        formatter = logging.Formatter(LOG_FORMAT)
        handler.setFormatter(formatter)

        ROOT_LOGGER.addHandler(handler)

    def get_log(self):
        contents = self.log_capture.getvalue()
        self.log_capture.close()
        return contents

    def build(self, service, endpoint=None, verify_tls=True, credentials=None):
        if not credentials:
            credentials = self._client_creator.context.get_credentials()
        return self._client_creator.create_client(
            service,
            endpoint,
            verify_tls,
            credentials)


class StaticCredentials(Credentials):
    """A credential class that simply takes a set of static credentials."""
    def __init__(self, access_key_id, private_key):
        super(StaticCredentials, self).__init__(access_key_id, private_key, 'static')


class CdpModule(object):
    """A base CDP module class for common parameters and fields."""
    def __init__(self, module):
        # Set common parameters
        self.module = module
        self.tls = self.module.params['verify_tls']
        self.debug = self.module.params['debug']

        # Initialize common return values
        self.log_out = None
        self.log_lines = []

        # Initial the ClientBuilder
        self.builder = ClientBuilder(debug=self.debug)

    def build_client(self, service):
        return self.builder.build(service, verify_tls=self.tls)

    @staticmethod
    def argument_spec(**spec):
        return dict(
            **spec,
            verify_tls=dict(required=False, type='bool', default=True, aliases=['tls']),
            debug=dict(required=False, type='bool', default=False, aliases=['debug_endpoints'])
        )


def dumps(data):
    """Perform a json.dumps, but handle datetime objects."""
    def _convert(o):
        if isinstance(o, datetime.datetime):
            return o.__str__()
    return json.dumps(data, indent=2, default=_convert)


def handle_cdp_error(error_code, return_default, key=None):
    """
    A wrapper function to catch a given CDP Error Code and return a specified default Python object or field
        from the error according to a key
    :param error_code: NOT_FOUND, INVALID_ARGUMENT
    :param return_default: list(), None
    :param key: str for error field to be returned
    :return: as per specified return_default or key
    """
    def key_wrapper(f):
        @wraps(f)
        def wrapper(*args, **kwds):
            try:
                if key is not None:
                    return f(*args, **kwds)[key]
                else:
                    return f(*args, **kwds)
            except ClientError as e:
                if e.response['error']['code'] == error_code:
                    return return_default
                raise e
        return wrapper
    return key_wrapper


CLIENT_ERROR_PATTERN = re.compile(r"Status Code: (.*?); Error Code: (.*?); Service: (.*?); Operation: (.*?); Request "
                                  r"ID: (.*?);")


def parse_client_error(error):
    payload = re.search(CLIENT_ERROR_PATTERN, str(error))
    try:
        violations = json.loads(html.unescape(error.response['error']['message']))
    except JSONDecodeError:
        violations = error.response['error']['message']

    return dict(
        msg=error.response['error']['code'],
        violations=violations,
        status_code=payload.group(1),
        rc=1,
        service=payload.group(3),
        operation=payload.group(4),
        request_id=payload.group(5)
    )
