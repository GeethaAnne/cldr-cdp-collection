#!/usr/bin/env python
# -*- coding: utf-8 -*-


class ModuleDocFragment(object):
    DOCUMENTATION = r'''
    options:
      profile:
        description:
          - If provided, the CDP SDK will use this value as its profile.
        type: str
        required: False
    '''
