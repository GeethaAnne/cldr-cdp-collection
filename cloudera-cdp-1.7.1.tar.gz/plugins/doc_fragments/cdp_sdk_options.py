#!/usr/bin/env python
# -*- coding: utf-8 -*-


class ModuleDocFragment(object):
    DOCUMENTATION = r'''
    options:
        verify_tls:
            description:
                - Verify the TLS certificates for the CDP endpoint.
            type: bool
            required: False
            default: True
            aliases:
                - tls
        debug:
            description:
                - Capture the CDP SDK debug log.
            type: bool
            required: False
            default: False
            aliases:
                - debug_endpoints
    '''
