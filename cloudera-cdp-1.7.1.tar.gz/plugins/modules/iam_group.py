#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error
from ansible_collections.cloudera.cdp.plugins.module_utils.iam_common import gather_groups
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: iam_group
short_description: Create, update, or destroy CDP IAM Groups
description:
    - Create, update, and destroy CDP IAM Groups.
    - A group is a named collection of users and machine users.
    - Roles and resource roles can be assigned to a group impacting all members of the group.
author:
  - "Webster Mudge <@wmudge>"
requirements:
  - cdpcli
options:
  name:
    description:
      - The name of the group.
      - The name must be unique, must have a maximum of 32 characters, and must contain only alphanumeric characters, "-", and "_".
      - The first character of the name must be alphabetic or an underscore.
      - Names are are not case-sensitive.
      - The group named "administrators" is reserved.
    type: str
    required: True
    aliases:
      - group_name
  purge:
    description:
      - Flag to replace C(roles), C(users), and C(resource_roles) with their specified values.
    type: bool
    required: False
    default: False
    aliases:
      - replace
  resource_roles:
    description:
      - A list of resource role assignments.
    type: list
    required: False
    elements: dict
    contains:
      resource:
        description:
          - The resource CRN for the rights assignment.
        type: str
        required: True
        aliases:
          - resourceCrn
      role:
        description:
          - The resource role CRN to be assigned.
        type: str
        required: True
        aliases:
          - resourceRoleCrn
  roles:
    description:
      - A single role or list of roles assigned to the group.
      - The role must be identified by its full CRN.
    type: list
    elements: str
    required: False
  state:
    description:
      - The state of the group.
    type: str
    required: False
    default: present
    choices:
      - present
      - absent
  sync:
    description:
      - Whether group membership is synced when a user logs in.
      - The default is to sync group membership.
    type: bool
    required: False
    default: True
    aliases:
      - sync_membership
      - sync_on_login
  users:
    description:
      - A single user or list of users assigned to the group.
      - The user can be either the name or CRN.
    type: list
    elements: str
    required: False
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Create a group
- cloudera.cdp.iam_group:
    name: group-example

# Create a group with membership sync disabled
- cloudera.cdp.iam_group:
    state: present
    name: group-example
    sync: no

# Delete a group
- cloudera.cdp.iam_group:
    state: absent
    name: group-example

# Assign users to a group
- cloudera.cdp.iam_group:
    name: group-example
    users:
      - user-a
      - user-b

# Assign roles to a group
- cloudera.cdp.iam_group:
    name: group-example
    roles:
      - role-a
      - role-b

# Replace resource roles a group
- cloudera.cdp.iam_group:
    name: group-example
    resource_roles:
      - role-c
      - role-d
    purge: yes
'''

RETURN = '''
group:
  description: The information about the Group
  type: dict
  returned: always
  contains:
    creationDate:
      description: The date when this group record was created.
      returned: on success
      type: str
      sample: 2020-07-06T12:24:05.531000+00:00
    crn:
      description: The CRN of the group.
      returned: on success
      type: str
    groupName:
      description: The group name.
      returned: on success
      type: str
      sample: example-01
    users:
      description: List of User CRNs which are members of the group.
      returned: on success
      type: list
      elements: str
    roles:
      description: List of Role CRNs assigned to the group.
      returned: on success
      type: list
      elements: str
    resource_roles:
      description: List of Resource-to-Role assignments, by CRN, that are associated with the group.
      returned: on success
      type: list
      elements: dict
      contains:
        resourceCrn:
          description: The CRN of the resource granted the rights of the role.
          returned: on success
          type: str
        resourceRoleCrn:
          description: The CRN of the CDP Role.
          returned: on success
          type: str
    syncMembershipOnUserLogin:
      description: Flag indicating whether group membership is synced when a user logs in. The default is to sync group membership.
      returned: when supported
      type: bool
sdk_out:
  description: Returns the captured CDP SDK log.
  returned: when supported
  type: str
sdk_out_lines:
  description: Returns a list of each line of the captured CDP SDK log.
  returned: when supported
  type: list
  elements: str
'''

PAGE_SIZE = 50


class IAMGroup(CdpModule):
    def __init__(self, module):
        super(IAMGroup, self).__init__(module)

        # Set Variables
        self.state = self.module.params['state']
        self.name = self.module.params['name'] if 'name' in self.module.params else None
        self.sync = self.module.params['sync'] if 'sync' in self.module.params else None
        self.users = self.module.params['users'] if 'users' in self.module.params else None
        self.roles = self.module.params['roles'] if 'roles' in self.module.params else None
        self.resource_roles = self.module.params['resource_roles'] if 'resource_roles' in self.module.params else None
        self.purge = self.module.params['purge']

        # Initialize the return values
        self.info = dict()
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('iam')
            existing = self._retrieve_group(client)
            if existing is None:
                if self.state == 'present':
                    self.changed = True
                    self.create_group(client)
                    if self.users:
                        for user in self.users:
                            self.add_user(client, user)
                    if self.roles:
                        for role in self.roles:
                            self.add_role(client, role)
                    if self.resource_roles:
                        for assignment in self.resource_roles:
                            self.add_resource_role(client, assignment)
                    self.info = self._retrieve_group(client)
            else:
                if self.state == 'present':
                    if self.sync is not None and existing['syncMembershipOnUserLogin'] != self.sync:
                        self.changed = True
                        self.update_group(client)

                    if self.users is not None:
                        # If an empty user list, don't normalize
                        normalized_users = self._normalize_users(client) if self.users else list()
                        new_users = [user for user in normalized_users if user not in existing['users']]
                        for user in new_users:
                            self.changed = True
                            self.add_user(client, user)
                        if self.purge:
                            stale_users = [user for user in existing['users'] if user not in normalized_users]
                            for user in stale_users:
                                self.changed = True
                                self.remove_user(client, user)

                    if self.roles is not None:
                        new_roles = [role for role in self.roles if role not in existing['roles']]
                        for role in new_roles:
                            self.changed = True
                            self.add_role(client, role)
                        if self.purge:
                            stale_roles = [role for role in existing['roles'] if role not in self.roles]
                            for role in stale_roles:
                                self.changed = True
                                self.remove_role(client, role)

                    if self.resource_roles is not None:
                        new_assignments = self._new_assignments(existing['resource_roles'])
                        for assignment in new_assignments:
                            self.changed = True
                            self.add_resource_role(client, assignment)
                        if self.purge:
                            stale_assignments = self._stale_assignments(existing['resource_roles'])
                            for assignment in stale_assignments:
                                self.changed = True
                                self.remove_resource_role(client, assignment)

                    if self.changed:
                        self.info = self._retrieve_group(client)
                    else:
                        self.info = existing

                elif self.state == 'absent':
                    self.changed = True
                    self.delete_group(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def create_group(self, client):
        if self.sync is None:
            self.sync = True
        return client.create_group(groupName=self.name, syncMembershipOnUserLogin=self.sync)['group']

    def update_group(self, client):
        return client.update_group(groupName=self.name, syncMembershipOnUserLogin=self.sync)['group']

    def delete_group(self, client):
        return client.delete_group(groupName=self.name)

    def add_user(self, client, user):
        client.add_user_to_group(groupName=self.name, userId=user)

    def remove_user(self, client, user):
        client.remove_user_from_group(groupName=self.name, userId=user)

    def add_role(self, client, role):
        client.assign_group_role(groupName=self.name, role=role)

    def remove_role(self, client, role):
        return client.unassign_group_role(groupName=self.name, role=role)

    def add_resource_role(self, client, assignment):
        client.assign_group_resource_role(groupName=self.name, resourceCrn=assignment['resource'],
                                          resourceRoleCrn=assignment['role'])

    def remove_resource_role(self, client, assignment):
        return client.unassign_group_resource_role(groupName=self.name, resourceCrn=assignment['resourceCrn'],
                                                   resourceRoleCrn=assignment['resourceRoleCrn'])

    def _retrieve_group(self, client):
        group_list = gather_groups(client, self.name)
        if group_list:
            return group_list[0]
        else:
            return None

    def _normalize_users(self, client):
        gathered = []
        results = self._list_users(client)

        while 'nextToken' in results:
            gathered.extend(results['users'])
            results = self._list_users(client, starting_token=results['nextToken'])

        if 'users' in results:
            gathered.extend(results['users'])

        return list(map(lambda user: user['crn'], gathered))

    def _list_users(self, client, starting_token=None):
        if starting_token:
            return client.list_users(pageSize=PAGE_SIZE, startingToken=starting_token)
        else:
            return client.list_users(pageSize=PAGE_SIZE, userIds=self.users)

    def _new_assignments(self, existing_assignments):
        new_assignments = []
        resource_dict = dict()
        for existing in existing_assignments:
            if existing['resourceCrn'] in resource_dict:
                resource_dict[existing['resourceCrn']].add(existing['resourceRoleCrn'])
            else:
                resource_dict[existing['resourceCrn']] = {existing['resourceRoleCrn']}
        for assignment in self.resource_roles:
            if assignment['resource'] not in resource_dict or assignment['role'] not in \
                    resource_dict[assignment['resource']]:
                new_assignments.append(assignment)
        return new_assignments

    def _stale_assignments(self, existing_assignments):
        stale_assignments = []
        resource_dict = dict()
        for assignment in self.resource_roles:
            if assignment['resource'] in resource_dict:
                resource_dict[assignment['resource']].add(assignment['role'])
            else:
                resource_dict[assignment['resource']] = {assignment['role']}
        for existing in existing_assignments:
            if existing['resourceCrn'] not in resource_dict or existing['resourceRoleCrn'] not in \
                    resource_dict[existing['resourceCrn']]:
                stale_assignments.append(existing)
        return stale_assignments


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            state=dict(required=False, type='str', choices=['present', 'absent'], default='present'),
            name=dict(required=True, type='str', aliases=['group_name']),
            sync=dict(required=False, type='bool', aliases=['sync_membership', 'sync_on_login']),
            users=dict(required=False, type='list', elements='str'),
            roles=dict(required=False, type='list', elements='str'),
            resource_roles=dict(required=False, type='list', elements='dict', options=dict(
                resource=dict(required=True, type='str', aliases=['resourceCrn']),
                role=dict(required=True, type='str', aliases=['resourceRoleCrn'])
            ), aliases=['assignments']),
            purge=dict(required=False, type='bool', default=False, aliases=['replace'])
        ),
        supports_check_mode=True
    )

    result = IAMGroup(module)

    output = dict(
        changed=result.changed,
        group=result.info,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
