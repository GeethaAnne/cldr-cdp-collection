#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error, \
    handle_cdp_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: iam_resource_role_info
short_description: Gather information about CDP Public IAM resource roles
description:
    - Gather information about CDP Public IAM resource role or roles
author:
  - "Webster Mudge (@wmudge)"
options:
  name:
    description:
      - A list of Resource Role CRNs or a single role's CRN.
      - If no CRNs are provided, all Resource Roles are returned.
    type: list
    elements: str
    required: False
    aliases:
      - crn
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Gather information about all Resource Roles
- cloudera.cdp.iam_resource_role_info:

# Gather information about a named Resource Role
- cloudera.cdp.iam_resource_role_info:
    name: crn:altus:iam:us-west-1:altus:resourceRole:ODUser

# Gather information about several named Resource Roles
- cloudera.cdp.iam_resource_role_info:
    name:
      - crn:altus:iam:us-west-1:altus:resourceRole:DWAdmin
      - crn:altus:iam:us-west-1:altus:resourceRole:DWUser
'''

RETURN = '''
resource_roles:
  description: The information about the named Resource Role or Roles
  type: list
  returned: always
  elements: dict
  contains:
    crn:
      description: The CRN of the resource role.
      returned: on success
      type: str
    rights:
      description: List of rights assigned to the group.
      returned: on success
      type: list
      elements: str
sdk_out:
  description: Returns the captured CDP SDK log.
  returned: when supported
  type: str
sdk_out_lines:
  description: Returns a list of each line of the captured CDP SDK log.
  returned: when supported
  type: list
  elements: str
'''

PAGE_SIZE = 50


class IAMResourceRoleInfo(CdpModule):
    def __init__(self, module):
        super(IAMResourceRoleInfo, self).__init__(module)

        # Set Variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None

        # Initialize the return values
        self.info = []

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('iam')
            self.info = self.get_resource_roles(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def get_resource_roles(self, client):
        roles = []
        results = self._list_resource_roles(client)
        while 'nextToken' in results:
            roles.extend(results['resourceRoles'])
            results = self._list_resource_roles(client, starting_token=results['nextToken'])
        if 'resourceRoles' in results:
            roles.extend(results['resourceRoles'])
        return roles

    @handle_cdp_error('NOT_FOUND', list())
    def _list_resource_roles(self, client, starting_token=None):
        if starting_token:
            return client.list_resource_roles(pageSize=PAGE_SIZE, startingToken=starting_token)
        elif self.name is not None:
            return client.list_resource_roles(pageSize=PAGE_SIZE, resourceRoleNames=self.name)
        else:
            return client.list_resource_roles(pageSize=PAGE_SIZE)


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='list', elements='str', aliases=['crn'])
        ),
        supports_check_mode=True
    )

    result = IAMResourceRoleInfo(module)

    output = dict(
        changed=False,
        resource_roles=result.info,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
