#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_cred_info
short_description: Gather information about CDP Credentials
description:
  - Gather information about CDP Credentials using the CDP SDK.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  name:
    description:
      - If a name is provided, the module will describe the found Credential. If the Credential is not found, the module
        will return an empty dictionary.
      - If no name is provided, the module will list all found Credentials. If no Credentials are found, the module will
        return an empty list.
    type: str
    required: False
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Gather information about all Credentials
- cloudera.cdp.env_cred_info:

# Gather information about a named Credential
- cloudera.cdp.env_cred_info:
    name: example-credential
'''

RETURN = '''
credentials:
    description: Returns an array of objects for the named Credential or all Credentials.
    returned: always
    type: complex
    contains:
        cloudPlatform:
            description: The name of the cloud provider for the Credential.
            returned: always
            type: str
            sample: AWS
        credentialName:
            description: The name of the Credential.
            returned: always
            type: str
            sample: example-credential
        crn:
            description: The CDP CRN value derived from the cross-account Role ARN used during creation.
            returned: always
            type: str
            sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:61eb5b97-226a-4be7-b56d-795d18a043b5
        description:
            description: The description of the Credential.
            returned: when supported
            type: str
            sample: An example Credential
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class EnvironmentCredentialInfo(CdpModule):
    def __init__(self, module):
        super(EnvironmentCredentialInfo, self).__init__(module)

        # Set variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None

        # Initialize the return values
        self.credentials = []
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')
            if self.name is not None:
                cred = self.get_credential(client)
                if cred is not None:
                    self.credentials.append(cred[0])
            else:
                self.credentials = self.list_credentials(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        self.log_out = self.builder.get_log()
        self.log_lines = self.log_out.splitlines()

    @handle_cdp_error('NOT_FOUND', None, 'credentials')
    def get_credential(self, client):
        """
        Gets a given Credential.

        Args:
            client: The CDK client

        Returns: The Credential description or None if not found.
        """
        return client.list_credentials(credentialName=self.name)

    @handle_cdp_error('NOT_FOUND', list(), 'credentials')
    def list_credentials(self, client):
        """
        Lists all Credentials.

        Args:
            client: The CDK client

        Returns: A list of all Credential descriptions or an empty list.
        """
        return client.list_credentials()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='str', aliases=['credential'])
        ),
        supports_check_mode=True
    )

    result = EnvironmentCredentialInfo(module)

    output = dict(
        changed=False,
        credentials=result.credentials,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
