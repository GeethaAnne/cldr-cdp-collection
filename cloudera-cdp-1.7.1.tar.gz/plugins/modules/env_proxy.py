#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_proxy
short_description: Create, update, or destroy CDP Environment Proxies
description:
    - Create, update, and destroy CDP Environment Proxies
author:
  - "Webster Mudge <@wmudge>"
requirements:
  - cdpcli
options:
  name:
    description:
      - The name of the proxy config
    type: str
    required: True
    aliases:
      - proxyConfigName
  description:
    description:
      - A description for the proxy config
    type: str
    required: False
  host:
    description:
      - The proxy host
      - Required when state=present
    type: str
    required: False
  port:
    description:
      - The proxy port
      - Required when state=present
    type: int
    required: False
  protocol:
    description:
      - The protocol
      - Required when state=present
    type: str
    required: False
    choices:
      - http
      - https
  user:
    description:
      - The proxy user
      - NOTE: Defining this parameter will always force an proxy configuration update
    type: str
    required: False
  password:
    description:
      - The proxy password
      - NOTE: Defining this parameter will always force an proxy configuration update.
    type: str
    required: False
  state:
    description:
      - The state of the proxy
    type: str
    required: False
    default: present
    choices:
      - present
      - absent
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Create a proxy with a user and password
- cloudera.cdp.env_proxy:
    name: proxy-example
    host: example.cloudera.com
    port: 8443
    protocol: https
    user: foo
    password: barbazgaz

# Delete a proxy
- cloudera.cdp.env_info:
    state: absent
    name: proxy-example
'''

RETURN = '''
proxy:
    description: Details on the proxy
    type: dict
    returned: on success
    contains:
        crn:
            description: The CRN of the proxy config.
            returned: always
            type: str
            sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:eb6c5fc8-38fe-4c3c-8194-1a0f05edc010
        description:
            description: A description for the proxy config.
            returned: when supported
            type: str
            sample: Example proxy configuration
        host:
            description: The proxy host.
            returned: always
            type: str
            sample: example.cloudera.com
        port:
            description: The proxy port.
            returned: always
            type: int
            sample: 8443
        protocol:
            description: The proxy protocol.
            returned: always
            type: str
            sample: https
        proxyConfigName:
            description: The name of the proxy config.
            returned: always
            type: str
            sample: example-proxy-config
        user:
            description: The proxy user.
            returned: when supported
            type: str
            sample: proxy_username
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class EnvironmentProxy(CdpModule):
    def __init__(self, module):
        super(EnvironmentProxy, self).__init__(module)

        # Set variables
        self.state = self.module.params['state']
        self.name = self.module.params['name']
        self.host = self.module.params['host']
        self.port = self.module.params['port']
        self.protocol = self.module.params['protocol']

        self.description = self.module.params['description'] if 'description' in self.module.params else None
        self.user = self.module.params['user'] if 'user' in self.module.params else None
        self.password = self.module.params['password'] if 'password' in self.module.params else None

        self._payload = dict()

        # Initialize return values
        self.changed = False
        self.proxy_config = {}

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')

            existing = self._describe_proxy_config(client, self.name)

            if existing is None:
                if self.state == 'present':
                    self.changed = True
                    self._create_core_payload()
                    self._create_auth_payload()
                    self.proxy_config = self._create_proxy_config(client)
            else:
                if self.state == 'present':
                    self._create_core_payload()

                    test = dict(existing[0])
                    del test['crn']

                    if self._payload != test:
                        self.changed = True

                    if self.user is not None or self.password is not None:
                        self.changed = True
                        self._create_auth_payload()
                        self.module.warn('Proxy authentication details are set. Forcing update.')

                    if self.changed:
                        client.delete_proxy_config(proxyConfigName=self.name)
                        self.proxy_config = self._create_proxy_config(client)
                    else:
                        self.proxy_config = existing[0]
                else:
                    self.changed = True
                    client.delete_proxy_config(proxyConfigName=self.name)

        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def _create_core_payload(self):
        self._payload = dict(
            proxyConfigName=self.name,
            host=self.host,
            port=self.port,
            protocol=self.protocol
        )

        if self.description is not None:
            self._payload.update(description=self.description)

    def _create_auth_payload(self):
        if self.user is not None:
            self._payload.update(user=self.user)

        if self.password is not None:
            self._payload.update(password=self.password)

    @handle_cdp_error('NOT_FOUND', None, 'proxyConfigs')
    def _describe_proxy_config(self, client, name):
        return client.list_proxy_configs(proxyConfigName=name)

    def _create_proxy_config(self, client):
        return client.create_proxy_config(**self._payload)['proxyConfig']


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=True, type='str', aliases=['proxyConfigName']),
            description=dict(required=False, type='str', aliases=['desc']),
            host=dict(required=False, type='str'),
            port=dict(required=False, type='int'),
            protocol=dict(required=False, type='str'),
            user=dict(required=False, type='str'),
            password=dict(required=False, type='str', no_log=True),
            state=dict(required=False, type='str', choices=['present', 'absent'], default='present')
        ),
        required_if=[
            ['state', 'present', ('host', 'port', 'protocol'), False],
        ],
        # TODO Support check mode
        supports_check_mode=False
    )

    result = EnvironmentProxy(module)

    output = dict(
        changed=result.changed,
        proxy=result.proxy_config,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
