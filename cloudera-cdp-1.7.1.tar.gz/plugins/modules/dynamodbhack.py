#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule

import boto3

DOCUMENTATION = r''' # '''


def main():
    module = AnsibleModule(
        argument_spec=dict(
            table_name=dict(required=True, type='str'),
            region=dict(required=True, type='str'),
            hash_key_name=dict(required=True, type='str'),
            range_key_name=dict(required=True, type='str'),
            billing_mode=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )

    client = boto3.client('dynamodb', 
        region_name=module.params['region'])

    # response = client.update_table(
    #     TableName=module.params['table_name'],
    #     BillingMode='PAY_PER_REQUEST')

    response = client.create_table(
        AttributeDefinitions=[
            {
                'AttributeName': module.params['hash_key_name'],
                'AttributeType': 'S'
            },
            {
                'AttributeName': module.params['range_key_name'],
                'AttributeType': 'S'
            },
        ],
        TableName=module.params['table_name'],
        KeySchema=[
            {
                'AttributeName': module.params['hash_key_name'],
                'KeyType': 'HASH'
            },
            {
                'AttributeName': module.params['range_key_name'],
                'KeyType': 'RANGE'
            },
        ],
        BillingMode=module.params['billing_mode']  )

    module.exit_json(changed=True, result=response)


if __name__ == '__main__':
    main()