#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, \
    handle_cdp_error, parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: iam_user_info
short_description: Gather information about CDP Public IAM users
description:
    - Gather information about CDP Public IAM users
author:
  - "Webster Mudge (@wmudge)"
options:
  name:
    description:
      - A list of user names or CRNs or a single user name/CRN.
      - If no user name or CRN is provided, all users are returned.
      - Mutually exclusive with C(current_user).
    type: list
    elements: str
    required: False
    aliases:
      - user_name
  current_user:
    description:
      - Flag to use the current user login.
      - Mutually exclusive with C(name).
    type: bool
    required: False
    default: False
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# List basic information about all Users
- cloudera.cdp.iam_user_info:

# Gather detailed information about a named User
- cloudera.cdp.iam_info:
    name: Example

# Gather detailed information about the current user
- cloudera.cdp.iam_info:
    current_user: yes
'''

RETURN = '''
users:
  description: The information about the current or named User or Users
  type: list
  returned: always
  elements: dict
  contains:
    accountAdmin:
      description: Whether the user is an administrator of their CDP account.
      returned: on success
      type: bool
    creationDate:
      description: The date when this user record was created.
      returned: on success
      type: str
      sample: 2020-07-06T12:24:05.531000+00:00
    crn:
      description: The CRN of the user.
      returned: on success
      type: str
    email:
      description: The user's email address.
      returned: on success
      type: str
    firstName:
      description: The user's first name.
      returned: on success
      type: str
    identityProviderCrn:
      description: The identity provider that the user belongs to. It can be "Cloudera-Default", "Cloudera-Administration", or a customer-defined identity provider.
      returned: on success
      type: str
    lastInteractiveLogin:
      description: The date of the user’s last interactive login.
      returned: when supported
      type: str
      sample: 2020-08-04T16:57:37.808000+00:00
    lastName:
      description: The user's last name.
      returned: on success
      type: str
    userId:
      description: The stable, unique identifier of the user.
      returned: on success
      type: str
      sample: f2e7cd8a-4c2d-41b5-92e9-784255c25b7d
    workloadUsername:
      description: The username used in all the workload clusters of the user.
      returned: when supported
      type: str
      sample: u_023
sdk_out:
  description: Returns the captured CDP SDK log.
  returned: when supported
  type: str
sdk_out_lines:
  description: Returns a list of each line of the captured CDP SDK log.
  returned: when supported
  type: list
  elements: str
'''

PAGE_SIZE = 50


class IAMUserInfo(CdpModule):
    def __init__(self, module):
        super(IAMUserInfo, self).__init__(module)

        # Set Variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None
        self.current = self.module.params['current_user'] if 'current_user' in self.module.params else False

        # Initialize the return values
        self.info = []

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('iam')
            if self.current:
                self.info = self.describe_user(client)
            else:
                self.info = self.gather_users(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def gather_users(self, client):
        gathered = []
        results = self._list_users(client)

        while 'nextToken' in results:
            gathered.extend(results['users'])
            results = self._list_users(client, starting_token=results['nextToken'])

        if 'users' in results:
            gathered.extend(results['users'])

        return gathered

    @handle_cdp_error('NOT_FOUND', list())
    def _list_users(self, client, starting_token=None):
        if starting_token:
            return client.list_users(pageSize=PAGE_SIZE, startingToken=starting_token)
        elif self.name:
            return client.list_users(pageSize=PAGE_SIZE, userIds=self.name)
        else:
            return client.list_users(pageSize=PAGE_SIZE)

    def describe_user(self, client):
        return [client.get_user()['user']]


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='list', elements='str', aliases=['user_name']),
            current_user=dict(required=False, type='bool'),
        ),
        mutually_exclusive=[
            ['name', 'current_user']
        ],
        supports_check_mode=True
    )

    result = IAMUserInfo(module)

    output = dict(
        changed=False,
        users=result.info,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
