#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error
from ansible_collections.cloudera.cdp.plugins.module_utils.env_common import gather_idbroker_mappings
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_idbroker_info
short_description: Gather information about CDP ID Broker
description:
  - Gather information about the ID Broker mappings for a CDP Environment.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  name:
    description:
      - The name of the Environment.
    aliases:
      - environment
    type: str
    required: True
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Gather information about the ID Broker mappings
- cloudera.cdp.env_idbroker_info:
    name: example-environment
'''

RETURN = '''
idbroker:
    description: Returns the mappings and sync status for the ID Broker for the Environment.
    returned: when supported
    type: dict
    contains:
        mappingsVersion:
            description: The version of the mappings.
            returned: always
            type: str
            sample: AWS
        dataAccessRole:
            description: The cloud provider role to which data access services will be mapped (e.g. an ARN in AWS, a Resource ID in Azure).
            returned: always
            type: str
        rangerAuditRole:
            description:
              - The cloud provider role to which services that write to Ranger audit logs will be mapped (e.g. an ARN in AWS, a Resource ID in Azure).
              - Note that some data access services also write to Ranger audit logs; such services will be mapped to the 'dataAccessRole', not the 'rangerAuditRole'.
            returned: always
            type: str
        rangerCloudAccessAuthorizerRole:
            description: The cloud provider role to which the Ranger RAZ service will be mapped (e.g. an ARN in AWS, a Resource ID in Azure).
            returned: when supported
            type: str
        mappings:
            description: ID Broker mappings for individual actors and groups. Does not include mappings for data access services.
            returned: when supported
            type: list
            elements: dict
            contains:
              accessorCrn:
                description: The CRN of the actor (group or user) mapped to the cloud provider role.
                returned: on success
                type: str
              role:
                description: The cloud provider identitier for the role.
                returned: on success
                type: str
        syncStatus:
            description: The status of the most recent ID Broker mappings sync operation, if any. Not present if there is no Datalake associated with the Environment.
            returned: when supported
            type: dict
            contains:
                globalStatus:
                    description: The overall mappings sync status for all Datalake clusters in the Environment.
                    returned: always
                    type: str
                    sample:
                        - NEVER_RUN
                        - REQUESTED
                        - REJECTED
                        - RUNNING
                        - COMPLETED
                        - FAILED
                        - TIMEDOUT
                syncNeeded:
                    description: Flag indicating whether a sync is needed to bring in-cluster mappings up-to-date.
                    returned: always
                    type: bool
                statuses:
                    description: Map of Datalake cluster CRN-to-mappings sync status for each Datalake cluster in the environment.
                    returned: always
                    type: dict
                    contains:
                        __datalake CRN__:
                            description: The Datalake cluster CRN
                            returned: always
                            type: dict
                            contains:
                                endDate:
                                    description: The date when the mappings sync completed or was terminated. Omitted if status is NEVER_RUN or RUNNING.
                                    returned: when supported
                                    type: str
                                errorDetail:
                                    description: The detail of the error. Omitted if status is not FAILED.
                                    returned: when supported
                                    type: str
                                startDate:
                                    description: The date when the mappings sync started executing. Omitted if status is NEVER_RUN.
                                    returned: when supported
                                    type: str
                                status:
                                    description: The mappings sync summary status.
                                    returned: always
                                    type: str
                                    sample:
                                        - NEVER_RUN
                                        - REQUESTED
                                        - REJECTED
                                        - RUNNING
                                        - COMPLETED
                                        - FAILED
                                        - TIMEDOUT
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class EnvironmentIdBrokerInfo(CdpModule):
    def __init__(self, module):
        super(EnvironmentIdBrokerInfo, self).__init__(module)

        # Set variables
        self.name = self.module.params['name']

        # Initialize the return values
        self.idbroker = dict()
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')
            self.idbroker = gather_idbroker_mappings(client, self.name)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=True, type='str', aliases=['environment'])
        ),
        supports_check_mode=True
    )

    result = EnvironmentIdBrokerInfo(module)

    output = dict(
        changed=False,
        idbroker=result.idbroker,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
