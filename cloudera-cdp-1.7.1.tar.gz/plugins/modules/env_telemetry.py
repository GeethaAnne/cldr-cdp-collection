#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible.utils.display import Display
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_telemetry
short_description: Set CDP environment telemetry
description:
    - Set a CDP environment deployment log collection and workload analytics.
author:
  - "Webster Mudge <@wmudge>"
requirements:
  - cdpcli
options:
  name:
    description:
      - The targeted environment.
    type: str
    required: True
    aliases:
      - environment
  workload_analytics:
    description:
      - A flag to specify the availability of the environment's workload analytics.
    type: bool
    required: False
    aliases:
      - analytics
  logs_collection:
    description:
      - A flag to specify the availability of the environment's deployment log collection.
    type: bool
    required: False
    aliases:
      - report_deployment_logs
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Turn off both workload analytics and log collection
- cloudera.cdp.env_telemetry:
    name: the-environment
    workload_analytics: no
    logs_collection: no
'''

RETURN = '''
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''

display = Display()


class EnvironmentTelemetry(CdpModule):
    def __init__(self, module):
        super(EnvironmentTelemetry, self).__init__(module)

        # Set variables
        self.name = self.module.params['name']
        self.workload_analytics = self.module.params['workload_analytics'] if 'workload_analytics' in self.module.params else None
        self.logs_collection = self.module.params['logs_collection'] if 'logs_collection' in self.module.params else None

        # Execute logic process
        self.process()

    def process(self):
        if not self.module.check_mode:
            try:
                client = self.build_client('environments')
                payload = dict(environmentName=self.name)

                if self.workload_analytics is not None:
                    payload.update(workloadAnalytics=self.workload_analytics)
                if self.logs_collection is not None:
                    payload.update(reportDeploymentLogs=self.logs_collection)

                client.set_telemetry_features(**payload)
            except ClientError as e:
                error = parse_client_error(e)

                if error['status_code'] == '404' and error['operation'] == 'setTelemetryFeatures' and \
                        error['msg'] == 'NOT_FOUND':
                    error = dict(msg='Environment not found')

                if self.debug:
                    log = self.builder.get_log()
                    error.update(sdk_out=log, sdk_out_lines=log.splitlines())

                self.module.fail_json(**error)
            except Exception as e:
                error = dict(msg=to_native(e))
                if self.debug:
                    log = self.builder.get_log()
                    error.update(sdk_out=log, sdk_out_lines=log.splitlines())
                self.module.fail_json(**error)

            if self.debug:
                self.log_out = self.builder.get_log()
                self.log_lines = self.log_out.splitlines()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=True, type='str', aliases=['environment']),
            workload_analytics=dict(required=False, type='bool', aliases=['analytics']),
            logs_collection=dict(required=False, type='bool', aliases=['logs', 'report_deployment_logs'])
        ),
        supports_check_mode=True
    )

    result = EnvironmentTelemetry(module)
    output = dict(changed=True)

    if result.debug:
        output.update(sdk_out=result.log_out, sdk_out_lines=result.log_lines)

    module.exit_json(**output)


if __name__ == '__main__':
    main()
