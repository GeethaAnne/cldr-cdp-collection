#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible.utils.display import Display
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_proxy_info
short_description: Gather information about CDP Environment Proxies
description:
    - Gather information about CDP Environment Proxy Configurations
author:
  - "Webster Mudge <@wmudge>"
requirements:
  - cdpcli
options:
  name:
    description:
      - If a name is provided, that proxy configuration will be described
      - If no name is provided, all proxy configurations will be listed
    type: str
    required: False
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# List basic information about all Proxy Configurations
- cloudera.cdp.env_proxy_info:

# Gather detailed information about a named Proxy Configuration
- cloudera.cdp.env_proxy_info:
    name: example-proxy
'''

RETURN = '''
proxies:
    description: Details on the proxies.
    type: list
    returned: on success
    elements: dict
    contains:
        crn:
            description: The CRN of the proxy config.
            returned: always
            type: str
            sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:eb6c5fc8-38fe-4c3c-8194-1a0f05edc010
        description:
            description: A description for the proxy config.
            returned: when supported
            type: str
            sample: Example proxy configuration
        host:
            description: The proxy host.
            returned: always
            type: str
            sample: example.cloudera.com
        port:
            description: The proxy port.
            returned: always
            type: int
            sample: 8443
        protocol:
            description: The proxy protocol.
            returned: always
            type: str
            sample: https
        proxyConfigName:
            description: The name of the proxy config.
            returned: always
            type: str
            sample: example-proxy-config
        user:
            description: The proxy user.
            returned: when supported
            type: str
            sample: proxy_username
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''

display = Display()


class EnvironmentProxyInfo(CdpModule):
    def __init__(self, module):
        super(EnvironmentProxyInfo, self).__init__(module)

        # Set variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None

        # Initialize return values
        self.proxy_configs = []

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')
            if self.name is not None:
                results = self._describe_proxy_config(client, self.name)
                if results is not None:
                    self.proxy_configs = results['proxyConfigs']
            else:
                self.proxy_configs = client.list_proxy_configs()['proxyConfigs']
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    @handle_cdp_error('NOT_FOUND', None)
    def _describe_proxy_config(self, client, name):
        return client.list_proxy_configs(proxyConfigName=name)


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='str', aliases=['proxyConfigName'])
        ),
        supports_check_mode=True
    )

    result = EnvironmentProxyInfo(module)
    output = dict(
        changed=False,
        proxies=result.proxy_configs,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
