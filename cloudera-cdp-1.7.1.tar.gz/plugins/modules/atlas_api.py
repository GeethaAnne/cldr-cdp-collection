#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2019, Cloudera
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: atlas_api

short_description: Wrapper for the Atlas API

version_added: "2.8"

description:
    - Ansible wrapper module for the Atlas API
    - Consult the official API doc for a list of all functions.


options:
    username:
        description:
            - Atlas username
        default: "admin"
        type: str
    
    password:
        description:
            - Atlas password
        default: "admin"
        type: str
    
    protocol:
        description:
            - Either HTTP or HTTPS
        default: "http"
        type: str

    host:
        description:
            - Atlas host
        default: "localhost"
        type: str
    
    port:
        description:
            - Atlas port
        default: "6080"
        type: str
    
    path:
        description:
            - URL path to the Atlas API endpoint
        default: "/service"
        type: str

    verify_ssl:
        description:
            - whether to check for ssl cert
        default: False
        type: bool

    name:
        description:
            - The API function to run. The function name built by concatenating 
              - the request method (GET, POST, DELETE, PUT), 
              - two underscores `__`, 
              - the API endpoint replaced with underscores

    args:
        description:
            - The dict or string of arguments

requirements: [ "requests" ]

author:
    - Cloudera
'''

EXAMPLES = '''
# Get the list of roles
Atlas_api:
    # parameters for the Atlas ApiClient
    username: admin
    password: admin
    
    protocol: https
    host: mydomain.com
    port: 443
    path: "/service"

    name: GET__public_v2_api_roles

# Create a new role
Atlas_api:
    # parameters for the Atlas ApiClient
    username: admin
    password: admin
    
    protocol: https
    host: mydomain.com
    port: 443
    path: "/service"

    name: POST__public_v2_api_roles
    args:
        options: {}
        name: new_role
        createdByUser: admins
        description: admins
        groups: 
        - isAdmin: true
            name: admin_group1
        roles: []
        users: []
        isEnabled: true
'''

RETURN = '''
result:
    description: The response that the module generates
    type: dict
    returned: always
'''

import json
import requests
from ansible.module_utils.basic import AnsibleModule


def GET__v2_types_typedefs_headers(api_client, args):
    """     
    """
    return requests.get("%s/v2/types/typedefs/headers" % (api_client.url), 
        auth=api_client.auth,
        verify=api_client.verify_ssl)


def POST__v2_types_typedefs(api_client, args):
    """
    args:
      AtlasTypesDef :
        classificationDefs:
          - category: CLASSIFICATION
            name: PII
            description: Personally Identifiable Information
            attributeDefs: []
            superTypes: []
            entityTypes: []
            subTypes: []
    """
    data = args['AtlasTypesDef']

    return requests.post("%s/v2/types/typedefs" % (api_client.url), 
        auth=api_client.auth,
        json=data,
        verify=api_client.verify_ssl)


def GET__v2_search_basic(api_client, args):
    """
    args: 
      query: ccnumber
      typeName: hive_column
      excludeDeletedEntities: true
    """
    s = ""
    for k,v in args.items():
        s = s + k + "=" + v + "&"

    request_param = s[:-1]
    return requests.get("%s/v2/search/basic?%s" % (api_client.url, request_param), 
        auth=api_client.auth,
        verify=api_client.verify_ssl)


def POST__v2_entity_bulk_classification(api_client, args):
    """
    args:
      AtlasEntityWithExtInfo:
        classification:
          attributes: {}
          typeName: PII
        entityGuids:
          - d8cd4e17-6ddc-4f48-aad2-923ec7b47f68
    """
    data = args['AtlasEntityWithExtInfo']

    return requests.post("%s/v2/entity/bulk/classification" % (api_client.url), 
        auth=api_client.auth,
        json=data,
        verify=api_client.verify_ssl)


def main():
    result = {}
    # dict of all functions in Atlas API
    functions = {
        "GET__v2_types_typedefs_headers": GET__v2_types_typedefs_headers,
        "POST__v2_types_typedefs": POST__v2_types_typedefs,
        "GET__v2_search_basic": GET__v2_search_basic,
        "POST__v2_entity_bulk_classification": POST__v2_entity_bulk_classification,
    }

    module = AnsibleModule(
        argument_spec=dict(
            # parameters for the Atlas ApiClient
            username=dict(type='str', default="admin"),
            password=dict(type='str', no_log=True, default="admin"),
            
            protocol=dict(type='str', default="http"),
            host=dict(type='str', default="localhost"),
            port=dict(type='str', default="6080"),
            path=dict(type='str', default="/service"),

            verify_ssl=dict(type='bool', default=False),

            # name of the function to run
            name=dict(type='str'),

            # args, if any
            args=dict(type='dict', default={}),
        ),
        supports_check_mode=True,
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # Setup cAtlas ApiClient Configuration
    api_client = build_ApiClient(module.params)

    # Run the function specified in the module
    r = functions.get(
        module.params['name'])(api_client, module.params["args"])
    
    try:
        result['result'] = r.json()
    except:
        result['result'] = r.text


    if r.ok:
        module.exit_json(**result)
    else:
        module.fail_json(
            msg={
                "status_code" : r.status_code, 
                "content" : r.content,
                "reason" : r.reason}, 
            **result)


#
# Builders
#
def build_ApiClient(d):
    """
    Build a ApiClient obj from a dict
    
    Args:
        dict
    
    Return:
        ApiClient
    """

    url = "%s://%s:%s%s" % (
        d['protocol'],
        d["host"], 
        d["port"], 
        d["path"])
    
    return ApiClient(d['username'], d['password'], url, d['verify_ssl'])

class ApiClient:
    def __init__(self, username, password, url, verify_ssl):
        self.auth = (username, password)
        self.url = url
        self.verify_ssl = verify_ssl   

if __name__ == '__main__':
    main()
