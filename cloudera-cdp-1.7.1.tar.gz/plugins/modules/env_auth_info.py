#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = r'''
module: env_auth_info
short_description: Gather information about CDP environment authentication details
description:
  - Gather information about CDP environment authentication details, notably the FreeIPA root certificate and user keytabs.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  name:
    description:
      - A target list of environments or a single environment string.
      - If no environments are specified, all environments are targeted.
    type: list
    elements: str
    required: False
    aliases:
      - environment
  root_certificate:
    description:
      - A flag indicating whether to retrieve the given environment's FreeIPA root certificate.
    type: bool
    required: False
    default: True
    aliases:
      - root_ca
      - cert
  keytab:
    description:
      - A flag to retrieve the keytabs for the given environment or environments, governed by the value of C(user).
      - If no environments are declared, all environments will be queried.
    type: bool
    required: False
    default: True
    aliases:
      - keytabs
      - user_keytabs
  user:
    description:
      - A list of user IDs or a single user ID for retrieving the keytabs from the specified environment(s).
      - If no user ID is declared, the current CDP user will be used.
    type: list
    elements: str
    required: False
    aliases:
      - users
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = r'''
# Note: These examples do not set authentication details.

# Retrieve only the root certificate for a single environment
- cloudera.cdp.env_auth_info:
    name: the-environment
    root_certificate: yes
    keytab: no

# Retrieve the root certificate for multiple environments
- cloudera.cdp.env_auth_info:
    name:
      - one-environment
      - two-environment
    root_certificate: yes
    keytab: no

# Retrieve the keytab details for the current CDP user for selected environments
- cloudera.cdp.env_auth_info:
    name:
      - one-environment
      - two-environment
    keytab: yes
    root_certificate: no

# Retrieve the keytab details for the specified users for selected environments
- cloudera.cdp.env_auth_info:
    name:
      - one-environment
      - two-environment
    user:
      - UserA
      - UserB
    keytab: yes
    root_certificate: no
'''

RETURN = r'''
authentication:
    description: Returns a dictionary of the environment authentication details.
    returned: always
    type: dict
    contains:
        certificates:
            description: A dictionary of environment-to-FreeIPA root certificate
            returned: when supported
            type: dict
            contains:
              _environment name_:
                description: The FreeIPA root certificate for the environment
                returned: always
                type: str
        keytabs:
            description: A dictionary of the keytabs for each specified environment by user.
            returned: when supported
            type: dict
            contains:
              _workload username_:
                description: The user's workload username.
                returned: always
                type: dict
                contains:
                  _environment name_:
                    description: The keytab for the environment. The keytab is encoded in base64.
                    returned: always
                    type: str
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class EnvironmentAuthentication(CdpModule):
    def __init__(self, module):
        super(EnvironmentAuthentication, self).__init__(module)

        # Set Variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None
        self.user = self.module.params['user'] if 'user' in self.module.params else None
        self.root_cert = self.module.params['root_certificate']
        self.keytab = self.module.params['keytab']

        # Initialize the return values
        self.auth = dict()

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')

            if self.root_cert:
                certs = self.get_certificates(client)
                self.auth.update(certificates=certs)

            if self.keytab:
                iam_client = self.build_client('iam')
                keytabs = dict()
                actors = list()

                if self.user is None:
                    actors.append(self._get_user(iam_client))
                else:
                    for user in self.user:
                        actor = self._get_user(iam_client, user)
                        if actor is None:
                            self.module.fail_json(msg='Invalid user: %s' % user)
                        actors.append(actor)

                for actor in actors:
                    user_keytabs = self.get_keytabs_for_user(client, actor['crn'])
                    keytabs[actor['workloadUsername']] = user_keytabs

                self.auth.update(keytabs=keytabs)

        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def get_certificates(self, client):
        certs = dict()

        if self.name is None:
            env_list = self._list_all_crns(client)
        else:
            env_list = self._discover_crns(client)

        for env in env_list:
            result = client.get_root_certificate(environmentName=env['crn'])
            certs[env['name']] = result['contents']

        return certs

    def get_keytabs_for_user(self, client, workload_user_crn):
        keytabs = dict()

        if self.name is not None:
            for name in self.name:
                result = client.get_keytab(actorCrn=workload_user_crn, environmentName=name)
                keytabs[name] = result['contents']
        else:
            all_envs = self._list_environments(client)
            for env in all_envs:
                result = client.get_keytab(actorCrn=workload_user_crn, environmentName=env['crn'])
                keytabs[env['environmentName']] = result['contents']

        return keytabs

    def _discover_crns(self, client):
        converted = []
        for name in self.name:
            env = self._describe_environment(client, name)
            if env is not None:
                converted.append(dict(name=name, crn=env['crn']))
            else:
                self.module.fail_json(msg="Environment '%s' not found" % name)
        return converted

    def _list_all_crns(self, client):
        converted = []
        discovered = self._list_environments(client)
        for env in discovered:
            converted.append(dict(name=env['environmentName'], crn=env['crn']))
        return converted

    @handle_cdp_error('NOT_FOUND', list(), 'environments')
    def _list_environments(self, client):
        return client.list_environments()

    @handle_cdp_error('NOT_FOUND', None, 'environment')
    def _describe_environment(self, client, name):
        return client.describe_environment(environmentName=name)

    @handle_cdp_error('NOT_FOUND', None, 'user')
    def _get_user(self, client, username=None):
        if username is None:
            return client.get_user()
        else:
            return client.get_user(userId=username)


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='list', elements='str', aliases=['environment']),
            user=dict(required=False, type='list', elements='str', aliases=['users']),
            root_certificate=dict(required=False, type='bool', aliases=['root_ca', 'cert'], default=True),
            keytab=dict(required=False, type='bool', aliases=['keytabs', 'user_keytabs'], default=True)
        ),
        supports_check_mode=True
    )

    result = EnvironmentAuthentication(module)

    output = dict(
        changed=False,
        authentication=result.auth,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
