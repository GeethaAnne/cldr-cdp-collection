#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import time
import re

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible.utils.display import Display
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env
short_description: Manage CDP Environments
description:
    - Create, update, and delete CDP Environments
    - Note that changing states, in particular, creating a new environment, can take several minutes.
author:
  - "Webster Mudge <@wmudge>"
requirements:
  - cdpcli
options:
  name:
    description:
      - The name of the target environment.
      - Names must begin with a lowercase alphanumeric, contain only lowercase alphanumerics and hyphens, and be between 5 to 28 characters in length.
    type: str
    required: True
    aliases:
      - environment
  state:
    description:
      - The declarative state of the environment
      - If I(state=present), one of I(cloud) or I(credential) must be present.
    type: str
    required: False
    default: present
    choices:
      - present
      - started
      - stopped
      - absent
  cloud:
    description:
      - The cloud provider or platform for the environment.
      - Requires I(region), I(credential), I(log_location), and I(log_identity).
      - If I(cloud=aws), one of I(public_key) or I(public_key_id) must be present.
      - If I(cloud=aws), one of I(network_cidr) or I(vpc_id) must be present.
      - If I(cloud=aws), one of I(inbound_cidr) or I(default_sg) and I(knox_sg) must be present.
    type: str
    required: False
    choices:
      - aws
      - azure
  region:
    description:
      - The cloud platform specified region
    type: str
    required: False
  credential:
    description:
      - The CDP credential associated with the environment
    type: str
    required: False
  inbound_cidr:
    description:
      - CIDR range which is allowed for inbound traffic. Either IPv4 or IPv6 is allowed.
      - Mutually exclusive with I(default_sg) and I(knox_sg).
    type: str
    required: False
    aliases:
      - security_cidr
  default_sg:
    description:
      - Security group where all other hosts are placed.
      - Mutually exclusive with I(inbound_cidr).
    type: str
    required: False
    aliases:
      - default
      - default_security_group
  knox_sg:
    description:
      - Security group where Knox-enabled hosts are placed.
      - Mutually exclusive with I(inbound_cidr).
    type: str
    required: False
    aliases:
      - knox
      - knox_security_group
  public_key_text:
    description:
      - The content of a public SSH key.
      - Mutually exclusive with I(public_key_id).
    type: str
    required: False
    aliases:
      - ssh_key_text
  public_key_id:
    description:
      - The public SSH key ID already registered in the cloud provider.
      - Mutually exclusive with I(public_key_text).
    type: str
    required: False
    aliases:
      - public_key
      - ssh_key
      - ssh_key_id
  log_location:
    description:
      - (AWS) The base location to store logs in S3. This should be an s3a:// url.
    type: str
    required: False
    aliases:
      - storage_location_base
  log_identity:
    description:
      - (AWS) The instance profile ARN assigned the necessary permissions to access the S3 storage location, i.e.
        I(log_location).
    type: str
    required: False
    aliases:
      - instance_profile
  network_cidr:
    description:
      - (AWS) The network CIDR. This will create a VPC along with subnets in multiple Availability Zones.
      - Mutually exclusive with I(vpc_id) and I(subnet_ids).
    type: str
    required: False
  vpc_id:
    description:
      - (AWS) The VPC ID.
      - Mutually exclusive with I(network_cidr) and requires I(subnet_ids).
    type: str
    required: False
    aliases:
      - vpc
  subnet_ids:
    description:
      - (AWS) One or more subnet identifiers within the VPC.
      - Mutually exclusive with I(network_cidr) and requires I(vpc_id).
    type: list
    elements: str
    required: False
    aliases:
      - subnets
  tags:
    description:
      - Tags associated with the environment and its resources.
    type: dict
    required: False
    aliases:
      - environment_tags
  workload_analytics:
    description:
      - Flag to enable diagnostic information about job and query execution to be sent to Workload Manager for Data Hub
        clusters created within the environment.
    type: bool
    required: False
    default: True
  description:
    description:
      - A description for the environment.
    type: str
    required: False
    aliases:
      - desc
  tunnel:
    description:
      - Flag to enable SSH tunnelling for the environment.
    type: bool
    required: False
    default: False
    aliases:
      - enable_tunnel
      - ssh_tunnel
  freeipa:
    description:
      - The FreeIPA service for the environment.
    type: dict
    required: False
    contains:
      instanceCountByGroup:
        description:
          - The number of FreeIPA instances to create per group when creating FreeIPA in the environment
        type: int
        required: False
  proxy:
    description:
      - The name of the proxy config to use for the environment.
    type: str
    required: False
    aliases:
      - proxy_config
      - proxy_config_name
  wait:
    description:
      - Flag to enable internal polling to wait for the environment to achieve the declared state.
      - If set to FALSE, the module will return immediately.
    type: bool
    required: False
    default: True
  delay:
    description:
      - The internal polling interval (in seconds) while the module waits for the environment to achieve the declared
        state.
    type: int
    required: False
    default: 15
    aliases:
      - polling_delay
  timeout:
    description:
      - The internal polling timeout (in seconds) while the module waits for the environment to achieve the declared
        state.
    type: int
    required: False
    default: 3600
    aliases:
      - polling_timeout
  s3_guard_name:
    description:
      - (AWS) AWS Dynamo table name for S3 Guard.
    type: str
    required: False
    aliases:
      - s3_guard
      - s3_guard_table_name
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Create an environment
- cloudera.cdp.env:
    name: example-environment
    state: present
    credential: example-credential
    cloud: aws
    region: us-east-1
    log_location: s3a://example-bucket/datalake/logs
    log_identity: arn:aws:iam::981304421142:instance-profile/example-log-role
    public_key_id: example-sshkey
    network_cidr: 10.10.0.0/16
    inbound_cidr: 0.0.0.0/0
    tags:
      project: Arbitrary content

# Create an environment, but don't wait for completion (see env_info)
- cloudera.cdp.env:
    name: example-environment
    state: present
    wait: no
    credential: example-credential
    cloud: aws
    region: us-east-1
    log_location: s3a://example-bucket/datalake/logs
    log_identity: arn:aws:iam::981304421142:instance-profile/example-log-role
    public_key_id: example-sshkey
    network_cidr: 10.10.0.0/16
    inbound_cidr: 0.0.0.0/0
    tags:
      project: Arbitrary content

# Update the environment's CDP credential
- cloudera.cdp.env:
    name: example-module
    credential: another-credential

# Stop the environment (and wait for status change)
- cloudera.cdp.env:
    name: example-module
    state: stopped

# Start the environment (and wait for status change)
- cloudera.cdp.env:
    name: example-module
    state: started

# Delete the environment (and wait for status change)
  cloudera.cdp.env:
    name: example-module
    state: absent
'''

RETURN = '''
---
environment:
  description: The information about the Environment
  type: dict
  returned: on success
  contains:
    authentication:
      description: Additional SSH key authentication configuration for accessing cluster node instances of the Environment.
      returned: always
      type: dict
      contains:
        loginUserName:
          description: SSH user name created on the node instances for SSH access.
          type: str
          returned: always
          sample: cloudbreak
        publicKey:
          description: SSH Public key string
          type: str
          returned: when supported
          sample: ssh-rsa AAAAB3NzaC...BH example-public-key
        publicKeyId:
          description: Public SSH key ID registered in the cloud provider.
          type: str
          returned: when supported
          sample: a_labeled_public_key
    awsDetails:
      description: AWS-specific environment configuration information.
      returned: when supported
      type: dict
      contains:
        s3GuardTableName:
          description: The name for the DynamoDB table backing S3Guard.
          type: str
          returned: always
          sample: table_name
    cloudPlatform:
      description: Cloud provider of the Environment.
      returned: always
      type: str
      sample:
        - AWS
        - AZURE
    credentialName:
      description: Name of the CDP Credential of the Environment.
      returned: always
      type: str
      sample: a-cdp-credential
    crn:
      description: CDP CRN value for the Environment.
      returned: always
      type: str
      sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:61eb5b97-226a-4be7-b56d-795d18a043b5
    description:
      description: Description of the Environment.
      returned: always
      type: str
      sample: An example Environment
    environmentName:
      description: Name of the Environment.
      returned: always
      type: str
      sample: a-cdp-environment-name
    freeipa:
      description: Details of a FreeIPA instance in the Environment.
      returned: always
      type: complex
      contains:
        crn:
          description: CRN of the FreeIPA instance.
          returned: always
          type: str
          sample: crn:cdp:freeipa:us-west-1:558bc1d2-8867-4357-8524-311d51259233:freeipa:cbab8ee3-00f2-4958-90c1-6f7cc06b4937
        domain:
          description: Domain name of the FreeIPA instance.
          returned: always
          type: str
          sample: example.012345-abcd.cloudera.site
        hostname:
          description: Hostname of the FreeIPA instance.
          returned: always
          type: str
          sample: ipaserver
        serverIP:
          description: IP addresses of the FreeIPA instance.
          returned: always
          type: list
          elements: str
          sample:
            - ['10.10.2.40']
    logStorage:
      description: Storage configuration for cluster and audit logs for the Environment.
      returned: always
      type: complex
      contains:
        awsDetails:
          description: AWS-specific log storage configuration details.
          returned: when supported
          type: dict
          contains:
            instanceProfile:
              description: AWS instance profile that contains the necessary permissions to access the S3 storage location.
              returned: always
              type: str
              sample: arn:aws:iam::381358652250:instance-profile/EXAMPLE-LOG_ROLE
            storageLocationBase:
              description: Base location to store logs in S3.
              returned: always
              type: str
              sample: s3a://example-bucket/datalake/logs
        azureDetails:
          description: Azure-specific log storage configuration details.
          returned: when supported
          type: dict
          contains:
            managedIdentity:
              description:
                - Azure managing identity associated with the logger.
                - This identify should have the Storage Blob Data Contributor role on the given storage account.
              returned: always
              type: str
              sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment-name/providers/Microsoft.ManagedIdentity/userAssignedIdentities/loggerIdentity
            storageLocationBase:
              description: Base location to store logs in Azure Blob Storage.
              returned: always
              type: str
              sample: abfs://logs@example_location.dfs.core.windows.net
        enabled:
          description: Flag for external log storage.
          returned: always
          type: bool
    network:
      description: Network details for the Environment
      returned: always
      type: complex
      contains:
        aws:
          description: AWS networking specifics for the Environment.
          returned: when supported
          type: dict
          contains:
            vpcId:
              description: VPC identifier.
              returned: always
              type: str
              sample: vpc-08785c81e888251df
        azure:
          description: Azure networking specifics for the Environment.
          returned: when supported
          type: dict
          contains:
            networkId:
              description: VNet identifier.
              returned: always
              type: str
              sample: example-vnet
            resourceGroupName:
              description: Resource Group name.
              returned: always
              type: str
              sample: example-rg
            usePublicIp:
              description: Flag for associating public IP addresses to the resources within the network.
              returned: always
              type: bool
        networkCidr:
          description: Range of private IPv4 addresses that resources will use for the Environment.
          returned: always
          type: str
          sample: 10.10.0.0/16
        subnetIds:
          description: Subnet identifiers for the Environment.
          returned: always
          type: list
          elements: str
          sample:
            - ['subnet-04a332603a269535f', 'subnet-07bbea553ca667b66', 'subnet-0aad7d6d9aa66d1e7']
        subnetMetadata:
          description: Additional subnet metadata for the Environment.
          returned: always
          type: complex
          contains:
            __subnetId__:
              description: Keyed subnet identifier.
              returned: always
              type: dict
              contains:
                availabilityZone:
                  description: Availability zone (AWS only)
                  returned: when supported
                  type: str
                  sample: us-west-2a
                subnetId:
                  description: Identifier for the subnet
                  returned: always
                  type: str
                  sample: subnet-04a332603a269535f
                subnetName:
                  description: Name of the subnet
                  returned: always
                  type: str
                  sample: subnet-04a332603a269535f
    proxyConfig:
      description: Proxy configuration of the Environment.
      returned: when supported
      type: dict
      contains:
        proxyConfigName:
          description: Name of the proxy configuration.
          returned: always
          type: str
          sample: the-proxy-config
        crn:
          description: CDP CRN for the proxy configuration.
          returned: always
          type: str
          sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:38eeb2b9-6e57-4d10-ad91-f6d9bceecb54
        description:
          description: Description of the proxy..
          returned: always
          type: str
          sample: The proxy configuration description
        host:
          description: Proxy host.
          returned: always
          type: str
          sample: some.host.example.com
        password:
          description: Proxy user password.
          returned: always
          type: str
          sample: secret_password
        port:
          description: Proxy port.
          returned: always
          type: str
          sample: 8443
        protocol:
          description: Proxy protocol.
          returned: always
          type: str
          sample: https
        user:
          description: Proxy user name.
          returned: always
          type: str
          sample: the_username
    region:
      description: Cloud provider region of the Environment.
      returned: always
      type: str
      sample: us-east-1
    securityAccess:
      description: Security control configuration for FreeIPA and Datalake deployment in the Environment.
      returned: always
      type: dict
      contains:
        cidr:
          description: CIDR range which is allowed for inbound traffic. Either IPv4 or IPv6 is allowed.
          returned: when supported
          type: str
          sample: 0.0.0.0/0
        defaultSecurityGroupId:
          description: Security group associated with Knox-enabled hosts.
          returned: when supported
          type: str
          sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment/providers/Microsoft.Network/networkSecurityGroups/example-default-nsg
        securityGroupIdForKnox:
          description: Security group associated with all other hosts (non-Knox).
          returned: when supported
          type: str
          sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment/providers/Microsoft.Network/networkSecurityGroups/example-knox-nsg
    status:
      description: Status of the Environment.
      returned: always
      type: str
      sample:
        - AVAILABLE
        - CREATE_FAILED
        - CREATION_INITIATED
        - ENV_STOPPED
        - FREEIPA_CREATION_IN_PROGRESS
        - FREEIPA_DELETE_IN_PROGRESS
        - FREEIPA_DELETED_ON_PROVIDER_SIDE
        - START_FREEIPA_FAILED
        - STOP_FREEIPA_STARTED
    statusReason:
      description: Description for the status code of the Environment.
      returned: when supported
      type: str
sdk_out:
  description: Returns the captured CDP SDK log.
  returned: when supported
  type: str
sdk_out_lines:
  description: Returns a list of each line of the captured CDP SDK log.
  returned: when supported
  type: list
  elements: str
'''

display = Display()

CREATION_STATES = [
    'CREATION_INITIATED',
    'FREEIPA_CREATION_IN_PROGRESS'
]

TERMINATION_STATES = [
    'FREEIPA_DELETE_IN_PROGRESS'
]

STARTED_STATES = [
    'AVAILABLE'
]

STOPPED_STATES = [
    'ENV_STOPPED'
]

FAILED_STATES = [
    'CREATE_FAILED'
]

ENV_NAME_PATTERN = re.compile(r'(^[a-z0-9]|[^a-z0-9-]|^.{,4}$|^.{29,}$)')


class Environment(CdpModule):
    def __init__(self, module):
        super(Environment, self).__init__(module)

        self.name = self._get_param('name')
        self.state = self._get_param('state').lower()
        self.cloud = self._get_param('cloud')
        if self.cloud is not None:
            self.cloud = self.cloud.lower()
        self.region = self._get_param('region')
        self.credential = self._get_param('credential')
        self.inbound_cidr = self._get_param('inbound_cidr')
        self.default_sg = self._get_param('default_sg')
        self.knox_sg = self._get_param('knox_sg')
        self.public_key_text = self._get_param('public_key_text')
        self.public_key_id = self._get_param('public_key_id')
        self.log_location = self._get_param('log_location')
        self.log_identity = self._get_param('log_identity')
        self.network_cidr = self._get_param('network_cidr')
        self.vpc_id = self._get_param('vpc_id')
        self.subnet_ids = self._get_param('subnet_ids')
        self.s3_guard_name = self._get_param('s3_guard_name')
        self.tags = self._get_param('tags')
        self.workload_analytics = self._get_param('workload_analytics')
        self.description = self._get_param('description')
        self.tunnel = self._get_param('tunnel')
        self.freeipa = self._get_param('freeipa')
        self.proxy = self._get_param('proxy')
        self.wait = self._get_param('wait')
        self.delay = self._get_param('delay')
        self.timeout = self._get_param('timeout')
        self.cascade = self._get_param('cascade')
        self.force = self._get_param('force')

        # Initialize the return values
        self.environment = dict()
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')

            existing = self._describe_environment(client)

            # TODO SetTelemetryFeaturesRequest

            if self.state in ['present', 'started']:

                # If the environment exists
                if existing is not None:
                    self.environment = existing
                    try:

                        # Reconcile if specifying cloud parameters
                        if self.cloud is not None:
                            # Check to make sure environment state is the same
                            # TODO Delete environment and rebuild if different
                            if existing['cloudPlatform'].lower() != self.cloud:
                                self.module.fail_json(msg="Environment exists in a different cloud platform. "
                                                          "Platform: '%s'" % existing['cloudPlatform'])

                            # Check for changes (except for credentials and cloud platform)
                            mismatch = self._reconcile_existing_state(existing)
                            if mismatch:
                                msg = ''
                                for m in mismatch:
                                    msg += "Parameter '%s' found to be '%s'\n" % (m[0], m[1])
                                self.module.fail_json(msg='Environment exists and differs from expected:\n' + msg,
                                                      violations=mismatch)

                        # Else, only update the credential
                        elif self.credential is not None and existing['credentialName'] != self.credential:
                            self.update_credential(client)

                        # Fail if attempting to restart a failed environment
                        if existing['status'] in FAILED_STATES:
                            self.module.fail_json(msg='Attempting to restart a failed environment')

                        # Warn if attempting to start an environment amidst the creation cycle
                        elif not self.wait and existing['status'] in CREATION_STATES:
                            self.module.warn('Attempting to start an environment during its creation cycle')

                        # Otherwise attempt to start the environment
                        elif existing['status'] not in STARTED_STATES:
                            self.start_environment(client)

                    except KeyError as ke:
                        self.module.fail_json(msg=to_native(ke))

                # Else create the environment
                else:
                    # Catch errors for updating the credential
                    if self.cloud is None:
                        self.module.fail_json(msg="Environment does not exist, or 'cloud' is not defined.")

                    self.create_environment(client)

            elif self.state == 'stopped':
                # If the environment exists
                if existing is not None:

                    # Warn if attempting to stop an already stopped/stopping environment
                    if existing['status'] in STOPPED_STATES:
                        if not self.wait:
                            self.module.warn('Attempting to stop an environment already stopped or in stopping cycle')
                        self.environment = existing

                    # Warn if attempting to stop a terminated/terminating environment
                    elif existing['status'] in TERMINATION_STATES:
                        self.module.fail_json(msg='Attempting to stop a terminating environment', **existing)

                    # Fail if attempting to stop a failed environment
                    elif existing['status'] in FAILED_STATES:
                        self.module.fail_json(msg='Attempting to stop a failed environment', **existing)

                    # Otherwise, stop the environment
                    else:
                        self.stop_environment(client)

                else:
                    self.module.fail_json(msg='Environment does not exist.')

            elif self.state == 'absent':
                # If the environment exists
                if existing is not None:

                    # Warn if attempting to delete an already terminated/terminating environment
                    if not self.wait and existing['status'] in TERMINATION_STATES:
                        self.module.warn('Attempting to delete an environment during the termination cycle')
                        self.environment = existing

                    # Otherwise, delete the environment
                    else:
                        self.delete_environment(client)
            else:
                self.module.fail_json(msg='Invalid state: %s' % self.state)

        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def create_environment(self, client):
        self._validate_environment_name()

        payload = self._configure_payload()

        if self.cloud == 'aws':
            try:
                if not self.module.check_mode:
                    self.environment = client.create_aws_environment(**payload)['environment']
                self.changed = True
            except ClientError as e:
                error = parse_client_error(e)
                if error['status_code'] == '400' and error['msg'] == 'INVALID_ARGUMENT':
                    if error['violations']:
                      if error['violations']['constraintViolations']:
                        fail_msg = "; ".join(error['violations']['constraintViolations'])
                        fail = dict(msg='Environment violated one or more constraints: %s' % fail_msg, rc=3,
                                    operation=error['operation'], status='CONSTRAINT_ERROR')
                        self.module.fail_json(**fail)

                      warn_msg = json.dumps(error['violations'])
                      self.module.warn("Received violation warning:\n%s" % warn_msg)

                    if not self.wait:
                        fail = dict(msg='Environment submitted, yet its state or arguments are invalid. '
                                        'This state may be temporary. Please try again.', rc=2, 
                                        operation=error['operation'], status='STATE_ERROR')
                        if self.debug:
                            log = self.builder.get_log()
                            fail.update(sdk_out=log, sdk_out_lines=log.splitlines())
                        self.module.fail_json(**fail)
                    else:
                        self.environment = dict()
                else:
                    raise e

            if self.wait and not self.module.check_mode:
                self.environment = self._wait_for_state(client, 'AVAILABLE')
        else:
            self.module.fail_json(msg='Azure is not yet implemented')

    def update_credential(self, client):
        if not self.module.check_mode:
            client.change_environment_credential(environmentName=self.name, credentialName=self.credential)
        self.environment = self._describe_environment(client)
        self.changed = True

    def _wait_for_state(self, client, state, fail_state=frozenset(FAILED_STATES)):
        if not isinstance(state, list):
            state = [state]

        timeout = time.time() + self.timeout

        current = self._describe_environment(client)

        while True:
            if current is not None:
                self.module.log('Waiting for status change for Environment, %s. Current status: %s' %
                                (self.name, current['status']))

            if current is not None and current['status'] in state:
                break
            elif current is not None and current['status'] in fail_state:
                fail = 'Environment did not reach expected state(s), %s, encountered failed state, %s' % \
                       (state, current['status'])
                raise Exception(fail)
            else:
                # Check to see if the registration/cloud provider infrastructure failed, which is not reported by
                # describe_environment unfortunately
                env = self._summarize_environment(client)
                if env is not None:
                    if env['status'] in fail_state:
                        fail = 'Environment did not reach expected state(s), %s, encountered failed state, %s' % \
                               (state, env['status'])
                        raise Exception(fail)

                # If the timeout is met
                if time.time() > timeout:
                    fail = 'Environment did not reach expected state(s), %s. Activity timed out.' % state
                    raise Exception(fail)

                time.sleep(self.delay)
                current = self._describe_environment(client)

        return current

    def start_environment(self, client):
        """Start or restart an Environment."""
        try:
            if not self.module.check_mode:
                client.start_environment(environmentName=self.name)
            self.changed = True
        except ClientError as e:
            error = parse_client_error(e)
            if error['status_code'] == '500' and error['operation'] == 'startEnvironment' and error['msg'] == 'UNKNOWN':
                if not self.wait:
                    self.module.warn('Environment is already scheduled to start.')
            else:
                raise e

        if self.wait and not self.module.check_mode:
            self.environment = self._wait_for_state(client, 'AVAILABLE')

    def stop_environment(self, client):
        """Stop an Environment."""
        try:
            if not self.module.check_mode:
                client.stop_environment(environmentName=self.name)
            self.changed = True
        except ClientError as e:
            error = parse_client_error(e)
            if error['status_code'] == '500' and error['operation'] == 'stopEnvironment' and error['msg'] == 'UNKNOWN':
                if not self.wait:
                    self.module.warn('Environment is already scheduled to stop.')
            else:
                raise e

        if self.wait and not self.module.check_mode:
            self.environment = self._wait_for_state(client, 'ENV_STOPPED')

    def delete_environment(self, client):
        """Delete an Environment."""
        if self.cascade:
            self.module.warn('Cascading deletions are currently not supported')

        if self.force:
            self.module.warn('Forced deletions are currently not supported')

        if not self.module.check_mode:
            self.environment = client.delete_environment(environmentName=self.name)
        self.changed = True

        if self.wait and not self.module.check_mode:
            current = self._describe_environment(client)
            while True:
                if current is not None:
                    self.module.log('Waiting for status change for Environment, %s. Current status: %s' %
                                    (self.name, current['status']))
                    time.sleep(self.delay)
                    current = self._describe_environment(client)
                else:
                    break

    def _validate_environment_name(self):
        if re.search(ENV_NAME_PATTERN, self.name) is not None:
            self.module.fail_json(msg="Invalid environment name, '%s'. Names must contain only lowercase "
                                      "letters, numbers, and hyphens, must start with a lowercase letter "
                                      "or a number, and be between 5 and 28 characters" % self.name)

    def _configure_payload(self):
        payload = dict(environmentName=self.name, credentialName=self.credential, region=self.region,
                       enableTunnel=self.tunnel, workloadAnalytics=self.workload_analytics)

        if self.tags is not None:
            payload['tags'] = list()
            for k in self.tags:
                payload['tags'].append(dict(key=k, value=str(self.tags[k])))

        if self.cloud == 'aws':
            payload['logStorage'] = dict(instanceProfile=self.log_identity, storageLocationBase=self.log_location)

            if self.public_key_id is not None:
                payload['authentication'] = dict(publicKeyId=self.public_key_id)
            else:
                payload['authentication'] = dict(publicKey=self.public_key_text)

            if self.description is not None:
                payload['description'] = self.description

            if self.freeipa is not None:
                payload['freeIpa'] = dict(instanceCountByGroup=self.freeipa)

            if self.vpc_id is not None:
                payload['vpcId'] = self.vpc_id
                payload['subnetIds'] = self.subnet_ids
            else:
                payload['networkCidr'] = self.network_cidr

            if self.proxy is not None:
                payload['proxyConfigName'] = self.proxy

            if self.s3_guard_name is not None:
                payload['s3GuardTableName'] = self.s3_guard_name

            if self.inbound_cidr is not None:
                payload['securityAccess'] = dict(cidr=self.inbound_cidr)
            else:
                payload['securityAccess'] = dict(defaultSecurityGroupId=self.default_sg,
                                                 securityGroupIdForKnox=self.knox_sg)
        else:
            self.module.fail_json(msg='Azure not yet implemented')

        return payload

    def _reconcile_existing_state(self, existing):
        mismatch = list()

        if self.region is not None and existing['region'] != self.region:
            mismatch.append(['region', existing['region']])

        if self.tunnel is not None:
            self.module.warn('Environment SSH tunneling specified. Currently, the SSH tunnel setting cannot be '
                             'reconciled. To update the tunneling setting, explicitly delete and recreate the '
                             'environment.')

        if self.workload_analytics is not None:
            self.module.warn('Environment workload analytics specified. Currently, the environment\'s workload '
                             'analytics setting cannot be reconciled. To update the workload analytics setting for the'
                             'environment, explicitly delete and recreate the environment.')

        if self.tags is not None:
            self.module.warn('Environment tags specified. Currently, tags cannot be reconciled. To update tags, '
                             'explicitly delete and recreate the environment.')

        if self.cloud == 'aws':
            if self.log_identity is not None and \
                    existing['logStorage']['awsDetails']['instanceProfile'] != self.log_identity:
                mismatch.append(['log_identity', existing['logStorage']['awsDetails']['instanceProfile']])

            if self.log_location is not None and \
                    existing['logStorage']['awsDetails']['storageLocationBase'] != self.log_location:
                mismatch.append(['log_location', existing['logStorage']['awsDetails']['storageLocationBase']])

            if self.public_key_id is not None or self.public_key_text is not None:
                auth = existing['authentication']
                if self.public_key_id is not None and auth.get('publicKeyId') != self.public_key_id:
                    mismatch.append(['public_key_id', auth.get('publicKeyId')])
                elif auth.get('publicKey') != self.public_key_text:
                    mismatch.append(['public_key_text', auth.get('publicKey')])

            if self.description is not None and existing['description'] != self.description:
                mismatch.append(['description', existing['description']])

            if self.freeipa is not None and len(existing['freeipa']['serverIP']) != self.freeipa:
                mismatch.append(['freeipa', len(existing['freeipa']['serverIP'])])

            if self.vpc_id is not None and existing['network']['aws']['vpcId'] != self.vpc_id:
                mismatch.append(['vpc_id', existing['network']['aws']['vpcId']])

            if self.subnet_ids is not None and set(existing['network']['subnetIds']) != set(self.subnet_ids):
                mismatch.append(['subnetIds', existing['network']['subnetIds']])

            if self.network_cidr is not None and existing['network']['networkCidr'] != self.network_cidr:
                mismatch.append(['network_cidr', existing['network']['networkCidr']])

            if self.s3_guard_name is not None and existing['awsDetails']['s3GuardTableName'] != self.s3_guard_name:
                mismatch.append(['s3_guard_name', existing['awsDetails']['s3GuardTableName']])

            if self.inbound_cidr is not None and existing['securityAccess']['cidr'] != self.inbound_cidr:
                mismatch.append(['inbound_cidr', existing['securityAccess']['cidr']])

            if self.default_sg is not None or self.knox_sg is not None:
                access = existing['securityAccess']
                if self.default_sg is not None and access.get('defaultSecurityGroupId') != self.default_sg:
                    mismatch.append(['default_sg', access.get('defaultSecurityGroupId')])
                if self.knox_sg is not None and access.get('securityGroupIdForKnox') != self.knox_sg:
                    mismatch.append(['knox_sg', access.get('securityGroupIdForKnox')])

            if self.proxy is not None:
                if 'proxyConfig' in existing:
                    if existing['proxyConfig']['proxyConfigName'] != self.proxy:
                        mismatch.append(['proxy', existing['proxyConfig']['proxyConfigName']])
                else:
                    mismatch.append(['proxy', 'n/a'])
            elif 'proxyConfig' in existing:
                mismatch.append(['proxy', existing['proxyConfig']['proxyConfigName']])

        return mismatch

    @staticmethod
    def _get_path(obj, path):
        value = obj
        for p in path:
            value = value.get(p)
            if value is None:
                return None
        return value

    @handle_cdp_error('NOT_FOUND', None, 'environment')
    def _describe_environment(self, client):
        return client.describe_environment(environmentName=self.name)

    def _summarize_environment(self, client):
        result = client.list_environments()
        env_list = result['environments']
        for env in env_list:
            if env['environmentName'] == self.name:
                return env
        return None

    def _get_param(self, parameter):
        """Returns the value of the module parameter or None if no parameter is found"""
        if parameter in self.module.params:
            return self.module.params[parameter]
        else:
            return None


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=True, type='str', aliases=['environment']),
            state=dict(required=False, type='str', choices=['present', 'started', 'stopped', 'absent'],
                       default='present'),
            cloud=dict(required=False, type='str', choices=['aws', 'azure']),
            region=dict(required=False, type='str'),
            credential=dict(required=False, type='str'),
            inbound_cidr=dict(required=False, type='str', aliases=['security_cidr']),
            default_sg=dict(required=False, type='str', aliases=['default', 'default_security_group']),
            knox_sg=dict(required=False, type='str', aliases=['knox', 'knox_security_group']),
            public_key_text=dict(required=False, type='str', aliases=['ssh_key_text']),
            public_key_id=dict(required=False, type='str', aliases=['public_key', 'ssh_key', 'ssh_key_id']),
            log_location=dict(required=False, type='str', aliases=['storage_location_base']),
            log_identity=dict(required=False, type='str', aliases=['instance_profile']),
            network_cidr=dict(required=False, type='str'),
            vpc_id=dict(required=False, type='str', aliases=['vpc']),
            subnet_ids=dict(required=False, type='list', elements='str', aliases=['subnets']),
            s3_guard_name=dict(required=False, type='str', aliases=['s3_guard', 's3_guard_table_name']),
            tags=dict(required=False, type='dict', aliases=['environment_tags']),
            workload_analytics=dict(required=False, type='bool', default=True),
            description=dict(required=False, type='str', aliases=['desc']),
            tunnel=dict(required=False, type='bool', aliases=['enable_tunnel', 'ssh_tunnel'], default=False),
            freeipa=dict(required=False, type='dict', options=dict(instanceCountByGroup=dict(required=False,
                                                                                             type='int'))),
            proxy=dict(required=False, type='str', aliases=['[proxy_config', 'proxy_config_name']),
            cascade=dict(required=False, type='bool', default=False),
            force=dict(required=False, type='bool', default=False),
            wait=dict(required=False, type='bool', default=True),
            delay=dict(required=False, type='int', aliases=['polling_delay'], default=15),
            timeout=dict(required=False, type='int', aliases=['polling_timeout'], default=3600)
        ),
        required_if=[
            ['state', 'present', ('cloud', 'credential'), True],
            ['cloud', 'aws', ('public_key', 'public_key_id'), True],
            ['cloud', 'aws', ('network_cidr', 'vpc_id'), True],
            ['cloud', 'aws', ('inbound_cidr', 'default_sg', 'knox_sg'), True]
        ],
        required_by={
            'cloud': ('region', 'credential', 'log_location', 'log_identity'),
        },
        mutually_exclusive=[
            ['network_cidr', 'vpc_id'],
            ['network_cidr', 'subnet_ids'],
            ['public_key', 'public_key_id'],
            ['inbound_cidr', 'default_sg'],
            ['inbound_cidr', 'knox_sg']
        ],
        required_together=[
            ['vpc_id', 'subnet_ids'],
            ['default_sg', 'knox_sg']
        ],
        supports_check_mode=True
    )

    result = Environment(module)
    output = dict(changed=result.changed, environment=result.environment)

    if result.debug:
        output.update(sdk_out=result.log_out, sdk_out_lines=result.log_lines)

    module.exit_json(**output)


if __name__ == '__main__':
    main()
