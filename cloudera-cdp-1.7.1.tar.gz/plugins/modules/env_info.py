#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_info
short_description: Gather information about CDP Environments
description:
    - Gather information about CDP Environments
author:
  - "Webster Mudge (@wmudge)"
  - "Dan Chaffelson (@chaffelson)"
  - "Christian Leroy (cleroy@cloudera.com)"
requirements:
  - cdpcli
options:
  name:
    description:
      - If a name is provided, that environment will be described
      - If no name is provided, all environments will be listed
    type: str
    required: False
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# List basic information about all Environments
- cloudera.cdp.env_info:

# Gather detailed information about a named Environment
- cloudera.cdp.env_info:
    name: example-environment
'''

RETURN = '''
environments:
  description: The information about the named Environment or Environments
  type: list
  returned: on success
  elements: complex
  contains:
    authentication:
      description: Additional SSH key authentication configuration for accessing cluster node instances of the Environment.
      returned: always
      type: dict
      contains:
        loginUserName:
          description: SSH user name created on the node instances for SSH access.
          type: str
          returned: always
          sample: cloudbreak
        publicKey:
          description: SSH Public key string
          type: str
          returned: when supported
          sample: ssh-rsa AAAAB3NzaC...BH example-public-key
        publicKeyId:
          description: Public SSH key ID registered in the cloud provider.
          type: str
          returned: when supported
          sample: a_labeled_public_key
    awsDetails:
      description: AWS-specific environment configuration information.
      returned: when supported
      type: dict
      contains:
        s3GuardTableName:
          description: The name for the DynamoDB table backing S3Guard.
          type: str
          returned: always
          sample: table_name
    cloudPlatform:
      description: Cloud provider of the Environment.
      returned: always
      type: str
      sample:
        - AWS
        - AZURE
    credentialName:
      description: Name of the CDP Credential of the Environment.
      returned: always
      type: str
      sample: a-cdp-credential
    crn:
      description: CDP CRN value for the Environment.
      returned: always
      type: str
      sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:61eb5b97-226a-4be7-b56d-795d18a043b5
    description:
      description: Description of the Environment.
      returned: always
      type: str
      sample: An example Environment
    environmentName:
      description: Name of the Environment.
      returned: always
      type: str
      sample: a-cdp-environment-name
    freeipa:
      description: Details of a FreeIPA instance in the Environment.
      returned: always
      type: complex
      contains:
        crn:
          description: CRN of the FreeIPA instance.
          returned: always
          type: str
          sample: crn:cdp:freeipa:us-west-1:558bc1d2-8867-4357-8524-311d51259233:freeipa:cbab8ee3-00f2-4958-90c1-6f7cc06b4937
        domain:
          description: Domain name of the FreeIPA instance.
          returned: always
          type: str
          sample: example.012345-abcd.cloudera.site
        hostname:
          description: Hostname of the FreeIPA instance.
          returned: always
          type: str
          sample: ipaserver
        serverIP:
          description: IP addresses of the FreeIPA instance.
          returned: always
          type: list
          elements: str
          sample:
            - ['10.10.2.40']
    logStorage:
      description: Storage configuration for cluster and audit logs for the Environment.
      returned: always
      type: complex
      contains:
        awsDetails:
          description: AWS-specific log storage configuration details.
          returned: when supported
          type: dict
          contains:
            instanceProfile:
              description: AWS instance profile that contains the necessary permissions to access the S3 storage location.
              returned: always
              type: str
              sample: arn:aws:iam::381358652250:instance-profile/EXAMPLE-LOG_ROLE
            storageLocationBase:
              description: Base location to store logs in S3.
              returned: always
              type: str
              sample: s3a://example-bucket/datalake/logs
        azureDetails:
          description: Azure-specific log storage configuration details.
          returned: when supported
          type: dict
          contains:
            managedIdentity:
              description:
                - Azure managing identity associated with the logger.
                - This identify should have the Storage Blob Data Contributor role on the given storage account.
              returned: always
              type: str
              sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment-name/providers/Microsoft.ManagedIdentity/userAssignedIdentities/loggerIdentity
            storageLocationBase:
              description: Base location to store logs in Azure Blob Storage.
              returned: always
              type: str
              sample: abfs://logs@example_location.dfs.core.windows.net
        enabled:
          description: Flag for external log storage.
          returned: always
          type: bool
    network:
      description: Network details for the Environment
      returned: always
      type: complex
      contains:
        aws:
          description: AWS networking specifics for the Environment.
          returned: when supported
          type: dict
          contains:
            vpcId:
              description: VPC identifier.
              returned: always
              type: str
              sample: vpc-08785c81e888251df
        azure:
          description: Azure networking specifics for the Environment.
          returned: when supported
          type: dict
          contains:
            networkId:
              description: VNet identifier.
              returned: always
              type: str
              sample: example-vnet
            resourceGroupName:
              description: Resource Group name.
              returned: always
              type: str
              sample: example-rg
            usePublicIp:
              description: Flag for associating public IP addresses to the resources within the network.
              returned: always
              type: bool
        networkCidr:
          description: Range of private IPv4 addresses that resources will use for the Environment.
          returned: always
          type: str
          sample: 10.10.0.0/16
        subnetIds:
          description: Subnet identifiers for the Environment.
          returned: always
          type: list
          elements: str
          sample:
            - ['subnet-04a332603a269535f', 'subnet-07bbea553ca667b66', 'subnet-0aad7d6d9aa66d1e7']
        subnetMetadata:
          description: Additional subnet metadata for the Environment.
          returned: always
          type: complex
          contains:
            __subnetId__:
              description: Keyed subnet identifier.
              returned: always
              type: dict
              contains:
                availabilityZone:
                  description: Availability zone (AWS only)
                  returned: when supported
                  type: str
                  sample: us-west-2a
                subnetId:
                  description: Identifier for the subnet
                  returned: always
                  type: str
                  sample: subnet-04a332603a269535f
                subnetName:
                  description: Name of the subnet
                  returned: always
                  sample: subnet-04a332603a269535f
    proxyConfig:
      description: Proxy configuration of the Environment.
      returned: when supported
      type: dict
      contains:
        proxyConfigName:
          description: Name of the proxy configuration.
          returned: always
          type: str
          sample: the-proxy-config
        crn:
          description: CDP CRN for the proxy configuration.
          returned: always
          type: str
          sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:38eeb2b9-6e57-4d10-ad91-f6d9bceecb54
        description:
          description: Description of the proxy..
          returned: always
          type: str
          sample: The proxy configuration description
        host:
          description: Proxy host.
          returned: always
          type: str
          sample: some.host.example.com
        password:
          description: Proxy user password.
          returned: always
          type: str
          sample: secret_password
        port:
          description: Proxy port.
          returned: always
          type: str
          sample: 8443
        protocol:
          description: Proxy protocol.
          returned: always
          type: str
          sample: https
        user:
          description: Proxy user name.
          returned: always
          type: str
          sample: the_username
    region:
      description: Cloud provider region of the Environment.
      returned: always
      type: str
      sample: us-east-1
    securityAccess:
      description: Security control configuration for FreeIPA and Datalake deployment in the Environment.
      returned: always
      type: dict
      contains:
        cidr:
          description: CIDR range which is allowed for inbound traffic. Either IPv4 or IPv6 is allowed.
          returned: when supported
          type: str
          sample: 0.0.0.0/0
        defaultSecurityGroupId:
          description: Security group associated with Knox-enabled hosts.
          returned: when supported
          type: str
          sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment/providers/Microsoft.Network/networkSecurityGroups/example-default-nsg
        securityGroupIdForKnox:
          description: Security group associated with all other hosts (non-Knox).
          returned: when supported
          type: str
          sample: /subscriptions/01234-56789-abcd/resourceGroups/example-environment/providers/Microsoft.Network/networkSecurityGroups/example-knox-nsg
    status:
      description: Status of the Environment.
      returned: always
      type: str
      sample:
        - AVAILABLE
        - CREATE_FAILED
        - CREATION_INITIATED
        - ENV_STOPPED
        - FREEIPA_CREATION_IN_PROGRESS
        - FREEIPA_DELETE_IN_PROGRESS
        - FREEIPA_DELETED_ON_PROVIDER_SIDE
        - START_FREEIPA_FAILED
        - STOP_FREEIPA_STARTED
    statusReason:
      description: Description for the status code of the Environment.
      returned: when supported
      type: str
sdk_out:
  description: Returns the captured CDP SDK log.
  returned: when supported
  type: str
sdk_out_lines:
  description: Returns a list of each line of the captured CDP SDK log.
  returned: when supported
  type: list
  elements: str
'''


class EnvironmentInfo(CdpModule):
    def __init__(self, module):
        super(EnvironmentInfo, self).__init__(module)

        # Set variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None

        # Initialize return values
        self.environments = []

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')

            if self.name is not None:
                env_single = self.describe_environment(client, self.name)
                if env_single is not None:
                    self.environments.append(env_single)
            else:
                env_list = self.list_environments(client)
                if env_list:
                    for env in env_list:
                        desc = self.describe_environment(client, env['environmentName'])
                        if desc is None:
                            self.module.warn("Unable to describe '%s'" % env['environmentName'])
                        else:
                            self.environments.append(desc)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        self.log_out = self.builder.get_log()
        self.log_lines = self.log_out.splitlines()

    @handle_cdp_error('NOT_FOUND', None, 'environment')
    def describe_environment(self, client, name):
        return client.describe_environment(environmentName=name)

    @handle_cdp_error('NOT_FOUND', list(), 'environments')
    def list_environments(self, client):
        return client.list_environments()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='str', aliases=['environment'])
        ),
        supports_check_mode=True
    )

    result = EnvironmentInfo(module)
    output = dict(changed=False, environments=result.environments)

    if result.debug:
        output.update(sdk_out=result.log_out, sdk_out_lines=result.log_lines)

    module.exit_json(**output)


if __name__ == '__main__':
    main()
