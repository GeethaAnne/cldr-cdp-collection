#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2019, Cloudera
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: ranger_api

short_description: Wrapper for the Ranger API

version_added: "2.8"

description:
    - Ansible wrapper module for the Ranger API
    - Consult the official API doc for a list of all functions.


options:
    username:
        description:
            - Ranger username
        default: "admin"
        type: str
    
    password:
        description:
            - Ranger password
        default: "admin"
        type: str
    
    protocol:
        description:
            - Either HTTP or HTTPS
        default: "http"
        type: str

    host:
        description:
            - Ranger host
        default: "localhost"
        type: str
    
    port:
        description:
            - Ranger port
        default: "6080"
        type: str
    
    path:
        description:
            - URL path to the Ranger API endpoint
        default: "/service"
        type: str

    verify_ssl:
        description:
            - whether to check for ssl cert
        default: False
        type: bool

    name:
        description:
            - The API function to run. The function name built by concatenating 
              - the request method (GET, POST, DELETE, PUT), 
              - two underscores `__`, 
              - the API endpoint replaced with underscores

    args:
        description:
            - The dict or string of arguments

requirements: [ "requests" ]

author:
    - Cloudera
'''

EXAMPLES = '''
# Get the list of roles
ranger_api:
    # parameters for the Ranger ApiClient
    username: admin
    password: admin
    
    protocol: https
    host: mydomain.com
    port: 443
    path: "/service"

    name: GET__public_v2_api_roles

# Create a new role
ranger_api:
    # parameters for the Ranger ApiClient
    username: admin
    password: admin
    
    protocol: https
    host: mydomain.com
    port: 443
    path: "/service"

    name: POST__public_v2_api_roles
    args:
        options: {}
        name: new_role
        createdByUser: admins
        description: admins
        groups: 
        - isAdmin: true
            name: admin_group1
        roles: []
        users: []
        isEnabled: true
'''

RETURN = '''
result:
    description: The response that the module generates
    type: dict
    returned: always
'''

import json
import requests
from ansible.module_utils.basic import AnsibleModule

def GET__public_v2_api_roles(api_client, args):
    """
    """
    return requests.get("%s/public/v2/api/roles" % (api_client.url), 
        auth=api_client.auth,
        verify=api_client.verify_ssl)


def POST__public_v2_api_roles(api_client, args):
    """
    args:
      ranger_role:
        options: {}
        name: admins
        createdByUser: admin
        description: admins
        groups: 
        - isAdmin: true
            name: admin_users
        roles: []
        users: []
        isEnabled: true
    """
    data = args['ranger_role']

    return requests.post("%s/public/v2/api/roles" % (api_client.url), 
        auth=api_client.auth,
        json=data,
        verify=api_client.verify_ssl)


def GET__public_v2_api_policy_id(api_client, args):
    """
    """
    policy_id = args['policy_id']

    return requests.get("%s/public/v2/api/policy/%s" % (api_client.url, policy_id), 
        auth=api_client.auth,
        verify=api_client.verify_ssl)


def PUT__public_v2_api_policy_id(api_client, args):
    """
    args:
        policy_id: 7
        ranger_policy: 
    """
    policy_id = args['policy_id']
    data = args['ranger_policy']

    return requests.put("%s/public/v2/api/policy/%s" % (api_client.url, policy_id), 
        auth=api_client.auth,
        json=data,
        verify=api_client.verify_ssl)


def GET__public_v2_api_policy(api_client, args):
    """
    """
    return requests.get("%s/public/v2/api/policy" % (api_client.url), 
        auth=api_client.auth,
        verify=api_client.verify_ssl)


def POST__public_v2_api_policy(api_client, args):
    """
    args:
        policy_id: 7
        ranger_policy: 
    """
    data = args['ranger_policy']

    return requests.post("%s/public/v2/api/policy" % (api_client.url), 
        auth=api_client.auth,
        json=data,
        verify=api_client.verify_ssl)


def main():
    result = {}
    # dict of all functions in Ranger API
    functions = {
        "GET__public_v2_api_roles": GET__public_v2_api_roles,
        "POST__public_v2_api_roles": POST__public_v2_api_roles,
        "GET__public_v2_api_policy_id": GET__public_v2_api_policy_id,
        "PUT__public_v2_api_policy_id": PUT__public_v2_api_policy_id,
        "GET__public_v2_api_policy" : GET__public_v2_api_policy,
        "POST__public_v2_api_policy": POST__public_v2_api_policy,
    }

    module = AnsibleModule(
        argument_spec=dict(
            # parameters for the Ranger ApiClient
            username=dict(type='str', default="admin"),
            password=dict(type='str', no_log=True, default="admin"),
            
            protocol=dict(type='str', default="http"),
            host=dict(type='str', default="localhost"),
            port=dict(type='str', default="6080"),
            path=dict(type='str', default="/service"),

            verify_ssl=dict(type='bool', default=False),

            # name of the function to run
            name=dict(type='str'),

            # args, if any
            args=dict(type='dict', default={}),
        ),
        supports_check_mode=True,
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # Setup cRanger ApiClient Configuration
    api_client = build_ApiClient(module.params)

    # Run the function specified in the module
    r = functions.get(
        module.params['name'])(api_client, module.params["args"])
    
    try:
        result['result'] = r.json()
    except:
        result['result'] = r.text


    if r.ok:
        module.exit_json(**result)
    else:
        module.fail_json(
            msg={
                "status_code" : r.status_code, 
                "content" : r.content,
                "reason" : r.reason}, 
            **result)


#
# Builders
#
def build_ApiClient(d):
    """
    Build a ApiClient obj from a dict
    
    Args:
        dict
    
    Return:
        ApiClient
    """

    url = "%s://%s:%s%s" % (
        d['protocol'],
        d["host"], 
        d["port"], 
        d["path"])
    
    return ApiClient(d['username'], d['password'], url, d['verify_ssl'])

class ApiClient:
    def __init__(self, username, password, url, verify_ssl):
        self.auth = (username, password)
        self.url = url
        self.verify_ssl = verify_ssl   

if __name__ == '__main__':
    main()
