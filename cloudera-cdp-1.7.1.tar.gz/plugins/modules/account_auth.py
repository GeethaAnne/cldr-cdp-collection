#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: account_auth
short_description: Gather and set authentication details for a CDP Account
description:
  - Gather and set information for a CDP account.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  enable_sso:
    description:
      - Flag to enable or disable interactive login using the Cloudera SSO for the account.
      - When disabled, only users who are designated account administrators will be able to use Cloudera SSO to login interactively to the account.
      - All other users will only be able to login interactively using other SAML providers defined for the account.
    type: bool
    required: False
    aliases:
      - sso
      - enable_cloudera_sso
  password_lifetime:
    description:
      - The maximum lifetime of workload passwords for the account, in days.
      - If set to C(0), passwords never expire.
      - Changes to the workload password lifetime only affect passwords that are set after the policy has been updated.
    type: int
    required: False
    aliases:
      - workload_password_lifetime
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Disable Cloudera SSO login for all non-admin users
- cloudera.cdp.account_auth:
    disable_sso: yes

# Set the password expiration to 7 days
- cloudera.cdp.account_auth:
    password_lifetime: 7
'''

RETURN = '''
---
account:
    description: Returns the authentication settings for the CDP Account
    returned: always
    type: dict
    contains:
        clouderaSSOLoginEnabled:
            description: Flag indicating whether interactive login using Cloudera SSO is enabled.
            returned: always
            type: bool
        workloadPasswordPolicy:
            description: Information about the workload password policy for an account.
            returned: always
            type: dict
            contains:
                maxPasswordLifetimeDays:
                    description: The max lifetime, in days, of the password. If '0', passwords never expire.
                    returned: always
                    type: int
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class AccountAuthentication(CdpModule):
    def __init__(self, module):
        super(AccountAuthentication, self).__init__(module)

        # Set variables
        self.enable_sso = self.module.params['enable_sso'] if 'enable_sso' in self.module.params else None
        self.password_lifetime = self.module.params['password_lifetime'] if 'password_lifetime' in self.module.params else None

        # Initialize the return values
        self.changed = False
        self.account = dict()

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('iam')

            self.account = self._retrieve_account_authentication(client)

            if not self.module.check_mode:
                if self.enable_sso is not None and self.enable_sso != self.account['clouderaSSOLoginEnabled']:
                    self.set_sso_login(client)

                if self.password_lifetime is not None and self.password_lifetime != self.account['workloadPasswordPolicy']['maxPasswordLifetimeDays']:
                    self.set_password_lifetime(client)

            if self.changed:
                self.account = self._retrieve_account_authentication(client)

        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    @handle_cdp_error('NOT_FOUND', None, 'account')
    def _retrieve_account_authentication(self, client):
        return client.get_account()

    def set_sso_login(self, client):
        if self.enable_sso:
            client.enable_cloudera_sso_login()
        else:
            client.disable_cloudera_sso_login()
        self.changed = True

    def set_password_lifetime(self, client):
        client.set_workload_password_policy(maxPasswordLifetimeDays=self.password_lifetime)
        self.changed = True


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            enable_sso=dict(required=False, type='bool', aliases=['sso', 'enable_cloudera_sso']),
            password_lifetime=dict(required=False, type='int', no_log=False, aliases=['workload_password_lifetime'])
        ),
        supports_check_mode=True
    )

    result = AccountAuthentication(module)

    output = dict(
        changed=result.changed,
        account=result.account,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
