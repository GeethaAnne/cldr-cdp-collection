#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = r'''
---
module: account_auth_info
short_description: Gather information about CDP Account authentication settings
description:
  - Gather information about the authentication settings for a CDP Account.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  debug:
    description:
      - Flag to capture and return the debugging log of the underlying CDP SDK.
      - If set, the log level will be set from ERROR to DEBUG.
    aliases:
      - debug_cdpsdk
    default: False
    type: bool
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = r'''
# Note: These examples do not set authentication details.

# Gather information about the Account authentication settings
- cloudera.cdp.account_auth_info:
'''

RETURN = r'''
---
account:
    description: Returns the authentication settings for the CDP Account
    returned: always
    type: dict
    contains:
        clouderaSSOLoginEnabled:
            description: Flag indicating whether interactive login using Cloudera SSO is enabled.
            returned: always
            type: bool
        workloadPasswordPolicy:
            description: Information about the workload password policy for an account.
            returned: always
            type: dict
            contains:
                maxPasswordLifetimeDays:
                    description: The max lifetime, in days, of the password. If '0', passwords never expire.
                    returned: always
                    type: int
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class AccountAuthenticationInfo(CdpModule):
    def __init__(self, module):
        super(AccountAuthenticationInfo, self).__init__(module)

        # Initialize the return values
        self.account = dict()
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('iam')
            self.account = self.retrieve_auth(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    @handle_cdp_error('NOT_FOUND', None, 'account')
    def retrieve_auth(self, client):
        return client.get_account()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(),
        supports_check_mode=True
    )

    result = AccountAuthenticationInfo(module)

    output = dict(
        changed=False,
        account=result.account,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
