#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2020, Cloudera
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

import ansible_collections.cloudera.cdp.plugins.module_utils.cloudera as cldr
import json
from operator import itemgetter
from ansible.module_utils.basic import AnsibleModule

try:
    import cm_client
    from cm_client.rest import ApiException
except ImportError:
    raise ImportError(
        'pip package cm_client could not be imported. Is it installed?')

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: cm_roleconfiggroups

short_description: Creates, updates and deletes role config groups for a given cluster

version_added: "2.9.5"

description:
    - "Creates, updates and deletes new role config groups for a given cluster"

options:
    username:
        description:
            - Cloudera Manager username
        default: "admin"
        type: str

    password:
        description:
            - Cloudera Manager password
        default: "admin"
        type: str

    protocol:
        description:
            - Cloudera Manager protocol
        default: "https"
        type: str
        choices: [ "http" , "https" ]

    host:
        description:
            - Cloudera Manager host
        default: "localhost"
        type: str

    port:
        description:
            - Cloudera Manager port
        default: 443
        type: int

    path:
        description:
            - Cloudera Manager path to API
        default: "/api/v40"
        type: str

    verify_ssl:
        description:
            - Whether to verify SSL connection
        default: "yes"
        type: bool


    state:
        description:
            - The service reference (service name and cluster name) of this group.
        type: str
        choices: ['present', 'absent']
        required: true
    
    restart:
        description:
            - Request to restart the service, usually after you request a config update.
        type: str
        choices: ['always', 'never', 'on_change']
        default: "never"

    cluster_name:
        description:
            - The cluster name
        type: str
        required: true

    service_name:
        description:
            - The name of the service for which you want to get the role config groups info
        type: str
        required: true
    
    comment:
        description:
            - The message to be recorded on creations or updates
        type: str
        default: ""


    name:
        description:
            - The unique name of this role config group.
        type: str

    role_type:
        description:
            - The type of the roles in this group.
        type: str

    base:
        description:
            - Indicates whether this is a base group.
        type: bool
    
    display_name:
        description:
            - The display name of this group.
        type: str
    
    config:
        description:
            - The configuration for this group
        type: dict
    
    service_ref:
        description:
            - The service reference (service name and cluster name) of this group.
        type: dict
    

requirements: [ "cm_client" ]

author:
    - Cloudera
'''

EXAMPLES = '''
# Create, or update, a Role Config Group
- cm_roleconfiggroups:
    # control
    state: present

    # parameters for ApiClient
    username: admin
    password: admin
    protocol: http
    host: myhostname
    port: 7180
    path: /api/v40
    verify_ssl: no

    # module specific
    cluster_name: MyCluster
    service_name: atlas
    comment: my new rcg

    # Role Config Group details
    name: atlas-ATLAS_SERVER-MYCONFIG
    role_type: ATLAS_SERVER
    base: no
    display_name: my-atlas-server
    config: 
      items:
        - name: "conf/ranger-atlas-audit.xml_role_safety_valve"
          value: "<property><name>xasecure.audit.destination.hdfs</name><value>true</value><description>atlas fix</description></property>"
          sensitive: false
        - name: "conf/atlas-application.properties_role_safety_valve"
          value: "atlas.graph.index.search.solr.create-client-per-request=false"
          sensitive: false
        
    service_ref:
      cluster_name: MyCluster
      peer_name: null
      service_display_name: null
      service_name: atlas
      service_type: null


# Delete a role config group.
- cm_roleconfiggroups:
    # control
    state: absent

    # parameters for ApiClient
    username: admin
    password: admin
    protocol: http
    host: myhostname
    port: 7180
    path: /api/v40
    verify_ssl: no

    # module specific
    cluster_name: MyCluster
    service_name: atlas
    comment: my new rcg

    # Role Config Group details
    name: atlas-ATLAS_SERVER-MYCONFIG

'''

RETURN = '''
out:
    description: The response that the module generates
    type: dict
    returned: always
meta:
    description: The parameters passed
    type: dict
    returned: always
'''


valid_states = ['absent', 'present']
restart_modes = ['always', 'never', 'on_change']


class Client(object):
    # Setup
    def __init__(self, module):
        self.module = module

        # Extracting variables from all args for readability
        self.state = self.module.params['state']
        self.restart = self.module.params['restart']

        # parameters for ApiClient
        self.username = self.module.params['username']
        self.password = self.module.params['password']
        self.protocol = self.module.params['protocol']
        self.host = self.module.params['host']
        self.port = self.module.params['port']
        self.path = self.module.params['path']
        self.verify_ssl = self.module.params['verify_ssl']

        # module specific
        self.cluster_name = self.module.params['cluster_name']
        self.service_name = self.module.params['service_name']
        self.message = self.module.params['comment']

        # Role Config Group details
        self.name = self.module.params['name']
        self.role_type = self.module.params['role_type']
        self.base = self.module.params['base']
        self.display_name = self.module.params['display_name']
        self.config = self.module.params['config']
        self.service_ref = self.module.params['service_ref']

        # Outputs
        self.changed = False
        self.out = None

        # Finally, call main process
        self.process()

    # Control Logic
    def process(self):
        # Create the CM API Client
        self.client = cldr.build_ApiClient(self.module.params)

        if self.state == 'present':
            self.ensure_present()
        elif self.state == 'absent':
            self.ensure_absent()
        else:
            self.module.fail_json(msg="Unexpected State: " + self.state)

        if self.restart == "always" or (self.restart == "on_change" and self.changed):
            self.restart_service()

    def ensure_present(self):

        if self.config is None:
            self.module.fail_json(meta=self.module.params,
                                  msg="Mandatory field Config is missing")

        # check whether the role exists
        current_rcg = self.get_role_config_group()

        if current_rcg is None:
            # there is not such role so we need to create it
            self.create_role_config_group()
            self.changed = True

        else:
            # there is already a role with this name
            if not self.are_role_config_group_equals(current_rcg.to_dict()):
                # requested and current role are not quite the same so need to update it
                self.update_role_config_group()
                self.changed = True
            else:
                # the requested and current role are the same, nothing to do
                self.changed = False
                self.out = current_rcg.to_dict()

    def ensure_absent(self):

        # check whether the role exists or it was already deleted
        if self.get_role_config_group() is not None:
            self.delete_role_config_group()
            self.changed = True

        else:
            # role doesn't exist, so nothing to do
            self.changed = False
            self.out = {}

    def restart_service(self):
        api = cm_client.ServicesResourceApi(self.client)

        try:
            apiCommand = api.restart_command(
                self.cluster_name, self.service_name)

            cldr.wait(apiCommand, self.client)

        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def are_role_config_group_equals(self, d):
        a = self.remove_null_values(self.build_rcg_dict())
        b = self.remove_null_values(d)
        return a == b

    def remove_null_values(self, d):
        e = {}
        for k, v in d.items():
            if v is not None:
                if isinstance(v, dict):
                    e[k] = self.remove_null_values(v)
                elif isinstance(v, list):
                    v = sorted(v, key=itemgetter('name'), reverse=True)
                    e[k] = [self.remove_null_values(x) for x in v]
                else:
                    e[k] = v
        return e

    def get_role_config_group(self):

        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        try:
            apiRoleConfigGroupList = api.read_role_config_groups(
                self.cluster_name, self.service_name)

            for apiRoleConfigGroup in apiRoleConfigGroupList.items:
                if apiRoleConfigGroup.name == self.name:
                    return apiRoleConfigGroup

            return None
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def create_role_config_group(self):

        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        # The API call expects a ApiRoleConfigGroupList obj
        d = {"items": [self.build_rcg_dict()]}

        apiRoleConfigGroupList = cldr.build_ApiRoleConfigGroupList(d)

        try:
            apiRoleConfigGroupList = api.create_role_config_groups(
                self.cluster_name, self.service_name, body=apiRoleConfigGroupList)
            self.changed = True
            self.out = apiRoleConfigGroupList.items[0].to_dict()
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def update_role_config_group(self):

        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        apiRoleConfigGroup = cldr.build_ApiRoleConfigGroup(
            self.build_rcg_dict())

        try:
            api.update_role_config_group(
                self.cluster_name, self.name, self.service_name, message=self.message, body=apiRoleConfigGroup)
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def delete_role_config_group(self):

        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        try:
            apiRoleConfigGroup = api.delete_role_config_group(
                self.cluster_name, self.name, self.service_name)

            self.out = apiRoleConfigGroup.to_dict()
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def build_rcg_dict(self):
        return {"name": self.name,
                "role_type": self.role_type,
                "base": self.base,
                "config": self.config,
                "display_name": self.display_name,
                "service_ref": self.service_ref
                }


def main():
    module = AnsibleModule(
        argument_spec=dict(
            # control
            state=dict(type='str', required=True, choices=valid_states),
            restart=dict(type='str', default="never", choices=restart_modes),

            # parameters for ApiClient
            username=dict(type='str', default="admin"),
            password=dict(type='str', no_log=True, default="admin"),
            protocol=dict(type='str', choice=[
                          'http', 'https'], default="https"),
            host=dict(type='str', default="localhost"),
            port=dict(type='int', default=443),
            path=dict(type='str', default="/api/v40"),
            verify_ssl=dict(type='bool', default=True),

            # module specific
            cluster_name=dict(required=True, type='str'),
            service_name=dict(required=True, type='str'),
            comment=dict(type='str', dafault=""),

            # Role Config Group details
            name=dict(type='str', default=None),
            role_type=dict(type='str', dafault=None),
            base=dict(type='bool', dafault=False),
            display_name=dict(type='str', dafault=None),
            config=dict(type='dict', dafault=None),
            service_ref=dict(type='dict', dafault=None),

        ),
        supports_check_mode=False,
    )

    result = Client(module)
    module.exit_json(meta=module.params,
                     changed=result.changed, out=result.out)


if __name__ == '__main__':
    main()
