#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: account_cred_info
short_description: Gather information about Account prerequisites for CDP Credentials
description:
  - Gather prerequisites information from the Account for creating CDP Credentials using the CDP SDK.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  cloud:
    description:
      - Designates the cloud provider for the credential prerequisites.
    type: str
    required: True
    choices:
      - aws
      - azure
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Gather information about the AWS account credential prerequisites
- cloudera.cdp.account_cred_info:
    cloud: aws
'''

RETURN = '''
prerequisites:
    description: Returns a dictionary of the specific cloud provider prerequisites for Credentials
    returned: always
    type: dict
    contains:
        account_id:
            description: The account identifier for the CDP installation.
            returned: always
            type: str
            sample: 3875500000000
        external_id:
            description: The AWS cross-account identifier for the CDP installation.
            returned: when supported
            type: str
            sample: 32b18f82-f868-414f-aedc-b3ee137560e3
        policy:
            description: The policy definition, returned as a base64 string.
            returned: always
            type: str
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class AccountCredentialInfo(CdpModule):
    def __init__(self, module):
        super(AccountCredentialInfo, self).__init__(module)

        # Set variables
        self.cloud = self.module.params['cloud']

        # Initialize the return values
        self.prerequisites = dict()

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')

            if not self.module.check_mode:
                result = client.get_credential_prerequisites(cloudPlatform=self.cloud.upper())

                if self.cloud == 'aws':
                    self.prerequisites.update(external_id=result['aws']['externalId'],
                                              policy=result['aws']['policyJson'])
                else:
                    self.module.fail_json(msg='Azure not yet supported')

                self.prerequisites.update(account_id=result['accountId'])

        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            cloud=dict(required=True, type='str', aliases=['cloud_platform'], choices=['aws', 'azure'])
        ),
        supports_check_mode=True
    )

    result = AccountCredentialInfo(module)

    output = dict(
        changed=False,
        prerequisites=result.prerequisites,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
