#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule

from azure.storage.file import FileService
from azure.storage.file import ContentSettings

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = r''' # '''

def main():
    module = AnsibleModule(
        argument_spec=dict(
            bucket=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )

    file_service = FileService(account_name='myaccount', account_key='mykey')
    
    file_service.create_file_from_path(
    'myshare',
    None,  # We want to create this blob in the root directory, so we specify None for the directory_name
    'myfile',
    'sunset.png',
    content_settings=ContentSettings(content_type='image/png'))

    module.exit_json(changed=True, result=data)


if __name__ == '__main__':
    main()