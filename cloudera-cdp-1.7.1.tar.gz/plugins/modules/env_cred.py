#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
from time import sleep

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error, \
    handle_cdp_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_cred
short_description: Create, update, and destroy CDP credentials
description:
  - Create, update, and destroy CDP credentials.
  - The module support check_mode.
author:
  - "Webster Mudge (@wmudge)"
  - "Daniel Chaffelson (@chaffelson)"
requirements:
  - cdpcli
options:
  name:
    description:
      - The name of the Credential.
      - The name must conform to the CDP Credential format, which is lowercase letters, numbers, and hyphens only.
    aliases:
      - credential
    required: True
    type: str
  state:
    description:
      - Establish the state of the Credential in CDP.
    choices:
      - present
      - absent
    default: present
    type: str
  cloud:
    description:
      - The target cloud provider for the Credential.
      - Required if I(state=present).
    choices:
      - aws
      - azure
    required: False
    type: str
  role:
    description:
      - The CDP cross-account role.
      - Required if I(state=present).
      - For I(cloud=aws), this is the Role ARN for the cross-account role.
    aliases:
      - arn
      - role_arn
    required: False
    type: str
  description:
    description:
      - Descriptive text for the Credential.
    aliases:
      - desc
    type: str
    required: False
    default: None
  retries:
    description:
      - Number of times to retry the create operation if a possible eventual consistency error is returned
      - Set to 0 to fail immediately on such errors
    default: 5
    required: False
    type: int
  delay:
    description:
      - Delay period in seconds between retries
    default: 3
    required: False
    type: int
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Create a CDP Credential for AWS
- cloudera.cdp.env_cred:
    state: present
    cloud: aws
    name: example-credential
    description: This is an example Credential
    role: arn:aws:iam::981304421142:role/some-cross-account-role

# Delete a CDP Credential
- cloudera.cdp.env_cred:
    state: absent
    name: example-credential

# Create a CDP Credential for AWS and log the output of the CDP SDK in the return values
- cloudera.cdp.env_cred:
    name: example-credential
    debug: yes
'''

RETURN = '''
credential:
    description: Returns an object for the Credential.
    returned: success
    type: complex
    contains:
        cloudPlatform:
            description: The name of the cloud provider for the Credential.
            returned: always
            type: str
            sample: AWS
        credentialName:
            description: The name of the Credential.
            returned: always
            type: str
            sample: example-credential
        crn:
            description: The CDP CRN value derived from the cross-account Role ARN used during creation.
            returned: always
            type: str
            sample: crn:cdp:environments:us-west-1:558bc1d2-8867-4357-8524-311d51259233:credential:61eb5b97-226a-4be7-b56d-795d18a043b5
        description:
            description: The description of the Credential.
            returned: when supported
            type: str
            sample: An example Credential
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''

CREDENTIAL_NAME_PATTERN = re.compile(r'[^a-z0-9-]')


class EnvironmentCredential(CdpModule):
    def __init__(self, module):
        super(EnvironmentCredential, self).__init__(module)

        # Set variables
        self.state = self.module.params['state']
        self.cloud = self.module.params['cloud']
        self.name = self.module.params['name']
        self.role = self.module.params['role']
        self.retries = self.module.params['retries']
        self.delay = self.module.params['delay']
        self.description = self.module.params['description']

        # Initialize the return values
        self.credential = {}
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        """Executes the module logic."""
        self.validate_credential_name()

        try:
            client = self.build_client('environments')

            credential = self.describe_credential(client)
            if self.state == 'absent':
                if credential is not None:
                    self.credential = self.delete_credential(client)
            else:
                if credential is None:
                    self.credential = self.create_credential(client)
                else:
                    if self.reconcile_credential(credential):
                        self.credential = credential
                    else:
                        self.delete_credential(client)
                        self.credential = self.create_credential(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        self.log_out = self.builder.get_log()
        self.log_lines = self.log_out.splitlines()

    def validate_credential_name(self):
        """Ensures that Credential names follow required formatting and fails the module on error."""
        if re.search(CREDENTIAL_NAME_PATTERN, self.name) is not None:
            self.module.fail_json(msg='Invalid credential name, "%s". CDP credentials must contain only lowercase '
                                      'letters, numbers and hyphens.' % self.name)

    def describe_credential(self, client):
        """Returns the named credential, if found. Otherwise returns None."""
        cred = self._get_credential(client)
        if cred is not None:
            return cred[0]
        else:
            return cred

    @handle_cdp_error('NOT_FOUND', None, 'credentials')
    # TODO: Check should this be an empty list on no response?
    def _get_credential(self, client):
        return client.list_credentials(credentialName=self.name)

    def delete_credential(self, client):
        """Deletes the named credential, returning an empty object or ClientError."""
        self.changed = True
        if not self.module.check_mode:
            return client.delete_credential(credentialName=self.name)

    def reconcile_credential(self, credential):
        """
        Tests for differences between existing credential and inputs, returning TRUE if no changes.
        Note that only 'description' is checked, as the existing credential only exposes its computed 'crn', not
        the role ARN.
        """
        self.module.warn('Changes to Role ARN cannot be checked. If you need to change the Role ARN, explicitly delete'
                         ' and recreate the credential.')
        if 'description' in credential:
            return credential['description'] == self.description
        else:
            return self.description is None

    def create_credential(self, client):
        """Creates a Credential, returning a dictionary of the newly-created object or ClientError."""
        self.changed = True
        if not self.module.check_mode:
            if self.cloud == 'aws':
                return self._create_aws_credential(client)
            else:
                return self._create_azure_credential(client)

    def _create_aws_credential(self, client):
        """Creates an AWS Credential."""
        try:
            if self.description is not None:
                return client.create_aws_credential(credentialName=self.name, roleArn=self.role,
                                                    description=self.description)
            else:
                return client.create_aws_credential(credentialName=self.name, roleArn=self.role)
        except ClientError as e:
            error = parse_client_error(e)
            if self.retries > 0 and 'not authorized to perform sts:AssumeRole' in error['violations']['message']:
                self.retries = self.retries - 1
                self.module.warn('Got likely AWS IAM eventual consistency error, %d retries left...' % self.retries)
                sleep(self.delay)
                return self._create_aws_credential(client)
            else:
                self.module.fail_json(msg=to_native(error), **error)

    def _create_azure_credential(self, client):
        """Creates an Azure Credential."""
        raise Exception("Not yet implemented")


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            state=dict(required=False, type='str', choices=['present', 'absent'], default='present'),
            cloud=dict(required=False, type='str', choices=['aws', 'azure']),
            name=dict(required=True, type='str', aliases=['credential']),
            role=dict(required=False, type='str', aliases=['arn', 'role_arn']),
            description=dict(required=False, type='str', aliases=['desc'], default=None),
            retries=dict(required=False, type='int', default=5),
            delay=dict(required=False, type='int', default=3)
        ),
        required_if=[
            ['state', 'present', ('cloud', 'role', ), False]
        ],
        supports_check_mode=True
    )

    result = EnvironmentCredential(module)

    output = dict(
        changed=result.changed,
        credential=result.credential,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
