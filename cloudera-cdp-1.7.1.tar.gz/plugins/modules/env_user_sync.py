#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import time

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, parse_client_error, \
    handle_cdp_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_user_sync
short_description: Sync CDP Users and Groups to Environments
description:
  - Synchronize users and groups with one or more CDP environments.
  - The module support check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  name:
    description:
      - A single Environment or list of Environments that will sync all CDP Users and Groups.
      - If not present, all Environments will be synced.
      - Mutually exclusive with I(current_user).
    aliases:
      - environment
    required: False
    type: list
    elements: str
  current_user:
    description:
      - Sync the current CDP user as defined by the C(CDP_PROFILE) with all environments.
      - Mutually exclusive with I(name).
    aliases:
      - user
    required: False
    type: bool
  delay:
    description:
      - The internal polling interval (in seconds) while the module waits for the datalake to achieve the declared state.
    type: int
    required: False
    default: 15
    aliases:
      - polling_delay
  timeout:
    description:
      - The internal polling timeout (in seconds) while the module waits for the datalake to achieve the declared state.
    type: int
    required: False
    default: 3600
    aliases:
      - polling_timeout
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Sync a CDP Environment
- cloudera.cdp.env_user_sync:
    name: example-environment

# Sync multiple CDP Environments
- cloudera.cdp.env_user_sync:
    name:
      - example-environment
      - another-environment

# Sync the current CDP User
- cloudera.cdp.env_user_sync:
    current_user: yes
'''

RETURN = '''
sync:
    description: Returns an object describing of the status of the User and Group sync event.
    returned: success
    type: complex
    contains:
        endTime:
            description: Sync operation end timestamp (epoch seconds).
            returned: when supported
            type: str
            sample: 1602080301000
        error:
            description: Error message for general failure of sync operation.
            returned: when supported
            type: str
        failure:
            description: List of sync operation details for all failed environments.
            returned: when supported
            type: list
            elements: dict
            contains:
                environmentCrn:
                    description: The environment CRN.
                    returned: always
                    type: str
                message:
                    description: Details on the failure.
                    returned: when supported
                    type: str
        operationId:
            description: UUID of the request for this operation.
            returned: always
            type: str
            sample: 0e9bc67a-b308-4275-935c-b8c764dc13be
        operationType:
            description: The operation type.
            returned: when supported
            type: str
            sample: USER_SYNC
        startTime:
            description: Sync operation start timestamp (epoch seconds).
            returned: when supported
            type: str
            sample: 1602080301000
        status:
            description: Status of this operation.
            returned: when supported
            type: str
            sample:
                - NEVER_RUN
                - REQUESTED
                - REJECTED
                - RUNNING
                - COMPLETED
                - FAILED
                - TIMEDOUT
        success:
            description: List of sync operation details for all succeeded environments.
            returned: when supported
            type: list
            elements: dict
            contains:
                environmentCrn:
                    description: The environment CRN.
                    returned: always
                    type: str
                message:
                    description: Details on the success.
                    returned: when supported
                    type: str
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''

OPERATION_REGEX = 'operation ([0-9a-zA-Z-]{36}) running'

FAILED_STATES = [
    'REJECTED',
    'FAILED',
    'TIMEDOUT'
]


class EnvironmentUserSync(CdpModule):
    def __init__(self, module):
        super(EnvironmentUserSync, self).__init__(module)

        # Set variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None
        self.current_user = self.module.params['current_user'] if 'current_user' in self.module.params else None
        self.wait = self.module.params['wait']
        self.delay = self.module.params['delay']
        self.timeout = self.module.params['timeout']

        # Initialize the return values
        self.sync = {}
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')
            if self.current_user:
                self.sync = self.sync_current_user(client)
            else:
                self.sync = self.sync_environments(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        self.log_out = self.builder.get_log()
        self.log_lines = self.log_out.splitlines()

    def sync_current_user(self, client):
        self.changed = True
        results = dict()
        if not self.module.check_mode:
            results = client.sync_user()
            if self.wait:
                results = self._wait_for_state(client, results['operationId'], 'COMPLETED')
        return results

    def sync_environments(self, client):
        results = dict()
        payload = dict()

        if self.name:
            payload.update(environmentNames=self.name)

        if not self.module.check_mode:
            try:
                results = client.sync_all_users(**payload)
                self.changed = True
                if self.wait:
                    results = self._wait_for_state(client, results['operationId'], 'COMPLETED')
            except ClientError as e:
                error = parse_client_error(e)
                if error['status_code'] == '409' and error['operation'] == 'syncAllUsers' and error['msg'] == 'CONFLICT':
                    operation_match = re.search(OPERATION_REGEX, error['violations']['message'])
                    if operation_match is not None:
                        if not self.wait:
                            self.module.warn('User and group sync is already performing an operation, retrieving existing operation details')
                            results = self._get_sync_status(client, operation_match.group(1))
                        else:
                            self.changed = True
                            results = self._wait_for_state(client, operation_match.group(1), 'COMPLETED')
                    else:
                        raise e
                else:
                    raise e

        return results

    @handle_cdp_error('NOT_FOUND', None)
    def _get_sync_status(self, client, operation_id):
        return client.sync_status(operationId=operation_id)

    def _wait_for_state(self, client, operation_id, state, fail_state=frozenset(FAILED_STATES)):
        if not isinstance(state, list):
            state = [state]

        timeout = time.time() + self.timeout

        current = self._get_sync_status(client, operation_id)

        while True:
            if current is not None:
                self.module.log('Waiting for status change for FreeIPA user sync. Current status: %s' %
                                current['status'])
            if current is not None and current['status'] in state:
                break
            elif current is not None and current['status'] in fail_state:
                fail = 'FreeIPA user sync did not reach expected state(s), %s, encountered failed state, %s.' % (state, current['status'])
                raise Exception(fail)
            else:
                if time.time() > timeout:
                    fail = 'FreeIPA did not reach expected state(s), %s. Activity timed out.' % state
                    raise Exception(fail)
                time.sleep(self.delay)
                current = self._get_sync_status(client, operation_id)

        return current


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='list', aliases=['environment']),
            current_user=dict(required=False, type='bool', aliases=['user']),
            wait=dict(required=False, type='bool', default=True),
            delay=dict(required=False, type='int', aliases=['polling_delay'], default=15),
            timeout=dict(required=False, type='int', aliases=['polling_timeout'], default=3600)
        ),
        mutually_exclusive=(
            ['name', 'current_user']
        ),
        supports_check_mode=True
    )

    result = EnvironmentUserSync(module)

    output = dict(
        changed=result.changed,
        sync=result.sync,
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
