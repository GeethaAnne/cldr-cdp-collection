#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2020, Cloudera
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

import ansible_collections.cloudera.cdp.plugins.module_utils.cloudera as cldr
import json
from operator import itemgetter
from ansible.module_utils.basic import AnsibleModule

try:
    import cm_client
    from cm_client.rest import ApiException
except ImportError:
    raise ImportError(
        'pip package cm_client could not be imported. Is it installed?')

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: cm_roleconfiggroups_info

short_description: Get role config groups info for a given cluster

version_added: "2.9.5"

description:
    - "Returns the information for role config groups for a given cluster and service."

options:
    username:
        description:
            - Cloudera Manager username
        default: "admin"
        type: str
    
    password:
        description:
            - Cloudera Manager password
        default: "admin"
        type: str
    
    protocol:
        description:
            - Cloudera Manager protocol
        default: "https"
        type: str
        choices: [ "http" , "https" ]

    host:
        description:
            - Cloudera Manager host
        default: "localhost"
        type: str
    
    port:
        description:
            - Cloudera Manager port
        default: 443
        type: int
    
    path:
        description:
            - Cloudera Manager path to API
        default: "/api/v40"
        type: str

    verify_ssl:
        description:
            - Whether to verify SSL connection
        default: "yes"
        type: bool



    cluster_name:
        description:
            - The cluster name
        type: str
        required: true

    service_name:
        description:
            - The name of the service for which you want to get the role config groups info
        type: str
        required: true
    
    name:
        description:
            - The config group name. If none is specified, all config group names will be returned
        type: str
    
    show_roles:
        description:
            - Returns all roles in the given role config group.
        default: "no"
        type: bool

       
requirements: [ "cm_client" ]

author:
    - Cloudera
'''

EXAMPLES = '''
# Returns the information for all role config groups for a given cluster and service.
- cm_roleconfiggroups_info:
    # connection details
    username: my_workload_username
    password: my_password
    host: mycluster.domain.com
    path: "/mydatalake/cdp-proxy-api/cm-api/v40"

    cluster_name: mydatalake
    service_name: atlas


# Returns the information for a role config group.
- cm_roleconfiggroups_info:
    # connection details
    username: my_workload_username
    password: my_password
    host: mycluster.domain.com
    path: "/mydatalake/cdp-proxy-api/cm-api/v40"

    cluster_name: mydatalake
    service_name: atlas
    name: atlas-ATLAS_SERVER-BASE


# Returns all roles in the given role config group.
- cm_roleconfiggroups_info:
    # connection details
    username: my_workload_username
    password: my_password
    host: mycluster.domain.com
    path: "/mydatalake/cdp-proxy-api/cm-api/v40"

    cluster_name: mydatalake
    service_name: atlas
    name: atlas-ATLAS_SERVER-BASE
    show_roles: yes

'''

RETURN = '''
out:
    description: The response that the module generates
    type: dict
    returned: always
meta:
    description: The parameters passed
    type: dict
    returned: always
'''


class Client(object):
    # Setup
    def __init__(self, module):
        self.module = module

        # Extracting variables from all args for readability
        # parameters for ApiClient
        self.username = self.module.params['username']
        self.password = self.module.params['password']
        self.protocol = self.module.params['protocol']
        self.host = self.module.params['host']
        self.port = self.module.params['port']
        self.path = self.module.params['path']
        self.verify_ssl = self.module.params['verify_ssl']

        # module specific
        self.cluster_name = self.module.params['cluster_name']
        self.service_name = self.module.params['service_name']
        self.name = self.module.params['name']
        self.show_roles = self.module.params['show_roles']

        # Outputs
        self.changed = False
        self.out = None

        # Finally, call main process
        self.process()

    # Control Logic
    def process(self):
        # Create the CM API Client
        self.client = cldr.build_ApiClient(self.module.params)

        if self.name is None:
            self.get_all_rcgs()
        else:
            if self.show_roles:
                self.get_roles()
            else:
                self.get_rcg()

    def get_all_rcgs(self):
        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        try:
            apiRoleConfigGroupList = api.read_role_config_groups(
                self.cluster_name,
                self.service_name
            )
            self.out = apiRoleConfigGroupList.to_dict()

        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def get_rcg(self):
        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        try:
            apiRoleConfigGroup = api.read_role_config_group(
                self.cluster_name,
                self.name,
                self.service_name)

            self.out = apiRoleConfigGroup.to_dict()
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))

    def get_roles(self):
        api = cm_client.RoleConfigGroupsResourceApi(self.client)

        try:
            apiRoleList = api.read_roles(
                self.cluster_name,
                self.name,
                self.service_name
            )

            self.out = apiRoleList.to_dict()
        except ApiException as e:
            self.module.fail_json(meta=self.module.params,
                                  msg=cldr.stringify_error(e))


def main():
    module = AnsibleModule(
        argument_spec=dict(
            # parameters for the ApiClient
            username=dict(type='str', default="admin"),
            password=dict(type='str', no_log=True, default="admin"),

            protocol=dict(type='str', choice=[
                          'http', 'https'], default="https"),
            host=dict(type='str', default="localhost"),
            port=dict(type='int', default=443),
            path=dict(type='str', default="/api/v40"),

            verify_ssl=dict(type='bool', default=True),

            cluster_name=dict(type='str'),
            service_name=dict(type='str'),
            name=dict(type='str', default=None),
            show_roles=dict(type='bool', default=False),

        ),
        supports_check_mode=False,
    )

    result = Client(module)
    module.exit_json(meta=module.params,
                     changed=result.changed, out=result.out)


if __name__ == '__main__':
    main()
