#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule

import boto3

DOCUMENTATION = r''' # '''

def main():
    module = AnsibleModule(
        argument_spec=dict(
            bucket=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )

    s3 = boto3.resource('s3')
    bucket = s3.Bucket(module.params['bucket'])
    data = bucket.objects.all().delete()

    module.exit_json(changed=True, result=data)


if __name__ == '__main__':
    main()