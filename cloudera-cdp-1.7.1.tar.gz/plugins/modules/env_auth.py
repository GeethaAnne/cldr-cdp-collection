#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule, to_native
from ansible_collections.cloudera.cdp.plugins.module_utils.cdp_common import CdpModule, handle_cdp_error, \
    parse_client_error
from cdpcli.exceptions import ClientError

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: env_auth
short_description: Set authentication details for the current CDP user
description:
  - Set authentication details for the current CDP user for one or more Environments.
  - The module supports check_mode.
author:
  - "Webster Mudge (@wmudge)"
requirements:
  - cdpcli
options:
  name:
    description:
      - The targeted environment(s).
      - If no environment is specified, all environments are affected.
    type: list
    elements: str
    required: False
    aliases:
      - environment
  password:
    description:
      - The workload password to set for the current CDP user.
      - Passwords must be a minimum of 8 characters and no more than 64 characters and should be a combination of upper case, lower case, digits, and special characters.
      - Set to 'no_log' within Ansible.
    type: str
    required: True
    aliases:
      - workload_password
  strict:
    description:
      - A flag to ignore I(Conflict) errors on password updates.
    type: bool
    required: False
    default: True
extends_documentation_fragment:
  - cloudera.cdp.cdp_sdk_options
  - cloudera.cdp.cdp_auth_options
'''

EXAMPLES = '''
# Note: These examples do not set authentication details.

# Set the workload user password for the current CDP user on all environments
- cloudera.cdp.env_auth:
    password: Cloudera@2020!

# Set the workload user password for the current CDP user on selected environments
- cloudera.cdp.env_auth:
    name:
      - one-environment
      - two-environment
    password: Cloudera@2020!
'''

RETURN = '''
sdk_out:
    description: Returns the captured CDP SDK log.
    returned: when supported
    type: str
sdk_out_lines:
    description: Returns a list of each line of the captured CDP SDK log.
    returned: when supported
    type: list
    elements: str
'''


class EnvironmentAuthentication(CdpModule):
    def __init__(self, module):
        super(EnvironmentAuthentication, self).__init__(module)

        # Set variables
        self.name = self.module.params['name'] if 'name' in self.module.params else None
        self.password = self.module.params['password']
        self.strict = self.module.params['strict']

        # Initialize the return values
        self.changed = False

        # Execute logic process
        self.process()

    def process(self):
        try:
            client = self.build_client('environments')
            if not self.module.check_mode:
                self.set_password(client)
        except ClientError as e:
            error = parse_client_error(e)
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)
        except Exception as e:
            error = dict(msg=to_native(e))
            if self.debug:
                log = self.builder.get_log()
                error.update(sdk_out=log, sdk_out_lines=log.splitlines())
            self.module.fail_json(**error)

        if self.debug:
            self.log_out = self.builder.get_log()
            self.log_lines = self.log_out.splitlines()

    def set_password(self, client):
        payload = dict(password=self.password)

        if self.name is not None:
            converted_names = self._discover_env_crns(client)
            payload.update(environmentCRNs=converted_names)

        try:
            client.set_password(**payload)
            self.changed = True
        except ClientError as e:
            error = parse_client_error(e)
            if not self.strict and 'CONFLICT' in error['msg']:
                self.module.warn('Strict error handling not set, ignoring Conflict response on password '
                                 'update. Error: %s' % error['violations']['message'])
            else:
                raise e

    def _discover_env_crns(self, client):
        converted = []
        for name in self.name:
            env = self._describe_environment(client, name)
            if env is None:
                self.module.fail_json(msg="Environment not found")
            else:
                converted.append(env['crn'])
        return converted

    @handle_cdp_error('NOT_FOUND', None, 'environment')
    def _describe_environment(self, client, name):
        return client.describe_environment(environmentName=name)


def main():
    module = AnsibleModule(
        argument_spec=CdpModule.argument_spec(
            name=dict(required=False, type='list', elements='str', aliases=['environment']),
            password=dict(required=True, type='str', no_log=True, aliases=['workload_password']),
            strict=dict(required=False, type='bool', default=True)
        ),
        supports_check_mode=True
    )

    result = EnvironmentAuthentication(module)

    output = dict(
        changed=result.changed
    )

    if result.debug:
        output.update(
            sdk_out=result.log_out,
            sdk_out_lines=result.log_lines
        )

    module.exit_json(**output)


if __name__ == '__main__':
    main()
